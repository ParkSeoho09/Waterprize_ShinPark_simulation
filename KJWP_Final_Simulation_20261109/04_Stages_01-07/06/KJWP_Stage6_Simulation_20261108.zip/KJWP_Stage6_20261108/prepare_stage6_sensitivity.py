"""Select two exploratory leaders and write reproducible sensitivity manifests.

Selection is by reaction mass only; generated files are plans, not results.
"""
import argparse
import copy
import json
from pathlib import Path

from kjwp_stage1.evaluation import evaluate_batch


def prepare(batch, manifest, out):
    result,_,_=evaluate_batch(batch)
    if not result['comparison_ready']:raise ValueError('Primary audit failed')
    selected=[r['id'] for r in sorted(result['rows'],key=lambda r:r['reaction_rank'] or 999) if r['kind']=='injection'][:2]
    manifest=Path(manifest).resolve();m=json.loads(manifest.read_text())
    base=json.loads((manifest.parent/m['base']).read_text())
    chosen=[j for j in m['jobs'] if j['id'] in selected or next(r for r in result['rows'] if r['id']==j['id'])['kind']=='no_injection']
    out=Path(out);out.mkdir(parents=True,exist_ok=False)
    def write(name,value):(out/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    jobs=[]
    for job in chosen:
        value=json.loads((manifest.parent/job['layout']).read_text());name=job['id']+'.json'
        write(name,value);jobs.append(dict(id=job['id'],layout=name))
    variants={}
    # Grid and temporal effects can be separated using the independently written cases.
    for name,grid,half in [('fine_combined',True,True),('half_dt',False,True),('fine_grid',True,False)]:
        cfg=copy.deepcopy(base)
        if grid:cfg['grid']['cells_xyz']=[19,19,31]
        if half:
            cfg['max_dt_s']/=2
            for period in cfg.get('time_step_schedule',[]):period['max_dt_s']/=2
        variants[name]=cfg
    cfg=copy.deepcopy(base)
    cfg['chemistry']['batch']['environment_periods']=[dict(start_hour=0,dissolved_oxygen_mg_L=0,active_fraction=.25,in_contact=True)]
    cfg.setdefault('assumptions',{})['oxygen']='Prescribed DO=0 mg/L, activity=0.25, no lag; uncalibrated scenario, no oxygen balance'
    variants['activity_025']=cfg
    cfg=copy.deepcopy(base)
    cfg['chemistry']['batch']['environment_periods']=[dict(start_hour=0,dissolved_oxygen_mg_L=2,active_fraction=1,in_contact=True)]
    cfg['chemistry']['batch']['oxygen_half_inhibition_mg_L']=.2
    cfg.setdefault('assumptions',{})['oxygen']='Prescribed DO=2 mg/L, KI=0.2 mg/L, activity=1, no lag; uncalibrated inhibition scenario'
    variants['oxygen_scenario']=cfg
    for name,cfg in variants.items():
        write('base_'+name+'.json',cfg)
        write('batch_'+name+'.json',dict(schema_version=1,base='base_'+name+'.json',jobs=jobs))
    write('selection.json',dict(selection_metric='NO3_reacted_mg',selected=selected,
          primary_input_sha256={k:v['input_sha256'] for k,v in result['audits'].items()},
          notes=['Files are planned cases, not completed evidence.',
                 'Activity 0.25 and DO 2 mg/L, KI 0.2 mg/L are uncalibrated exploratory scenarios.',
                 'Fine combined changes grid and time. Use half_dt and fine_grid to separate effects.']))
    return selected


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('batch')
    p.add_argument('--manifest',default='configs/stage6/batch_primary.json');p.add_argument('--out',required=True)
    a=p.parse_args();print(json.dumps(prepare(a.batch,a.manifest,a.out)))
