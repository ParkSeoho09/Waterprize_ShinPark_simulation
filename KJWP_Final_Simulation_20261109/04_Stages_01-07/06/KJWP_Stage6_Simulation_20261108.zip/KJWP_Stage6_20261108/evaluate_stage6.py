"""Produce audited Stage 6 comparisons, charts and sensitivity evidence."""
import argparse
import base64
import csv
import html
import json
from pathlib import Path
import re

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

from kjwp_stage1.evaluation import evaluate_batch, compare_sensitivity

LABELS = {'CONTROL':'무주입', 'B00001':'밀집 정사각형', 'B00007':'넓은 정사각형',
          'B00035':'교대 5° 경사', 'B00285':'삼각 격자형', 'B06839':'V자형'}


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False)+'\n',encoding='utf-8')


def write_csv(path, rows):
    with path.open('w',newline='',encoding='utf-8-sig') as stream:
        writer=csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader();writer.writerows(rows)


def plot_histories(histories, out):
    fig,axes=plt.subplots(2,2,figsize=(12,8),constrained_layout=True)
    control=histories.get('CONTROL')
    for name,h in histories.items():
        time=h['time_s']/3600
        axes[0,0].plot(time,h['NO3_reacted_kg']*1e6,label=name)
        axes[0,1].plot(time,h['NO3_bottom_out_kg']*1e6,label=name)
        if control is not None:
            baseline=np.interp(h['time_s'],control['time_s'],control['NO3_bottom_out_kg'])
            axes[1,0].plot(time,(baseline-h['NO3_bottom_out_kg'])*1e6,label=name)
        axes[1,1].plot(time,h['SO4_reaction_net_kg']*1e6,label=name)
    for ax,title,unit in zip(axes.flat,['Cumulative nitrate reaction','Cumulative bottom nitrate outflow',
                                       'Control minus candidate bottom outflow','Reaction-generated sulfate'],
                             ['NO3 (mg)','NO3 (mg)','NO3 difference (mg)','SO4 (mg)']):
        ax.set(title=title,xlabel='Time (h)',ylabel=unit); ax.grid(alpha=.2)
    axes[0,0].legend(ncol=2,fontsize=8)
    axes[1,0].axhline(0,color='black',lw=.7)
    fig.savefig(out/'time_curves.png',dpi=170)
    plt.close(fig)


def plot_ports(cfgs, rows, out):
    names=[r['id'] for r in rows if r['kind']=='injection']
    fig,axes=plt.subplots(1,len(names),figsize=(3*len(names),3.4),constrained_layout=True,squeeze=False)
    for ax,name in zip(axes.flat,names):
        p=np.array([p['position_m'] for p in cfgs[name]['ports']])
        ax.scatter(p[:,0],p[:,1],s=20,alpha=.7)
        lengths=cfgs[name]['grid']['lengths_m']
        ax.set(title=name,xlim=(0,lengths[0]),ylim=(0,lengths[1]),xlabel='x (m)',ylabel='y (m)',aspect='equal')
        ax.grid(alpha=.2)
    fig.suptitle('Actual compiled outlets: horizontal projection (depths overlap)')
    fig.savefig(out/'outlet_layouts.png',dpi=170);plt.close(fig)


def plot_sensitivity(primary, variants, out):
    names=sorted(set.intersection(*(set(r['id'] for r in value['rows'] if r['kind']=='injection') for value in variants.values())))
    cases={'primary':primary}
    for label in ('half_dt','fine_combined'):
        if label in variants:cases[label]=variants[label]
    cases.update(variants)
    fig,axes=plt.subplots(1,2,figsize=(11,4.2),constrained_layout=True)
    for ax,metric,title in zip(axes,('NO3_reacted_mg','NO3_bottom_out_mg'),('Nitrate reaction','Bottom nitrate outflow')):
        x=np.arange(len(cases));width=.8/len(names)
        for i,name in enumerate(names):
            y=[next(r for r in value['rows'] if r['id']==name)[metric] for value in cases.values()]
            ax.bar(x+(i-(len(names)-1)/2)*width,y,width,label=name)
        ax.set_xticks(x,list(cases));ax.set(title=title,ylabel='NO3 (mg)');ax.grid(axis='y',alpha=.2)
    axes[0].legend();fig.savefig(out/'numerical_sensitivity.png',dpi=170);plt.close(fig)


def make_report(result, sensitivities, environment, out):
    rows=result['rows']; inject=[r for r in rows if r['kind']=='injection']
    duration=rows[0]['duration_h']
    screening = 'screening_solver_sha256' in result['physical_conditions']
    def ph_text(value):
        return '미산정' if value is None else f'{value:.6f}'
    top=max(inject,key=lambda r:r['NO3_reacted_mg'])
    if sensitivities:
        conclusion=('후속 검사 대상 두 후보의 순서는 관측한 수치 변화에 대한 보수적 검사를 통과했다. 전체 후보군의 최적해 입증은 아니다.'
                    if all(p['rank_supported_by_screen'] for p in sensitivities['pairwise']) else
                    '**배치 우열은 보류한다.** 후속 검사에서 후보 간 차이보다 수치 변동이 크거나 순서가 바뀌어 안정적인 순위를 확보하지 못했다.')
    else:conclusion='현재는 1차 비교이며 수치 민감도 결과가 연결되기 전에는 배치 우열을 확정하지 않는다.'
    lines=['# Stage 6 · 배치별 정량 성능 비교', '',
           f'모의시간 {duration:g}시간. 평가 검사 통과: **{result["comparison_ready"]}**. 실제 현장/실험 성능이 아닌 시나리오 계산이다.', '',
           f'기준 설정에서 누적 질산염 반응량이 가장 큰 후보는 {top["id"]}({top["NO3_reacted_mg"]:.3f} mg, '
           f'초기량+유입량 대비 {top["NO3_reacted_percent"]:.3f}%)다. '+conclusion, '',
           *(['고정 pH Monod 빠른 모드. 황산염은 반응 화학양론으로 계산했고, 방해석 용해와 pH 변화는 미산정이다.', ''] if screening else []),
           '## 공정 비교와 1차 결과', '',
           '| 배치 | 반응 제거 NO₃ (mg) | 반응 비율 (%) | 바닥 유출 NO₃ (mg) | 대조군 대비 유출 감소 (mg) | 잔류 NO₃ (mg) |',
           '|---|---:|---:|---:|---:|---:|']
    for r in rows:
        lines.append(f'| {r["id"]} {LABELS.get(r["id"],"")} | {r["NO3_reacted_mg"]:.6f} | {r["NO3_reacted_percent"]:.6f} | {r["NO3_bottom_out_mg"]:.6f} | {r["control_bottom_difference_mg"]:.6f} | {r["NO3_remaining_mg"]:.6f} |')
    r=rows[0]
    lines+=['',f'반응 비율의 분모는 초기 질산염 {r["NO3_initial_mg"]:.3f} mg + 계산 중 유입량 {r["NO3_entered_mg"]:.3f} mg다. '
            '초기 저장 질산염과 신규 표면 유입 질산염을 구분 추적하지 않으므로, 이 값을 신규 오염 차단율로 부르면 안 된다.', '',
            '대조군 대비 유출 감소가 음수이면 해당 후보의 바닥 유출량이 더 많다. 무주입 대조군은 물 공급도 0이므로 유동 차이를 포함한다. '
            '동일 실행의 NO3_passive와 NO3 차이는 같은 유동장에서 반응 유무를 비교하는 별도 장부다.', '',
            '![시간 곡선](time_curves.png)', '', '![출구 배치](outlet_layouts.png)', '',
            '## 투입·접촉·재료 및 에너지 지표', '',
            '| 배치 | 고체 (g) | 운반수 (mL) | 투입 완료 (s) | 출구 공급량 CV | 최종 잔류 NO₃ 동시 존재 비율 (%) |',
            '|---|---:|---:|---:|---:|---:|']
    for r in inject:
        lines.append(f'| {r["id"]} | {r["dry_solid_g"]:.9f} | {r["carrier_water_mL"]:.6f} | {r["injection_completion_s"]:.6f} | {r["port_volume_cv"]:.6f} | {100*r["final_remaining_NO3_colocated_fraction"]:.4f} |')
    lines+=['', '동시 존재 비율은 최종 시각에 고체합이 1×10⁻¹⁰ kg/m³ 토양을 넘는 셀에 있는 잔류 질산염의 질량 비율이다. '
            '**접촉효율이나 반응한 물의 비율이 아니다.** 격자·문턱값에 의존하는 접촉 가능성 지표다. '
            '주입 추적자의 잔류 질량 가중 연령·반응재 접촉 모멘트는 comparison.csv에 따로 제공하며 실제 질산염 체류시간이나 공극 RTD로 해석하지 않는다.', '',
            f'후보별 투입 황 {inject[0]["sulfur_g"]:.6f} g, CaCO₃ {inject[0]["CaCO3_g"]:.6f} g. '
            f'공통 출구 압력에 대한 슬러리 압력 일은 약 {inject[0]["outlet_pressure_work_J"]:.6f} J다. '
            '이는 출구 ∑P·V이며 펌프 효율·관내 손실·양정·대기전력을 포함한 소비전력이 아니다. '
            '가격 입력이 없어 실제 비용은 미산정(null)이다. '
            f'첫 주입 후보의 관 몸체 총길이는 {inject[0]["pipe_body_total_length_m"]:g} m이며 연결 관축 수는 {inject[0]["pipe_assembly_count"]}개다. '
            '배치별 관 길이와 관축 수는 comparison.csv에 따로 기록했다. 직접 출구만 입력한 검사용 배치는 관 길이를 0으로 표시한다.', '',
            '## 2차 수질 영향', '',
            '| 배치 | 생성 SO₄ (mg) | 최종 SO₄ 최대 (mg/L) | 생성 Ca (mg) | 최종 pH 최솟값 | 최종 pH 최댓값 |',
            '|---|---:|---:|---:|---:|---:|']
    for r in rows:
        lines.append(f'| {r["id"]} | {r["SO4_generated_mg"]:.6f} | {r["final_SO4_max_mg_L"]:.6f} | {r["Ca_generated_mg"]:.6f} | {ph_text(r["final_pH_min"])} | {ph_text(r["final_pH_max"])} |')
    lines+=['', 'SO₄ 최종 농도에는 초기 SO₄가 포함되므로 생성량과 구분했다. 위 pH는 최종 격자장의 범위이며 모든 중간 시각의 전역 극값을 뜻하지 않는다. EC·경도·규제 적합성 판정은 하지 않는다.', '',
            '## 수치 민감도와 순위 판단', '']
    if sensitivities:
        for p in sensitivities['pairwise']:
            lines.append(f'- {p["a"]} / {p["b"]}: 기준 반응량 차이 {p["primary_reaction_gap_mg"]:.6f} mg, '
                         f'관측한 수치 변화 합 {p["summed_observed_numerical_change_mg"]:.6f} mg, '
                         f'순서 유지 {p["order_preserved"]}, 보수적 순위 검사 통과 **{p["rank_supported_by_screen"]}**.')
        lines+=['', '격자와 시간 간격 변화 결과는 sensitivity_changes.csv에 있다. 순위 검사에서는 두 후보 반응량 차이가 '
                '각 후보의 기준 대비 최대 수치 변화 절댓값의 합보다 크고, 모든 검사에서 순서가 유지되어야 한다. '
                '관측된 변동을 사용한 선별 규칙이며 엄밀한 오차 상계나 공간 수렴 증명은 아니다. 검사하지 않은 후보의 순위 안정성은 미확인이다.']
        lines+=['','![수치 민감도](numerical_sensitivity.png)','',
                '`primary → half_dt`는 같은 격자의 시간 간격 효과, `half_dt → fine_combined`는 같은 절반 시간 간격에서의 격자 효과다. '
                '두 효과를 구분하되, 이 세 설정만으로 점근적 수렴 차수를 추정하지 않는다.']
        lines+=['','| 수치 설정 | 격자 | 대조군 초기 NO₃ (mg) | 대조군 바닥 유출 NO₃ (mg) |', '|---|---|---:|---:|']
        for c in sensitivities['control_checks']:
            grid='×'.join(map(str,c['numerical_settings']['grid']['cells_xyz']))
            lines.append(f'| {c["variant"]} | {grid} | {c["NO3_initial_mg"]:.6f} | {c["NO3_bottom_out_mg"]:.6f} |')
        lines+=['','초기 농도와 수두의 물리 조건은 같지만 격자별 초기 함수율 적분값이 달라 초기 질산염 질량에도 작은 차이가 생긴다. '
                '이를 숨기기 위해 농도를 보정하지 않았으며, 각 실행의 실제 초기 질량을 분모와 수지에 사용했다.']
    else:
        lines+=['민감도 결과가 아직 연결되지 않았다. 현재 순위는 1차 선별용이며 최적 배치로 확정하지 않는다.']
    if environment:
        lines+=['', '## 환경 시나리오 민감도', '', '| 시나리오 | 배치 | 반응 NO₃ (mg) | 바닥 유출 NO₃ (mg) |', '|---|---|---:|---:|']
        for label,v in environment.items():
            for r in v['rows']:
                if r['kind']=='injection':lines.append(f'| {label} | {r["id"]} | {r["NO3_reacted_mg"]:.6f} | {r["NO3_bottom_out_mg"]:.6f} |')
        lines+=['', '환경 입력값은 해당 실행의 input.json에 보존했다. 산소 억제계수·활성비율은 보정되지 않은 시나리오이며 토양 산소 수송 예측이 아니다.']
    lines+=['', '## 검증 및 남은 범위', '',
            f'- 공통 조건 일치: {result["common_conditions_match"]}; 동일 실제 고체/운반수/성분 투입: {result["equal_injected_dose"]}.',
            '- 원본 입력 해시, 완료 시각, CSV/요약 일치, 모든 기록 시각의 성분 수지·물 수지, 희석/반응 분리 장부, 황산염 화학양론을 검사했다.',
            '- 수지 통과 기준: 성분 10⁻¹⁰ kg + 상대 10⁻⁸, 물 10⁻⁹ m³ + 상대 10⁻⁸. 수치 민감도와 질량수지 통과는 서로 다른 조건이다.',
            '- 선택한 5개 후보만 비교했다. 23,223개 전체 검색, 깊이 최적화, 실측 반응속도/입경/토양 보정, 관 내부 손실, 독립 소프트웨어/실험 검증은 미완료다.',
            '- 산소 수송·생물량 성장·막힘·관벽 배제 부피는 기존 엔진의 미구현 범위다. Stage 7 UI 완료를 뜻하지 않는다.', '',
            '## 재현', '', '`python evaluate_stage6.py stage6_runs/primary --out stage6_results/primary`', '',
            '수치 민감도는 `--numerical LABEL=경로`, 환경 시나리오는 `--environment LABEL=경로`를 반복하여 연결한다. '
            'comparison.json에 원본 해시와 검사 결과를 저장한다. comparison.csv는 수치 단위가 열 이름에 명시되어 있다.']
    (out/'REPORT.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')


def make_html(out):
    """Render the report's restricted Markdown subset into a portable HTML file."""
    def inline(text):
        text=html.escape(text)
        text=re.sub(r'\*\*(.*?)\*\*',r'<strong>\1</strong>',text)
        return re.sub(r'`(.*?)`',r'<code>\1</code>',text)
    lines=(out/'REPORT.md').read_text(encoding='utf-8').splitlines()
    parts=[];i=0
    while i<len(lines):
        line=lines[i]
        if not line:i+=1;continue
        if line.startswith('|'):
            table=[]
            while i<len(lines) and lines[i].startswith('|'):
                cells=[v.strip() for v in lines[i].strip('|').split('|')]
                if not all(re.fullmatch(r':?-+:?',v) for v in cells):table.append(cells)
                i+=1
            parts.append('<div class="table"><table><thead><tr>'+''.join('<th>'+inline(v)+'</th>' for v in table[0])+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+inline(v)+'</td>' for v in row)+'</tr>' for row in table[1:])+'</tbody></table></div>')
            continue
        if line.startswith('!['):
            match=re.fullmatch(r'!\[(.*?)\]\((.*?)\)',line)
            if match:
                data=base64.b64encode((out/match[2]).read_bytes()).decode()
                parts.append(f'<figure><img alt="{html.escape(match[1])}" src="data:image/png;base64,{data}"></figure>')
        elif line.startswith('## '):parts.append('<h2>'+inline(line[3:])+'</h2>')
        elif line.startswith('# '):parts.append('<h1>'+inline(line[2:])+'</h1>')
        elif line.startswith('- '):parts.append('<p class="item">• '+inline(line[2:])+'</p>')
        else:parts.append('<p>'+inline(line)+'</p>')
        i+=1
    document='''<!doctype html><html lang="ko"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>KJWP Stage 6 정량 비교</title><style>
body{margin:0;background:#f4f6f8;color:#182a36;font-family:system-ui,"Malgun Gothic",sans-serif;line-height:1.75}main{max-width:1180px;margin:auto;padding:40px 26px 90px}h1{font-size:30px;line-height:1.4;border-bottom:4px solid #167d8d;padding-bottom:20px}h2{margin-top:44px;color:#176979;font-size:23px}p{max-width:1040px}.table{overflow:auto;background:white;border:1px solid #dbe4e8;border-radius:8px}table{border-collapse:collapse;width:100%;font-variant-numeric:tabular-nums;font-size:13px}th,td{padding:12px 10px;border-bottom:1px solid #e3eaed;text-align:right;white-space:nowrap}th{background:#e7f1f3}th:first-child,td:first-child{text-align:left}figure{margin:28px 0}img{width:100%;height:auto;background:white;border-radius:8px}code{background:#e7ecef;padding:2px 5px;font-size:.9em;overflow-wrap:anywhere}.item{margin:6px 0}strong{color:#134f62}@media print{body{background:white}main{padding:0}h2{break-after:avoid}figure,.table{break-inside:avoid}}
</style><main>'''+''.join(parts)+'</main></html>'
    (out/'REPORT.html').write_text(document,encoding='utf-8')


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('batch');p.add_argument('--out',required=True)
    p.add_argument('--numerical',action='append',default=[])
    p.add_argument('--environment',action='append',default=[])
    a=p.parse_args();out=Path(a.out);out.mkdir(parents=True,exist_ok=True)
    result,histories,cfgs=evaluate_batch(a.batch)
    write_json(out/'comparison.json',result)
    if not result['comparison_ready']:
        raise SystemExit('Comparison withheld; inspect comparison.json audits')
    numerical={};environment={}
    for args,target in [(a.numerical,numerical),(a.environment,environment)]:
        for item in args:
            label,path=item.split('=',1)
            if label in target:raise ValueError('Duplicate sensitivity label')
            value,_,_=evaluate_batch(path)
            if not value['comparison_ready']:raise ValueError('Sensitivity batch failed audit')
            target[label]=value
    sensitivity=compare_sensitivity(result,numerical) if numerical else None
    if sensitivity:
        write_json(out/'sensitivity.json',sensitivity)
        write_csv(out/'sensitivity_changes.csv',sensitivity['changes'])
        supported=all(pair['rank_supported_by_screen'] for pair in sensitivity['pairwise'])
        result['ranking_status']='selected pair passed observed-change screen' if supported else 'ranking withheld: numerical changes comparable to layout difference or order reversal'
        result['numerical_rank_screen_passed']=supported
        result['numerical_checked_ids']=sorted({pair[k] for pair in sensitivity['pairwise'] for k in ('a','b')})
        write_json(out/'comparison.json',result)
        plot_sensitivity(result,numerical,out)
    write_json(out/'variant_comparisons.json',dict(numerical=numerical,environment=environment))
    write_csv(out/'comparison.csv',result['rows'])
    ports=[]
    for name,cfg in cfgs.items():
        h=histories[name];phi=cfg['slurry']['solid_volume_fraction']
        meta=cfg['layout_metadata'];total=meta['planned_dose']['carrier_water_m3']
        spacing=np.array(cfg['grid']['lengths_m'])/np.array(cfg['grid']['cells_xyz'])
        for i,(pid,port) in enumerate(zip(meta['port_ids'],cfg['ports'],strict=True)):
            water=float(h[f'port_{i+1}_water_m3'][-1])
            index=np.floor(np.array(port['position_m'])/spacing).astype(int)
            center=(index+.5)*spacing
            ports.append(dict(id=name,port=pid,x_m=port['position_m'][0],y_m=port['position_m'][1],z_m=port['position_m'][2],
                              cell_x=int(index[0]),cell_y=int(index[1]),cell_z=int(index[2]),
                              cell_center_distance_m=float(np.linalg.norm(center-port['position_m'])),
                              source_cell_volume_L_soil=float(np.prod(spacing)*1000),
                              water_mL=water*1e6,slurry_mL=water/(1-phi)*1e6,
                              dry_solid_mg=water/total*meta['planned_dose']['dry_solid_kg']*1e6,
                              water_fraction=water/total))
    write_csv(out/'port_delivery.csv',ports)
    plot_histories(histories,out);plot_ports(cfgs,result['rows'],out)
    make_report(result,sensitivity,environment,out)
    make_html(out)
    print(json.dumps(dict(comparison_ready=result['comparison_ready'],output=str(out),
                         reaction_order=[r['id'] for r in sorted(result['rows'],key=lambda r:r['reaction_rank'] or 999)])))


if __name__=='__main__':main()
