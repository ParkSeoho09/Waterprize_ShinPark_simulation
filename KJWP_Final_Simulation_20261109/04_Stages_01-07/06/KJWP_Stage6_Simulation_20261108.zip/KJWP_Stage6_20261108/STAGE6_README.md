# KJWP Stage 6 사용 안내

단계명은 **6. 배치별 정량 성능 비교**다. 기존 7단계의 순서와 의미는 `docs/ROADMAP.md`를 따른다.

## 확인할 파일

- `STAGE6_STATUS.json`: 실제 실행/검증 완료 상태. 구현과 결과 완료를 구분한다.
- `stage6_runs/primary_recovered/`: 대표 5개 후보와 무주입 대조군의 48시간 원본 결과.
- `stage6_results/primary/REPORT.html`: 완료된 기준 6개 케이스의 48시간 비교.
- `stage6_runs/campaign_recovered/report/REPORT.html`: 수치·환경 민감도를 연결한 최종 보고서. 계산이 완료된 뒤 생성된다.
- `stage6_runs/campaign_recovered/report/comparison.csv`: 정량 비교표. 원본 단위는 열 이름에 명시한다.
- `stage6_runs/campaign_recovered/report/port_delivery.csv`: 48개 출구별 공급량, 셀 매핑, 실제 좌표와 셀 중심 간 거리.
- `stage6_runs/campaign_recovered/report/comparison.json`: 비교 허용 여부, 검사 실패 이유, 입력 해시 및 최대 수지 잔차.
- `stage6_runs/campaign_recovered/report/sensitivity.json`: 관측한 수치 변화와 순위 판단.
- `docs/STAGE6_METHODS.md`: 지표 정의와 한계.
- `stage6_results/regression.log`: 실제 자동시험 로그.
- `stage6_results/engine_preservation.json`: 이전 수송·수리·반응 엔진 소스의 보존 검사.

완료 전에는 위 결과 파일 일부가 없다. 중간 로그나 입력 파일만 존재하는 케이스는 완료로 해석하지 않는다. 초기 420초 실행은 `stage6_preflight/`에 있으며 48시간 비교가 아니다.

## 전체 재현

Python 3.12 환경에서 프로젝트 폴더로 이동한 뒤 실행한다.

```bash
python -m pip install -r requirements-stage3.txt
python run_stage6_campaign.py --out stage6_runs/new_campaign --workers 3
```

이 명령은 기준 6개 실행 → 비교 검사 → 반응량 상위 2개 선정 → 대조군 포함 시간 간격/격자 검사 → 활성 0.25 시나리오 → 보고서 생성 순서로 진행한다. 동시 실행은 기준 최대 3개, 두 수치 검사 묶음에서 합계 최대 6개다. CPU/메모리가 작은 장비는 `--workers 1`로 줄일 수 있다. 실제 소요시간은 반응 계산량과 장비에 따라 크게 달라진다.

## 완료 결과로 분석만 재생성

```bash
python evaluate_stage6.py stage6_runs/primary_recovered --out stage6_results/reanalysis \
  --numerical half_dt=stage6_runs/campaign_recovered/half_dt \
  --numerical fine_combined=stage6_runs/campaign_recovered/fine_combined \
  --environment activity_025=stage6_runs/campaign_recovered/activity_025
```

민감도 실행이 아직 완료되지 않았다면 해당 인수를 생략한다. 이 경우 보고서는 수치 안정성 미확인으로 표시한다. 검증에 실패한 결과는 순위를 생성하지 않는다.

## 완료 케이스 재사용과 중단 처리

```bash
python run_stage6.py configs/stage6/batch_primary.json --out stage6_runs/existing_completed --resume --workers 3
```

`--resume`은 완료 케이스를 감사 후 재사용하고, 미완료 케이스는 `checkpoint.npz`에서 복구한다. 입력 및 솔버 소스 해시가 모두 같아야 한다. 저장은 수리 시간 단계가 완전히 수락된 뒤 5단계마다 원자적으로 수행하며 물·성분·입자·반응·추적자 모멘트·투입 장부와 기존 시간 기록/스냅샷을 함께 보존한다. pickle을 사용하지 않는다. 180초 이내에 실행 상태가 갱신된 작업에는 중복 실행 방지를 위해 재접속을 거부한다.

```bash
python run_stage6_campaign.py --out stage6_runs/campaign_recovered \
  --primary-existing stage6_runs/primary_recovered --resume --workers 3
```

체크포인트 기능 추가 전 중단된 결과에는 `checkpoint.npz`가 없어 부분 시간 복구가 불가능하다. 그런 케이스만 새로 계산한다. 코드나 입력을 수정한 뒤 기존 체크포인트를 강제로 복원하지 않는다. 기존 물리 시간 단계와 반응 계산식은 유지했으며, 주입 전·후 중단 검증에서 모든 시간 기록과 3D 배열이 연속 실행과 정확히 같았다.

각 실행의 `heartbeat.json`은 20초마다 갱신된다. `progress.jsonl`은 25개 수리 단계마다 모의시간을 기록한다. `checkpoint.json`은 마지막 복구 가능 시각을 표시한다. 파일이 존재한다는 사실만으로 실행 중이라 판단하지 않고 갱신 시각도 함께 확인한다. `summary.json`·`history.csv`·`fields.npz`가 모두 저장되고 감사를 통과해야 완료다.

## 연구에서 쓸 때

정량 비교 기능의 구현과 최적 배치 입증은 다르다. 비용 단가와 실제 펌프 소비전력은 입력되지 않아 미산정이다. 접촉 가능성 지표, 반응 제거량, 바닥 유출량을 혼동하지 않는다. 생성만 한 산소·추가 격자 시나리오는 실제 실행 결과로 보고하지 않는다. 본 계산은 실험/현장 보정이나 Stage 7 UI 완료를 뜻하지 않는다.

## 빠른 반응 모드

```bash
python run_stage6.py configs/stage6/batch_primary.json --out stage6_runs/fast_benchmark --fast --workers 3
python evaluate_stage6.py stage6_runs/fast_benchmark --out stage6_results/fast_benchmark
python compare_stage6_screening.py stage6_runs/primary_recovered stage6_runs/fast_benchmark --out stage6_results/fast_benchmark
```

`--fast`는 고정 초기 pH 인자를 적용한 Monod 반응을 후진 오일러로 적분한다.
용액 초기 조성에는 PHREEQC를 사용하고, 시간 단계별 종분화와 방해석 용해는 생략한다.
수리, 수송, 투입 종료, 용존산소·활성 시나리오, 황-질산염 화학양론, 수지 감사는 공통 경로를 사용한다.
빠른 출력에서 pH·알칼리도 격자장은 제공되지 않으며 황산염은 화학양론 결과로 해석한다.
`--resume`으로 재개할 때도 `--fast`와 동일한 입력을 사용한다. 빠른 솔버 소스 해시를 입력에 포함한다.
비교 스크립트는 대응하는 케이스의 원본 입력과 질량수지 검사를 확인하고 반응량·바닥 유출량·실행시간을 내보낸다.
대표 케이스 비교는 스테이지 6 기능 검증용이다. 최종 배치 결정은 스테이지 7 이후로 둔다.
