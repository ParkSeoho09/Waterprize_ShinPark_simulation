"""Resumable Stage 6 execution with independent worker processes.

Completed outputs are audited before reuse. Interrupted jobs resume only from
atomic checkpoints with matching input and solver source hashes.
"""
import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
import hashlib
import json
from pathlib import Path
import threading
import time

from kjwp_stage1.layout import compile_layout
from kjwp_stage1.reactive_transport import solve
from run_layout_batch import write_json, summarize_run


def run_one(name, cfg, folder, resume_checkpoint=False):
    folder=Path(folder)
    solver = solve
    if 'screening_solver_sha256' in cfg:
        from stage6_screening import solve as screening_solve
        solver = screening_solve
    stopped=threading.Event();latest={};started=time.time()
    def heartbeat():
        while not stopped.is_set():
            write_json(folder/'heartbeat.json',dict(job=name,unix_time=time.time(),elapsed_s=time.time()-started,
                       state='running',last_progress=latest.copy()))
            stopped.wait(20)
    thread=threading.Thread(target=heartbeat,daemon=True);thread.start()
    try:
        with (folder/'progress.jsonl').open('a' if resume_checkpoint else 'w',encoding='utf-8',buffering=1) as stream:
            def progress(value):
                latest.update(value)
                stream.write(json.dumps(dict(job=name,**value))+'\n')
            checkpoint=folder/'checkpoint.npz'
            result=solver(cfg,folder,progress,checkpoint=checkpoint,
                         resume=checkpoint if resume_checkpoint else None,checkpoint_steps=5)
    finally:
        stopped.set();thread.join()
        write_json(folder/'heartbeat.json',dict(job=name,unix_time=time.time(),elapsed_s=time.time()-started,
                   state='finished' if all((folder/f).exists() for f in ('summary.json','history.csv','fields.npz')) else 'stopped',last_progress=latest))
    return summarize_run(result['summary'],cfg['layout_metadata'])


def run(manifest, out, workers=1, resume=False, fast=False):
    if workers<1:raise ValueError('workers must be positive')
    manifest=Path(manifest).resolve();data=json.loads(manifest.read_text())
    if data.get('schema_version')!=1:raise ValueError('Invalid manifest schema')
    base=json.loads((manifest.parent/data['base']).read_text())
    if fast:
        base['screening_solver_sha256'] = hashlib.sha256(
            Path(__file__).with_name('stage6_screening.py').read_bytes()).hexdigest()
    rows=[];configs={};planned=None;names=set();checkpoints=set()
    for job in data['jobs']:
        name=job['id']
        if not name or name.casefold() in names or any(c not in 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-' for c in name):
            raise ValueError('Invalid or duplicate job id')
        names.add(name.casefold())
        cfg=compile_layout(base,json.loads((manifest.parent/job['layout']).read_text()))
        meta=cfg['layout_metadata']
        if meta['kind']=='injection':
            if planned is not None and planned!=meta['planned_dose']:raise ValueError('Unequal planned dose')
            planned=meta['planned_dose']
        raw=json.dumps(cfg,ensure_ascii=False,sort_keys=True,indent=2)+'\n'
        configs[name]=cfg
        rows.append(dict(id=name,kind=meta['kind'],status='pending',
                         input_sha256=hashlib.sha256(raw.encode()).hexdigest(),
                         planned_dose=meta['planned_dose'],shared_cells=meta['shared_cells']))
    if not rows:raise ValueError('Empty batch')
    out=Path(out)
    if out.exists() and not resume:
        previous=out/'batch_summary.json'
        if previous.exists():
            cached=json.loads(previous.read_text())
            if cached['all_requested_jobs_finished'] and [r['id'] for r in cached['jobs']]==[r['id'] for r in rows]:
                # A completed external run may have satisfied a queued campaign job.
                # Reuse only after the same full input/result audit as --resume.
                return run(manifest,out,workers=workers,resume=True,fast=fast)
        raise FileExistsError(out)
    out.mkdir(parents=True,exist_ok=True)
    # Check every reuse before writing a new batch summary.
    for row in rows:
        folder=out/row['id']
        if folder.exists():
            if not resume:raise FileExistsError(folder)
            from kjwp_stage1.evaluation import audit_run
            if all((folder/f).exists() for f in ('summary.json','history.csv','fields.npz','input.json')):
                audit,cfg,summary,_=audit_run(folder)
                if not audit['passed'] or audit['input_sha256']!=row['input_sha256']:
                    raise ValueError(f'Cannot reuse {row["id"]}: mismatched or invalid completed output')
                row.update(summarize_run(summary,cfg['layout_metadata']))
            elif (folder/'checkpoint.npz').exists():
                from kjwp_stage1.checkpoint import load_checkpoint
                heartbeat=folder/'heartbeat.json'
                if heartbeat.exists():
                    value=json.loads(heartbeat.read_text())
                    if value['state']=='running' and time.time()-value['unix_time']<180:
                        raise ValueError(f'Job {row["id"]} still appears active; will not duplicate it')
                load_checkpoint(folder/'checkpoint.npz',configs[row['id']])
                checkpoints.add(row['id'])
            else:
                raise ValueError(f'Cannot reuse {row["id"]}: no complete output or checkpoint')

    def save():
        done=all(r['status']=='finished' for r in rows)
        ready=done and sum(r['kind']=='injection' for r in rows)>=2 and all(r['dose_completed'] and r['actual_dose_matches_plan'] for r in rows)
        write_json(out/'batch_summary.json',dict(schema_version=1,jobs=rows,
                   requested_job_count=len(rows),all_requested_jobs_finished=done,comparison_ready=ready))
    save()
    with ProcessPoolExecutor(max_workers=workers) as pool:
        futures={}
        for row in rows:
            if row['status']=='finished':continue
            folder=out/row['id'];folder.mkdir(exist_ok=row['id'] in checkpoints)
            write_json(folder/'compiled_input.json',configs[row['id']])
            row['status']='running'
            futures[pool.submit(run_one,row['id'],configs[row['id']],str(folder),row['id'] in checkpoints)]=row
        save()
        for future in as_completed(futures):
            row=futures[future]
            try:row.update(future.result())
            except Exception as exc:row.update(status='failed',error=str(exc))
            save();print(json.dumps(dict(id=row['id'],status=row['status'])),flush=True)
    if any(r['status']!='finished' for r in rows):raise RuntimeError('Some jobs failed; inspect batch_summary.json')
    return rows


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('manifest');p.add_argument('--out',required=True)
    p.add_argument('--workers',type=int,default=1);p.add_argument('--resume',action='store_true')
    p.add_argument('--fast', action='store_true', help='Use fixed-pH Monod screening chemistry')
    a=p.parse_args();run(a.manifest,a.out,a.workers,a.resume,a.fast)
