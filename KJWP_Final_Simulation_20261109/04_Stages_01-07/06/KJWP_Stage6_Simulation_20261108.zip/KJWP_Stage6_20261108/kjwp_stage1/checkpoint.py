"""Atomic, non-pickle checkpoints for accepted transport states only."""
import hashlib
import json
from pathlib import Path
import numpy as np


def input_digest(config):
    return hashlib.sha256((json.dumps(config,ensure_ascii=False,sort_keys=True,indent=2)+'\n').encode()).hexdigest()


def solver_digest():
    root=Path(__file__).parent
    digest=hashlib.sha256()
    for p in sorted(root.rglob('*.py')):
        if p.name=='evaluation.py':continue
        digest.update(str(p.relative_to(root)).encode());digest.update(p.read_bytes())
    return digest.hexdigest()


def write_checkpoint(path, config, state):
    arrays={}
    def encode(value):
        if isinstance(value,np.ndarray):
            key=f'array_{len(arrays)}';arrays[key]=value;return {'__array__':key}
        if isinstance(value,dict):return {k:encode(v) for k,v in value.items()}
        if isinstance(value,(list,tuple)):return [encode(v) for v in value]
        if isinstance(value,np.generic):return value.item()
        return value
    data=dict(schema_version=1,input_sha256=input_digest(config),solver_sha256=solver_digest(),state=encode(state))
    arrays['metadata']=np.asarray(json.dumps(data,allow_nan=False,separators=(',',':')))
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    temporary=path.with_suffix('.tmp')
    with temporary.open('wb') as stream:np.savez_compressed(stream,**arrays)
    temporary.replace(path)
    status=path.with_suffix('.json');tmp=status.with_suffix('.tmp')
    tmp.write_text(json.dumps(dict(time_s=state['t'],steps=state['count'],input_sha256=data['input_sha256'])))
    tmp.replace(status)


def load_checkpoint(path, config):
    with np.load(path,allow_pickle=False) as arrays:
        data=json.loads(str(arrays['metadata']))
        if data['schema_version']!=1:raise ValueError('Checkpoint schema mismatch')
        if data['input_sha256']!=input_digest(config):raise ValueError('Checkpoint input mismatch')
        if data['solver_sha256']!=solver_digest():raise ValueError('Checkpoint solver source mismatch')
        def decode(value):
            if isinstance(value,dict):
                if set(value)=={'__array__'}:return arrays[value['__array__']].copy()
                return {k:decode(v) for k,v in value.items()}
            if isinstance(value,list):return [decode(v) for v in value]
            return value
        return decode(data['state'])
