"""Stage 6 audit and comparison of completed Stage 4/5 output.

All performance metrics are derived from saved histories/fields. No solver
physics is changed here. A rank is descriptive, never an optimum claim.
"""
import csv
import hashlib
import json
import math
from pathlib import Path

import numpy as np

SPECIES = ('NO3', 'NO3_passive', 'tracer', 'sulfur', 'caco3', 'SO4', 'Ca', 'DIC', 'Na', 'Cl')
CONTACT_THRESHOLD_KG_M3_SOIL = 1e-10
BALANCE_RTOL = 1e-8
MASS_ATOL_KG = 1e-10
WATER_ATOL_M3 = 1e-9


def read_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def history(path):
    with Path(path).open(newline='', encoding='utf-8') as stream:
        rows = list(csv.DictReader(stream))
    if not rows:
        raise ValueError('Empty history')
    return {key: np.asarray([r[key] for r in rows], dtype=float) for key in rows[0]}


def common_conditions(cfg):
    """Exclude geometry and its dose switch, retain all physical/numerical forcing."""
    return {k: v for k, v in cfg.items() if k not in
            ('ports', 'layout_metadata', 'target_dry_solid_kg', 'no_injection', 'case_name')}


def physical_conditions(cfg):
    common = common_conditions(cfg)
    common['grid'] = {'lengths_m': common['grid']['lengths_m']}
    return {k:v for k,v in common.items() if k not in ('max_dt_s','time_step_schedule')}


def audit_run(folder):
    folder = Path(folder)
    cfg = read_json(folder/'input.json')
    summary = read_json(folder/'summary.json')
    h = history(folder/'history.csv')
    meta = cfg['layout_metadata']
    errors = []
    check = lambda ok, message: errors.append(message) if not ok else None
    digest = hashlib.sha256((folder/'input.json').read_bytes()).hexdigest()
    check(digest == summary['input_sha256'], 'input hash mismatch')
    check(all(np.isfinite(v).all() for v in h.values()), 'nonfinite history')
    check(np.all(np.diff(h['time_s']) > 0), 'non-increasing history times')
    check(math.isclose(h['time_s'][-1], cfg['end_s'], abs_tol=1e-7), 'incomplete duration')
    check(h['time_s'][0] == 0, 'missing initial state')
    for endpoint, idx in [('initial', 0), ('final', -1)]:
        check(all(math.isclose(float(h[k][idx]), float(v), rel_tol=1e-12, abs_tol=1e-15)
                  for k, v in summary[endpoint].items()), f'{endpoint} summary/history mismatch')
    dose = summary['dose']
    water = np.asarray(summary['port_water_m3'])
    check(len(water) == len(meta['port_ids']) == len(cfg['ports']), 'port count mismatch')
    check(np.isfinite(water).all() and np.all(water >= 0), 'invalid port water')
    check(all(math.isclose(float(v),float(h[f'port_{i+1}_water_m3'][-1]),rel_tol=1e-12,abs_tol=1e-15)
              for i,v in enumerate(water)), 'port summary/history mismatch')
    check(dose['done'], 'dose incomplete')
    for actual, planned, name in [
        (dose['injected_dry_solid_kg'], meta['planned_dose']['dry_solid_kg'], 'solid'),
        (math.fsum(water), meta['planned_dose']['carrier_water_m3'], 'carrier water'),
    ]:
        check(math.isclose(actual, planned, rel_tol=2e-12, abs_tol=0), f'{name} dose mismatch')
    check(not meta['shared_cells'], 'shared outlet cells: resolve before ranking')
    budget = {}
    for s in SPECIES:
        scale = np.maximum(h[s+'_stored_kg'][0] + h[s+'_in_kg'] + np.abs(h[s+'_reaction_net_kg']), MASS_ATOL_KG)
        residual = np.abs(h[s+'_residual_kg'])
        reconstructed = h[s+'_stored_kg']-h[s+'_stored_kg'][0]-h[s+'_in_kg']+h[s+'_out_kg']-h[s+'_reaction_net_kg']
        check(np.allclose(reconstructed,h[s+'_residual_kg'],rtol=0,atol=1e-13), f'{s} inconsistent residual ledger')
        ok = bool(np.all(residual <= MASS_ATOL_KG + BALANCE_RTOL*scale))
        check(ok, f'{s} mass balance failure')
        check(np.min(h[s+'_min_kg_m3']) >= -1e-12, f'{s} negative concentration')
        budget[s+'_max_abs_residual_kg'] = float(np.max(residual))
    wr = np.abs(h['water_residual_m3'])
    reconstructed = h['water_stored_m3']-h['water_stored_m3'][0]-h['water_in_m3']+h['water_out_m3']
    check(np.allclose(reconstructed,h['water_residual_m3'],rtol=0,atol=1e-13), 'inconsistent water residual ledger')
    check(np.all(wr <= WATER_ATOL_M3 + BALANCE_RTOL*(h['water_stored_m3'][0]+h['water_in_m3'])), 'water balance failure')
    budget['water_max_abs_residual_m3'] = float(wr.max())
    shadow = h['NO3_passive_stored_kg'] - h['NO3_stored_kg'] + h['NO3_passive_out_kg'] - h['NO3_out_kg'] - h['NO3_reacted_kg']
    check(np.max(np.abs(shadow)) <= MASS_ATOL_KG + BALANCE_RTOL*(h['NO3_stored_kg'][0]+h['NO3_in_kg'][-1]), 'passive/reaction identity failure')
    budget['passive_identity_max_abs_residual_kg'] = float(np.max(np.abs(shadow)))
    # Molecular weights/stoichiometry match the reaction engine's exported constants.
    from .geochemistry import MW_NO3, MW_SO4
    so4_expected = h['NO3_reacted_kg']*(5/6)*MW_SO4/MW_NO3
    check(np.allclose(h['SO4_reaction_net_kg'], so4_expected, rtol=1e-10, atol=MASS_ATOL_KG), 'sulfate stoichiometry mismatch')
    for species in ('sulfur','caco3'):
        check(math.isclose(float(h[species+'_inlet_kg'][-1]),dose['component_injected_kg'][species],rel_tol=2e-12,abs_tol=1e-15),
              f'{species} inlet/dose mismatch')
    with np.load(folder/'fields.npz') as fields:
        volume=math.prod(cfg['grid']['lengths_m'])/math.prod(cfg['grid']['cells_xyz'])
        theta=fields['theta'][-1]
        check(theta.shape==tuple(reversed(cfg['grid']['cells_xyz'])), 'field/grid shape mismatch')
        for species in SPECIES:
            inventory=theta*fields[species+'_kg_m3_carrier'][-1]
            if species in ('sulfur','caco3'):
                inventory=inventory+fields[species+'_attached_kg_m3_soil'][-1]+fields[species+'_strained_kg_m3_soil'][-1]
            check(math.isclose(float(inventory.sum()*volume),float(h[species+'_stored_kg'][-1]),rel_tol=1e-10,abs_tol=1e-13),
                  f'{species} field/history mismatch')
    return dict(passed=not errors, errors=errors, budgets=budget, input_sha256=digest), cfg, summary, h


def field_metrics(folder, cfg):
    """Co-location proxy and tracer moment diagnostics, not nitrate contact efficiency."""
    with np.load(Path(folder)/'fields.npz') as f:
        if not all(np.isfinite(f[k]).all() for k in f.files):
            raise ValueError(f'Nonfinite fields: {folder}')
        if not math.isclose(float(f['time_s'][-1]), cfg['end_s'], abs_tol=1e-7):
            raise ValueError('Final snapshot missing')
        theta = f['theta'][-1]
        volume = math.prod(cfg['grid']['lengths_m'])/math.prod(cfg['grid']['cells_xyz'])
        solid = sum(theta*f[s+'_kg_m3_carrier'][-1] + f[s+'_attached_kg_m3_soil'][-1] +
                    f[s+'_strained_kg_m3_soil'][-1] for s in ('sulfur', 'caco3'))
        contact = solid > CONTACT_THRESHOLD_KG_M3_SOIL
        nitrate = theta*f['NO3_kg_m3_carrier'][-1]*volume
        tracer = theta*f['tracer_kg_m3_carrier'][-1]*volume
        tracer_total = float(tracer.sum())
        mean = lambda key: float(np.sum(tracer*f[key][-1])/tracer_total) if tracer_total > 0 else None
        water = theta*volume
        return dict(
            final_reagent_cell_volume_fraction=float(contact.mean()),
            final_remaining_NO3_colocated_fraction=float(nitrate[contact].sum()/nitrate.sum()) if nitrate.sum()>0 else None,
            colocated_threshold_kg_m3_soil=CONTACT_THRESHOLD_KG_M3_SOIL,
            retained_tracer_mean_age_h=mean('injected_tracer_mean_age_h'),
            retained_tracer_mean_reagent_exposure_h=mean('injected_tracer_mean_exposure_h'),
            final_pH_min=float(f['pH'][-1].min()) if 'pH' in f else None,
            final_pH_max=float(f['pH'][-1].max()) if 'pH' in f else None,
            final_SO4_max_mg_L=float(f['SO4_kg_m3_carrier'][-1].max()*1000),
            final_SO4_water_weighted_mg_L=float(np.sum(water*f['SO4_kg_m3_carrier'][-1])/water.sum()*1000),
            final_Ca_max_mg_L=float(f['Ca_kg_m3_carrier'][-1].max()*1000),
        )


def evaluate_batch(folder):
    folder = Path(folder)
    batch = read_json(folder/'batch_summary.json')
    if not batch['all_requested_jobs_finished'] or len(batch['jobs']) != batch['requested_job_count']:
        raise ValueError('All requested jobs must finish before evaluation')
    ids = [j['id'] for j in batch['jobs']]
    if len(set(ids)) != len(ids):
        raise ValueError('Duplicate job IDs')
    rows, audits, histories, cfgs = [], {}, {}, {}
    for job in batch['jobs']:
        if job['status'] != 'finished':
            raise ValueError('Unfinished job')
        name = job['id']
        audit, cfg, s, h = audit_run(folder/name)
        audits[name], histories[name], cfgs[name] = audit, h, cfg
        meta, final = cfg['layout_metadata'], s['final']
        if job['input_sha256'] != audit['input_sha256']:
            audit['errors'].append('batch/input hash mismatch')
            audit['passed'] = False
        available = s['initial']['NO3_stored_kg']+final['NO3_in_kg']
        water = np.asarray(s['port_water_m3'])
        injected = s['dose']['injected_dry_solid_kg']
        carrier = math.fsum(water)
        phi = cfg['slurry']['solid_volume_fraction']
        # Hydraulic work at specified outlets; pump and pipe losses are not modeled.
        outlet_work = sum(v*p['outlet_gauge_pressure_Pa']/(1-phi) for v, p in zip(water, cfg['ports'], strict=True))
        row = dict(id=name, kind=meta['kind'], duration_h=cfg['end_s']/3600,
                   pipe_assembly_count=len(meta['original_layout'].get('pipes',[])),
                   pipe_body_total_length_m=math.fsum(p['body_length_m'] for p in meta['original_layout'].get('pipes',[])),
                   dry_solid_g=injected*1000, carrier_water_mL=carrier*1e6,
                   sulfur_g=s['dose']['component_injected_kg']['sulfur']*1000,
                   CaCO3_g=s['dose']['component_injected_kg']['caco3']*1000,
                   injection_completion_s=s['injection_completion_s'],
                   NO3_initial_mg=s['initial']['NO3_stored_kg']*1e6,
                   NO3_entered_mg=final['NO3_in_kg']*1e6,
                   NO3_available_mg=available*1e6,
                   NO3_reacted_mg=final['NO3_reacted_kg']*1e6,
                   NO3_reacted_percent=final['NO3_reacted_kg']/available*100 if available else None,
                   NO3_bottom_out_mg=final['NO3_bottom_out_kg']*1e6,
                   NO3_all_out_mg=final['NO3_out_kg']*1e6,
                   NO3_remaining_mg=final['NO3_stored_kg']*1e6,
                   NO3_passive_bottom_out_mg=final['NO3_passive_bottom_out_kg']*1e6,
                   same_flow_bottom_reaction_difference_mg=(final['NO3_passive_bottom_out_kg']-final['NO3_bottom_out_kg'])*1e6,
                   SO4_generated_mg=final['SO4_reaction_net_kg']*1e6,
                   Ca_generated_mg=final['Ca_reaction_net_kg']*1e6,
                   outlet_pressure_work_J=float(outlet_work),
                   material_cost=None, pump_energy_J=None,
                   port_volume_cv=float(water.std()/water.mean()) if len(water) and water.mean()>0 else None,
                   port_volume_min_mL=float(water.min()*1e6) if len(water) else None,
                   port_volume_max_mL=float(water.max()*1e6) if len(water) else None,
                   **field_metrics(folder/name, cfg))
        rows.append(row)
    common = common_conditions(next(iter(cfgs.values())))
    common_ok = all(common_conditions(c) == common for c in cfgs.values())
    injected = [r for r in rows if r['kind']=='injection']
    controls = [r for r in rows if r['kind']=='no_injection']
    dose_equal = bool(injected) and all(
        math.isclose(r[k], injected[0][k], rel_tol=2e-12, abs_tol=0)
        for r in injected for k in ('dry_solid_g','carrier_water_mL','sulfur_g','CaCO3_g'))
    ready = all(a['passed'] for a in audits.values()) and common_ok and dose_equal and len(injected)>=2 and len(controls)==1
    control = controls[0] if len(controls)==1 else None
    for r in rows:
        r['control_bottom_difference_mg'] = control['NO3_bottom_out_mg']-r['NO3_bottom_out_mg'] if control else None
        r['control_bottom_difference_percent'] = (100*r['control_bottom_difference_mg']/control['NO3_bottom_out_mg']) if control and control['NO3_bottom_out_mg']>0 else None
        r['reaction_rank'] = None
    if ready:
        for rank, row in enumerate(sorted(injected, key=lambda r: (-r['NO3_reacted_mg'],r['id'])),1):
            row['reaction_rank'] = rank
    result = dict(schema_version=1, stage=6, evaluation_version='0.6.0', comparison_ready=ready,
                  physical_conditions=physical_conditions(next(iter(cfgs.values()))),
                  numerical_settings={k:next(iter(cfgs.values())).get(k) for k in ('grid','max_dt_s','time_step_schedule')},
                  original_layouts={name:c['layout_metadata']['original_layout'] for name,c in cfgs.items()},
                  common_conditions_match=common_ok, equal_injected_dose=dose_equal,
                  unique_no_injection_control=len(controls)==1,
                  ranking_status='exploratory; numerical robustness pending' if ready else 'withheld',
                  balance_tolerances=dict(relative=BALANCE_RTOL,mass_absolute_kg=MASS_ATOL_KG,water_absolute_m3=WATER_ATOL_M3),
                  audits=audits, rows=rows)
    return result, histories, cfgs


def compare_sensitivity(primary, variants):
    """Conservative observed-change screen; not a convergence proof/error bound."""
    base = {r['id']:r for r in primary['rows'] if r['kind']=='injection'}
    selected = sorted(set.intersection(*(set(r['id'] for r in v['rows'] if r['kind']=='injection') for v in variants.values()))) if variants else []
    if len(selected)<2:
        raise ValueError('Sensitivity needs at least two common injection candidates')
    if not primary['comparison_ready'] or not all(v['comparison_ready'] for v in variants.values()):
        raise ValueError('Sensitivity comparison contains an invalid batch')
    for value in variants.values():
        if value['physical_conditions'] != primary['physical_conditions']:
            raise ValueError('Numerical comparison changed physical conditions')
        for name in selected:
            if value['original_layouts'][name] != primary['original_layouts'][name]:
                raise ValueError('Numerical comparison changed layout geometry')
    metrics = ('NO3_reacted_mg','NO3_bottom_out_mg','control_bottom_difference_mg')
    changes = []
    envelopes = {name:{m:0. for m in metrics} for name in selected}
    for label,v in variants.items():
        for r in v['rows']:
            if r['id'] not in selected: continue
            for m in metrics:
                delta = r[m]-base[r['id']][m]
                envelopes[r['id']][m] = max(envelopes[r['id']][m],abs(delta))
                changes.append(dict(variant=label,id=r['id'],metric=m,primary=base[r['id']][m],variant_value=r[m],delta=delta))
    pairs=[]
    for i,a in enumerate(selected):
        for b in selected[i+1:]:
            gap=base[a]['NO3_reacted_mg']-base[b]['NO3_reacted_mg']
            numerical_change=envelopes[a]['NO3_reacted_mg']+envelopes[b]['NO3_reacted_mg']
            same_sign=all((next(r for r in v['rows'] if r['id']==a)['NO3_reacted_mg']-
                           next(r for r in v['rows'] if r['id']==b)['NO3_reacted_mg'])*gap>0 for v in variants.values())
            supported=same_sign and abs(gap)>numerical_change
            pairs.append(dict(a=a,b=b,primary_reaction_gap_mg=gap,
                              summed_observed_numerical_change_mg=numerical_change,
                              order_preserved=same_sign,rank_supported_by_screen=supported))
    controls=[]
    for label,value in {'primary':primary,**variants}.items():
        control=next(r for r in value['rows'] if r['kind']=='no_injection')
        controls.append(dict(variant=label,NO3_initial_mg=control['NO3_initial_mg'],
                             NO3_bottom_out_mg=control['NO3_bottom_out_mg'],numerical_settings=value['numerical_settings']))
    return dict(changes=changes,pairwise=pairs,control_checks=controls,
                interpretation='Observed differences only; two grids do not establish spatial convergence. Unchecked candidates remain unranked for robustness.')
