"""Stage 6 fast chemistry for comparative screening on the existing flow grid."""
import math

import numpy as np

from kjwp_stage1 import stage2
from kjwp_stage1.geochemistry import MW_N
from kjwp_stage1.reactive_transport import ReactiveCoupling


class ScreeningCoupling(ReactiveCoupling):
    def __init__(self, config):
        super().__init__(config)
        self.cell.advance = self.advance_cell

    def advance_cell(self, components, sulfur, calcite, dt_s, environment, biomass):
        nitrate = components[0]
        capacity = min(nitrate, sulfur * 6 / 5)
        if capacity <= 1e-14 or not environment["in_contact"]:
            return (0.0, 0.0)
        chemistry = self.batch
        ph_factor = 1.0
        if chemistry.pH_inhibition:
            ph_factor = min(1.0, max(0.0, (chemistry.initial_pH - chemistry.pH_stop)
                                     / (chemistry.pH_full - chemistry.pH_stop)))
        demand = (chemistry.k_per_day * biomass / (MW_N * 1000) * dt_s / 86400
                  * environment["active_fraction"] * environment["oxygen_factor"] * ph_factor)
        half_saturation = chemistry.ks_mg_N_L * (chemistry.kinetic_volume_L_per_kgw or 1.0) / (MW_N * 1000)
        # Backward Euler Monod step, solved for the smaller root in the extent.
        total = nitrate + half_saturation + demand
        discriminant = (nitrate - demand)**2 + half_saturation * (2 * (nitrate + demand) + half_saturation)
        extent = 2 * demand * nitrate / (total + math.sqrt(discriminant))
        return (min(capacity, extent), 0.0)

    def snapshot(self, theta, concentrations):
        tracer = concentrations["tracer"]

        def tracer_hours(moment):
            return np.divide(moment, tracer, out=np.zeros_like(tracer), where=tracer > 1e-12) / 3600

        return dict(NO3_reacted_kg_cell=self.local_reacted.copy(),
                    reagent_presence_hours=self.contact_time / 3600,
                    injected_tracer_mean_age_h=tracer_hours(self.age),
                    injected_tracer_mean_exposure_h=tracer_hours(self.exposure),
                    tracer_age_moment_kg_s_m3=self.age.copy(),
                    tracer_exposure_moment_kg_s_m3=self.exposure.copy())

    def summary(self):
        summary = super().summary()
        summary.update(model="stage6_screening_fixed_ph_monod_v1",
                       limitations=summary["limitations"] + [
                           "screening proxy: fixed initial pH factor; calcite dissolution omitted",
                           "sulfate is a stoichiometric ledger; pH and alkalinity fields are unavailable",
                           "PHREEQC is used only to initialize solution composition",
                       ])
        return summary


def solve(config, output=None, progress=None, **kwargs):
    return stage2.solve(config, output, progress, ScreeningCoupling(config), **kwargs)
