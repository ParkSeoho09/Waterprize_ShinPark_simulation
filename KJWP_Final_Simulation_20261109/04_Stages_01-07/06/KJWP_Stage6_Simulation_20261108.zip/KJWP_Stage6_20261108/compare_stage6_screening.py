"""Compare paired Stage 6 screening runs to saved PHREEQC runs."""
import argparse
import math
from pathlib import Path

from evaluate_stage6 import write_csv, write_json
from kjwp_stage1.evaluation import audit_run


def compare(reference, screening):
    rows = []
    for fast_input in sorted(screening.glob("*/input.json")):
        name = fast_input.parent.name
        fast_audit, fast_cfg, fast, _ = audit_run(fast_input.parent)
        ref_audit, ref_cfg, ref, _ = audit_run(reference / name)
        fast_id = fast_cfg.pop("screening_solver_sha256", None)
        if not (fast_audit["passed"] and ref_audit["passed"] and fast_id
                and fast["model"] == "stage6_screening_fixed_ph_monod_v1"
                and ref["model"] == "stage4_component_transport_phreeqc_v0.5.0"
                and fast_cfg == ref_cfg):
            raise ValueError(f"Failed audit or unmatched inputs for {name}")
        row = dict(id=name, kind=ref_cfg["layout_metadata"]["kind"],
                   ref_elapsed_s=ref["elapsed_s"], fast_elapsed_s=fast["elapsed_s"],
                   elapsed_ratio=ref["elapsed_s"] / fast["elapsed_s"])
        for label, run in (("ref", ref), ("fast", fast)):
            row[label + "_reacted_mg"] = run["final"]["NO3_reacted_kg"] * 1e6
            row[label + "_bottom_mg"] = run["final"]["NO3_bottom_out_kg"] * 1e6
        row["reaction_error_mg"] = row["fast_reacted_mg"] - row["ref_reacted_mg"]
        rows.append(row)
    if {p.parent.name for p in reference.glob("*/input.json")} != {r["id"] for r in rows}:
        raise ValueError("Benchmark requires every reference case")
    control, = [r for r in rows if r["kind"] == "no_injection"]
    candidates = [r for r in rows if r["kind"] == "injection"]
    if len(candidates) < 2:
        raise ValueError("Benchmark requires at least two injection layouts")
    for row in rows:
        for label in ("ref", "fast"):
            row[label + "_bottom_delta_mg"] = row[label + "_bottom_mg"] - control[label + "_bottom_mg"]
    orders = {label: [r["id"] for r in sorted(candidates, key=lambda r: (-r[label + "_reacted_mg"], r["id"]))]
              for label in ("ref", "fast")}
    return dict(rows=rows, reaction_orders=orders,
                top_two_overlap=len(set(orders["ref"][:2]) & set(orders["fast"][:2])),
                max_abs_reaction_error_mg=max(abs(r["reaction_error_mg"]) for r in candidates),
                bottom_delta_sign_agreements=sum(
                    (r["ref_bottom_delta_mg"] > 0) - (r["ref_bottom_delta_mg"] < 0)
                    == (r["fast_bottom_delta_mg"] > 0) - (r["fast_bottom_delta_mg"] < 0)
                    for r in candidates),
                aggregate_elapsed_ratio=(math.fsum(r["ref_elapsed_s"] for r in candidates)
                                         / math.fsum(r["fast_elapsed_s"] for r in candidates)))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("reference", type=Path)
    parser.add_argument("screening", type=Path)
    parser.add_argument("--out", required=True, type=Path)
    args = parser.parse_args()
    result = compare(args.reference, args.screening)
    args.out.mkdir(parents=True, exist_ok=True)
    write_csv(args.out / "screening_benchmark.csv", result["rows"])
    write_json(args.out / "screening_benchmark.json", result)
    print({k: v for k, v in result.items() if k != "rows"})


if __name__ == "__main__":
    main()
