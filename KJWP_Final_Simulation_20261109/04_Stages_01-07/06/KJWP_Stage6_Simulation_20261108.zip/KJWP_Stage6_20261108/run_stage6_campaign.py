"""Run the selected Stage 6 campaign through audited numerical/environment checks."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time

from kjwp_stage1.evaluation import evaluate_batch
from prepare_stage6_sensitivity import prepare
from run_stage6 import run

ROOT=Path(__file__).resolve().parent


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--out',required=True)
    p.add_argument('--manifest',default=str(ROOT/'configs/stage6/batch_primary.json'))
    p.add_argument('--primary-existing')
    p.add_argument('--wait-for-primary',action='store_true')
    p.add_argument('--precomputed-controls',help='Directory containing control_fine and control_half completed batches')
    p.add_argument('--workers',type=int,default=3)
    p.add_argument('--resume',action='store_true',help='Reuse audited completed jobs and resume matching checkpoints')
    a=p.parse_args();out=Path(a.out).resolve();out.mkdir(parents=True,exist_ok=a.resume)
    if a.resume and not a.primary_existing and (out/'campaign.json').exists():
        a.primary_existing=json.loads((out/'campaign.json').read_text())['primary']
    if a.primary_existing:
        primary=Path(a.primary_existing).resolve()
        if a.wait_for_primary:
            while True:
                batch=json.loads((primary/'batch_summary.json').read_text())
                if batch['all_requested_jobs_finished']:break
                if any(r['status']=='failed' for r in batch['jobs']):raise RuntimeError('Primary job failed')
                beats=list(primary.glob('*/heartbeat.json'))
                if any(time.time()-json.loads(b.read_text())['unix_time']>180 and json.loads(b.read_text())['state']=='running' for b in beats):
                    raise RuntimeError('Primary heartbeat stale; completed results are preserved')
                time.sleep(20)
    else:
        primary=out/'primary';run(a.manifest,primary,workers=a.workers,resume=a.resume)
    result,_,_=evaluate_batch(primary)
    if not result['comparison_ready']:raise RuntimeError('Primary audit failed')
    configs=out/'configs'
    if configs.exists() and a.resume:
        selection=json.loads((configs/'selection.json').read_text())
        hashes={k:v['input_sha256'] for k,v in result['audits'].items()}
        if selection['primary_input_sha256']!=hashes:raise ValueError('Primary inputs changed since selection')
        selected=selection['selected']
    else:selected=prepare(primary,a.manifest,configs)
    (out/'campaign.json').write_text(json.dumps(dict(status='running',selected=selected,primary=str(primary),
        executed_plan=['fine_combined','half_dt','activity_025'],
        planned_only=['fine_grid','oxygen_scenario']),indent=2)+'\n')
    print(json.dumps(dict(selected=selected)),flush=True)

    def execute(name):
        folder=out/name
        reuse=a.resume
        control_name={'fine_combined':'control_fine','half_dt':'control_half'}.get(name)
        if a.precomputed_controls and control_name:
            source=Path(a.precomputed_controls)/control_name/'CONTROL'
            if (source/'fields.npz').exists() and not (folder/'CONTROL').exists():
                folder.mkdir(exist_ok=a.resume);shutil.copytree(source,folder/'CONTROL');reuse=True
        command=[sys.executable,str(ROOT/'run_stage6.py'),str(configs/f'batch_{name}.json'),'--out',str(folder),'--workers',str(min(a.workers,3))]
        if reuse:command.append('--resume')
        with (out/f'{name}.log').open('w') as log:
            subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,cwd=ROOT)
        value,_,_=evaluate_batch(folder)
        if not value['comparison_ready']:raise RuntimeError(f'{name} audit failed')
        print(json.dumps(dict(variant=name,status='finished')),flush=True)
    # Spatial effects can be isolated at the half time step by comparing these two.
    with ThreadPoolExecutor(max_workers=2) as pool:
        futures=[pool.submit(execute,n) for n in ('fine_combined','half_dt')]
        for f in futures:f.result()
    execute('activity_025')
    subprocess.run([sys.executable,str(ROOT/'evaluate_stage6.py'),str(primary),'--out',str(out/'report'),
                    '--numerical',f'fine_combined={out/"fine_combined"}',
                    '--numerical',f'half_dt={out/"half_dt"}',
                    '--environment',f'activity_025={out/"activity_025"}'],check=True,cwd=ROOT)
    (out/'campaign.json').write_text(json.dumps(dict(status='finished',selected=selected,primary=str(primary),
        completed=['fine_combined','half_dt','activity_025'],planned_only=['fine_grid','oxygen_scenario']),indent=2)+'\n')


if __name__=='__main__':main()
