"""Interrupt/resume invariance before and after the dose event."""
import copy
import json
from pathlib import Path
import numpy as np
import pytest

from kjwp_stage1 import stage2
from kjwp_stage1.reactive_transport import solve
from kjwp_stage1.checkpoint import load_checkpoint

ROOT=Path(__file__).resolve().parents[1]


@pytest.mark.parametrize('stop_write',[1,3])
def test_reactive_restart_preserves_every_history_value_and_field(tmp_path,monkeypatch,stop_write):
    cfg=json.loads((ROOT/'configs/stage5/batch_test_base.json').read_text())
    cfg['initial_attached_kg_m3_soil']={'sulfur':.03,'caco3':.01}
    reference=solve(cfg)
    checkpoint=tmp_path/'checkpoint.npz'
    real_write=stage2.write_checkpoint;calls=0
    class Interrupted(Exception):pass
    def stop(path,config,state):
        nonlocal calls
        real_write(path,config,state);calls+=1
        if calls==stop_write:raise Interrupted()
    monkeypatch.setattr(stage2,'write_checkpoint',stop)
    with pytest.raises(Interrupted):solve(cfg,checkpoint=checkpoint,checkpoint_steps=1)
    monkeypatch.setattr(stage2,'write_checkpoint',real_write)
    resumed=solve(cfg,checkpoint=checkpoint,resume=checkpoint,checkpoint_steps=1)
    assert resumed['summary']['checkpoint_resumed_from_s']>0
    assert len(resumed['history'])==len(reference['history'])
    for a,b in zip(resumed['history'],reference['history'],strict=True):
        assert a==b
    for a,b in zip(resumed['fields'],reference['fields'],strict=True):
        for key in a:np.testing.assert_array_equal(a[key],b[key])
    changed=copy.deepcopy(cfg);changed['surface_NO3_load_kg_m2_s']*=2
    with pytest.raises(ValueError,match='input mismatch'):load_checkpoint(checkpoint,changed)


def test_nonreactive_restart_and_solver_guard(tmp_path,monkeypatch):
    cfg=json.loads((ROOT/'configs/stage5/batch_test_base.json').read_text())
    ref=stage2.solve(cfg);path=tmp_path/'checkpoint.npz'
    done=stage2.solve(cfg,checkpoint=path,checkpoint_steps=2)
    resumed=stage2.solve(cfg,resume=path)
    assert resumed['history']==done['history']==ref['history']
    for a,b in zip(resumed['fields'],ref['fields'],strict=True):
        for key in a:np.testing.assert_array_equal(a[key],b[key])
    import kjwp_stage1.checkpoint as module
    monkeypatch.setattr(module,'solver_digest',lambda:'different source')
    with pytest.raises(ValueError,match='solver source mismatch'):load_checkpoint(path,cfg)
