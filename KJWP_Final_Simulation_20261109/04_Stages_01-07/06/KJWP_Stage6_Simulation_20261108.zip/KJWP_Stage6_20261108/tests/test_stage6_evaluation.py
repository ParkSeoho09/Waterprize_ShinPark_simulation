"""Guard against false rankings from corrupt/incomparable simulation evidence."""
import copy
import csv
import hashlib
import json
from pathlib import Path
import shutil

import pytest

from kjwp_stage1.evaluation import evaluate_batch, audit_run, compare_sensitivity

ROOT=Path(__file__).resolve().parents[1]
SMOKE=ROOT/'stage6_preflight'/'smoke'


def save(path,value):path.write_text(json.dumps(value,ensure_ascii=False,sort_keys=True,indent=2)+'\n')


@pytest.fixture
def batch(tmp_path):
    destination=tmp_path/'batch'
    shutil.copytree(SMOKE,destination)
    return destination


def edit_cfg(batch,name,mutate):
    p=batch/name/'input.json';cfg=json.loads(p.read_text());mutate(cfg);save(p,cfg)
    digest=hashlib.sha256(p.read_bytes()).hexdigest()
    p=batch/name/'summary.json';summary=json.loads(p.read_text());summary['input_sha256']=digest;save(p,summary)
    p=batch/'batch_summary.json';meta=json.loads(p.read_text())
    next(r for r in meta['jobs'] if r['id']==name)['input_sha256']=digest;save(p,meta)


def test_stage6_valid_metrics_and_control():
    r,_,_=evaluate_batch(SMOKE)
    assert r['comparison_ready']
    rows={v['id']:v for v in r['rows']}
    c=rows['CONTROL'];a=rows['B00001']
    assert c['dry_solid_g']==c['carrier_water_mL']==c['NO3_reacted_mg']==0
    assert a['dry_solid_g']==pytest.approx(10)
    assert a['NO3_reacted_percent']==pytest.approx(a['NO3_reacted_mg']/a['NO3_available_mg']*100)
    assert a['control_bottom_difference_mg']==pytest.approx(c['NO3_bottom_out_mg']-a['NO3_bottom_out_mg'])
    assert a['NO3_available_mg']==pytest.approx(a['NO3_remaining_mg']+a['NO3_all_out_mg']+a['NO3_reacted_mg'])
    assert a['material_cost'] is None and a['pump_energy_J'] is None


def test_stage6_corrupt_intermediate_balance_rejects_ranking(batch):
    p=batch/'B00001'/'history.csv'
    with p.open() as stream:rows=list(csv.DictReader(stream))
    rows[2]['NO3_residual_kg']='0.01'
    with p.open('w',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=rows[0]);writer.writeheader();writer.writerows(rows)
    result,_,_=evaluate_batch(batch)
    assert not result['comparison_ready']
    assert 'NO3 mass balance failure' in result['audits']['B00001']['errors']
    assert all(row['reaction_rank'] is None for row in result['rows'])


def test_stage6_tampered_input_rejected(batch):
    p=batch/'B00001'/'input.json';p.write_text(p.read_text()+' ')
    result,_,_=evaluate_batch(batch)
    assert not result['comparison_ready']
    assert 'input hash mismatch' in result['audits']['B00001']['errors']


def test_stage6_actual_water_shortfall_rejected(batch):
    p=batch/'B00001'/'summary.json';s=json.loads(p.read_text());s['port_water_m3'][0]*=.5;save(p,s)
    audit,_,_,_=audit_run(batch/'B00001')
    assert not audit['passed'] and 'carrier water dose mismatch' in audit['errors']


def test_stage6_changed_forcing_and_incomplete_batch_rejected(batch):
    edit_cfg(batch,'B00001',lambda c:c.update(surface_NO3_load_kg_m2_s=5e-10))
    result,_,_=evaluate_batch(batch)
    assert not result['common_conditions_match'] and not result['comparison_ready']
    p=batch/'batch_summary.json';m=json.loads(p.read_text());m['all_requested_jobs_finished']=False;save(p,m)
    with pytest.raises(ValueError,match='All requested jobs'):evaluate_batch(batch)


def test_stage6_sensitivity_reversal_and_physics_guard():
    primary,_,_=evaluate_batch(SMOKE)
    # Use deliberately separated synthetic metrics to test the decision rule.
    ids=['B00001','B00007']
    primary['rows']=[r for r in primary['rows'] if r['id'] in ids or r['kind']=='no_injection']
    for r in primary['rows']:
        if r['id'] in ids:r['NO3_reacted_mg']=100 if r['id']==ids[0] else 90
    small=copy.deepcopy(primary)
    for r in small['rows']:
        if r['id'] in ids:r['NO3_reacted_mg']+=1
    assert compare_sensitivity(primary,{'small':small})['pairwise'][0]['rank_supported_by_screen']
    reverse=copy.deepcopy(small)
    next(r for r in reverse['rows'] if r['id']==ids[1])['NO3_reacted_mg']=110
    assert not compare_sensitivity(primary,{'reverse':reverse})['pairwise'][0]['rank_supported_by_screen']
    small['physical_conditions']['surface_NO3_load_kg_m2_s']=1
    with pytest.raises(ValueError,match='changed physical conditions'):compare_sensitivity(primary,{'invalid':small})


def test_stage6_resume_requires_same_completed_inputs(tmp_path):
    from run_stage6 import run
    from prepare_stage6_sensitivity import prepare
    for name in ('base_smoke.json','CONTROL.json','B00001.json','B00007.json'):
        shutil.copy(ROOT/'configs'/'stage6'/name,tmp_path/name)
    manifest=dict(schema_version=1,base='base_smoke.json',jobs=[dict(id=n,layout=n+'.json') for n in ('CONTROL','B00001','B00007')])
    save(tmp_path/'batch.json',manifest)
    out=tmp_path/'completed';out.mkdir()
    for n in ('CONTROL','B00001','B00007'):shutil.copytree(SMOKE/n,out/n)
    rows=run(tmp_path/'batch.json',out,resume=True)
    assert all(r['status']=='finished' for r in rows)
    assert evaluate_batch(out)[0]['comparison_ready']
    selected=prepare(out,tmp_path/'batch.json',tmp_path/'sensitivity')
    assert set(selected)=={'B00001','B00007'}
    fine=json.loads((tmp_path/'sensitivity'/'base_fine_combined.json').read_text())
    base=json.loads((tmp_path/'base_smoke.json').read_text())
    assert fine['max_dt_s']==base['max_dt_s']/2
    assert fine['grid']['cells_xyz']==[19,19,31]
    base['surface_NO3_load_kg_m2_s']*=2;save(tmp_path/'base_smoke.json',base)
    with pytest.raises(ValueError,match='Cannot reuse'):run(tmp_path/'batch.json',out,resume=True)


def test_stage6_process_runner_and_heartbeat(tmp_path):
    from run_stage6 import run
    base=json.loads((ROOT/'configs'/'stage5'/'batch_test_base.json').read_text())
    layout=json.loads((ROOT/'configs'/'stage5'/'batch_test_layout.json').read_text())
    save(tmp_path/'base.json',base)
    save(tmp_path/'one.json',layout)
    layout['direct_ports'][0]['position_m'][0]=.125
    save(tmp_path/'two.json',layout)
    save(tmp_path/'CONTROL.json',dict(schema_version=1,id='CONTROL',kind='no_injection'))
    save(tmp_path/'manifest.json',dict(schema_version=1,base='base.json',jobs=[dict(id=n,layout=n+'.json') for n in ('one','two','CONTROL')]))
    out=tmp_path/'executed'
    run(tmp_path/'manifest.json',out,workers=2)
    assert evaluate_batch(out)[0]['comparison_ready']
    assert all(json.loads((out/n/'heartbeat.json').read_text())['state']=='finished' for n in ('one','two','CONTROL'))
