import copy,json,tempfile,unittest
from pathlib import Path
import numpy as np
from kjwp_stage1.core.grid import Grid
from kjwp_stage1.core.units import concentration_to_si,si_to_mg_l
from kjwp_stage1.core.config import build
from kjwp_stage1.flow.prescribed import ConstantFlow
from kjwp_stage1.physics.transport import Dispersion
from kjwp_stage1.physics.boundary import Boundary,FACES,check_boundaries
from kjwp_stage1.numerics.solver import solve
from kjwp_stage1.numerics.fv import fluxes,concentration_rate
from kjwp_stage1.validation.benchmarks import flow_boundaries,gaussian_case
from kjwp_stage1.validation.analytical import cosine_cell_average
from kjwp_stage1.io.results import save_result


class TransportTests(unittest.TestCase):
    def setUp(self):
        self.g=Grid((1.,.8,.6),(10,8,6))
        self.f=ConstantFlow(.3,.4,(0.,0.,0.))
        self.d=Dispersion((.001,.002,.003))
        self.b={f:Boundary('closed') for f in FACES}

    def run_case(self,initial=None,**kwargs):
        options=dict(end_s=.4,save_times_s=[0,.4],max_dt_s=.02)
        options.update(kwargs)
        return solve(self.g,self.f,self.d,self.b,np.full(self.g.shape,.02) if initial is None else initial,**options)

    def test_units_and_basis(self):
        self.assertAlmostEqual(concentration_to_si(40,'mg/L','NO3'),.04)
        self.assertEqual(float(si_to_mg_l(.04)),40.)
        self.assertAlmostEqual(concentration_to_si(40,'mg/L','NO3-N'),.04)
        for unit,basis in [('g/L','NO3'),('mg/L',None)]:
            with self.assertRaises(ValueError): concentration_to_si(1,unit,basis)

    def test_invalid_concentrations(self):
        for c in (-1,np.nan,np.inf):
            with self.assertRaises(ValueError): concentration_to_si(c,'mg/L','NO3')

    def test_grid_order_and_volume(self):
        self.assertEqual(self.g.shape,(6,8,10))
        self.assertAlmostEqual(np.prod(self.g.shape)*self.g.volume,.48)
        z,y,x=self.g.mesh_zyx()
        self.assertAlmostEqual(x[2,3,4],.45)
        self.assertAlmostEqual(y[2,3,4],.35)
        self.assertAlmostEqual(z[2,3,4],.25)

    def test_invalid_grid(self):
        for n in ((1,2,2),(2.,2,2),(True,2,2)):
            with self.assertRaises(ValueError): Grid((1.,1.,1.),n)

    def test_flow_q_vs_u(self):
        f=ConstantFlow(.25,.4,(1e-6,-2e-6,3e-6))
        np.testing.assert_allclose(f.pore_velocity_m_s,(4e-6,-8e-6,12e-6))
        faces=f.face_fluxes(self.g)
        self.assertEqual(faces[0].shape,(6,8,11))
        self.assertEqual(faces[1].shape,(6,9,10))
        self.assertEqual(faces[2].shape,(7,8,10))

    def test_flow_invalid(self):
        for theta,por in [(0,.4),(.5,.4),(.3,1.1),(np.nan,.4)]:
            with self.assertRaises(ValueError): ConstantFlow(theta,por,(0.,)*3)

    def test_bad_dispersion(self):
        for d in [(-1,0,0),(0,np.nan,0),(1,2)]:
            with self.assertRaises(ValueError): Dispersion(d)

    def test_closed_wall_water_conflict(self):
        with self.assertRaises(ValueError): check_boundaries(self.b,ConstantFlow(.3,.4,(0,0,1e-6)),self.g)

    def test_boundary_signs(self):
        b=self.b.copy();b['x+']=Boundary('inflow_flux')
        with self.assertRaises(ValueError): check_boundaries(b,self.f,self.g)
        b=self.b.copy();b['x+']=Boundary('outflow')
        with self.assertRaises(ValueError): check_boundaries(b,self.f,self.g)

    def test_periodic_pair(self):
        b=self.b.copy();b['x+']=Boundary('periodic')
        with self.assertRaises(ValueError): check_boundaries(b,self.f,self.g)

    def test_constant_solution(self):
        r=self.run_case()
        np.testing.assert_allclose(r.concentration,.02,rtol=1e-14,atol=0)

    def test_3d_closed_diffusion_and_local_conservation(self):
        c=cosine_cell_average(self.g,0,self.d.diagonal_m2_s,.03,.8)
        r=self.run_case(c)
        self.assertLess(max(h['relative_residual'] for h in r.history),1e-12)
        self.assertLess(r.numerical['max_local_residual_kg'],1e-18)
        self.assertGreater(r.concentration[-1].min(),c.min())
        self.assertLess(r.concentration[-1].max(),c.max())

    def test_every_flow_direction_constant_state(self):
        for a in range(3):
            for sign in (-1,1):
                q=[0.]*3;q[a]=sign*.003
                self.f=ConstantFlow(.3,.4,tuple(q));self.b=flow_boundaries(self.f)
                for f,b in list(self.b.items()):
                    if b.kind=='inflow_flux':self.b[f]=Boundary('inflow_flux',.02)
                r=self.run_case()
                np.testing.assert_allclose(r.concentration,.02,rtol=1e-13,atol=1e-17)
                self.assertLess(max(h['relative_residual'] for h in r.history),1e-12)

    def test_periodic_flow_is_internal_not_external_mass(self):
        self.f=ConstantFlow(.3,.4,(.003,-.002,.001))
        self.b={f:Boundary('periodic') for f in FACES}
        c=np.random.default_rng(7).uniform(.001,.04,self.g.shape)
        r=self.run_case(c)
        self.assertEqual(r.history[-1]['in_kg'],0)
        self.assertEqual(r.history[-1]['out_kg'],0)
        self.assertLess(max(h['relative_residual'] for h in r.history),1e-12)

    def test_dirichlet_diffusion_linear_equilibrium_and_budget(self):
        self.b['x-']=Boundary('dirichlet',.01);self.b['x+']=Boundary('dirichlet',.03)
        x=self.g.centers_xyz[0]
        c=np.broadcast_to(.01+.02*x,self.g.shape).copy()
        r=self.run_case(c)
        np.testing.assert_allclose(r.concentration[-1],c,atol=2e-17)
        self.assertGreater(r.history[-1]['in_kg'],0)
        self.assertGreater(r.history[-1]['out_kg'],0)
        self.assertLess(max(h['relative_residual'] for h in r.history),1e-12)

    def test_partial_pulse_exact_input(self):
        self.f=ConstantFlow(.3,.4,(0.,0.,.003));self.b=flow_boundaries(self.f)
        self.b['z-']=Boundary('inflow_flux',.04,.031,.173,((.2,.6),(.2,.6)))
        r=self.run_case(np.zeros(self.g.shape),max_dt_s=.037)
        expected=.003*.4*.4*.04*(.173-.031)
        self.assertAlmostEqual(r.history[-1]['in_kg']/expected,1.,places=13)
        self.assertEqual(r.history[0]['bottom_flux_concentration_kg_m3'],0.)
        self.assertLess(max(h['relative_residual'] for h in r.history if np.isfinite(h['relative_residual'])),1e-12)

    def test_high_peclet_step_positivity(self):
        self.f=ConstantFlow(.3,.4,(.03,-.01,.02));self.d=Dispersion((0.,0.,0.))
        self.b=flow_boundaries(self.f)
        c=np.zeros(self.g.shape);c[1:4,2:6,2:6]=.1
        r=self.run_case(c,end_s=2.,save_times_s=[0,2.],max_dt_s=1.)
        self.assertGreaterEqual(min(h['minimum_kg_m3'] for h in r.history),0.)
        self.assertLessEqual(max(h['maximum_kg_m3'] for h in r.history),.1+1e-14)

    def test_gaussian_accuracy(self):
        r,m=gaussian_case(24)
        self.assertLess(m[-1]['relative_l1'],.05)
        self.assertLess(max(m[-1]['relative_variance_error']),.05)

    def test_reject_invalid_states(self):
        for v in (np.nan,np.inf,-.1):
            c=np.zeros(self.g.shape);c[0,0,0]=v
            with self.assertRaises((ValueError,FloatingPointError)): self.run_case(c)
        with self.assertRaises(FloatingPointError): self.run_case(np.zeros((3,3,3)))

    def test_reject_bad_time_and_scheme(self):
        for kw in [dict(max_dt_s=-1),dict(end_s=0),dict(cfl=1.),dict(scheme='unknown'),
                   dict(save_times_s=[.2,.1]),dict(save_times_s=[0,1])]:
            with self.assertRaises(ValueError): self.run_case(**kw)

    def test_max_steps_stops(self):
        with self.assertRaises(RuntimeError):self.run_case(max_steps=1)

    def test_snapshot_schedule(self):
        r=self.run_case(save_times_s=[.13,.27])
        np.testing.assert_array_equal(r.times_s,[0,.13,.27,.4])

    def test_patch_outside_rejected(self):
        self.f=ConstantFlow(.3,.4,(0.,0.,.003));self.b=flow_boundaries(self.f)
        self.b['z-']=Boundary('inflow_flux',.02,patch_m=((0,2),(0,.4)))
        with self.assertRaises(ValueError):self.run_case()

    def test_missing_basis_and_unknown_option(self):
        config=json.loads((Path(__file__).parents[1]/'configs'/'column_pulse.json').read_text())
        a=copy.deepcopy(config);del a['nitrate_basis']
        with self.assertRaises(ValueError):build(a)
        a=copy.deepcopy(config);a['flow']['velocity']=.2
        with self.assertRaises(ValueError):build(a)

    def test_output_roundtrip(self):
        r=self.run_case()
        with tempfile.TemporaryDirectory() as td:
            save_result(r,td,{'nitrate_basis':'NO3','note':'test'})
            with np.load(Path(td)/'fields.npz',allow_pickle=False) as f:
                np.testing.assert_array_equal(f['C_kg_m3'],r.concentration)
                self.assertEqual(str(f['array_order']),'time,z,y,x')
            meta=json.loads((Path(td)/'run_metadata.json').read_text())
            self.assertFalse(meta['numerical']['clipping'])
            self.assertIn('OpenGeoSys cross-validation NOT performed.',meta['limitations'])


if __name__=='__main__':unittest.main()
