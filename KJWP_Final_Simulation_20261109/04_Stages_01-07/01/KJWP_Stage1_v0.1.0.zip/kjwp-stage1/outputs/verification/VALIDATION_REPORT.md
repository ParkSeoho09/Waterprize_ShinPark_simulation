# Stage 1 수치검증 결과

상태: **PASS**. 자동 실행으로 생성한 수치이며 실측 연구결과가 아니다.

| 검증 | 결과 |
|---|---|
| 3D Gaussian continuum solution at two positive times | PASS |
| Gaussian spatial convergence (24,48,96) | PASS |
| MC reduces numerical spreading compared with upwind | PASS |
| Closed 3D diffusion cosine continuum solution | PASS |
| Closed system mass conservation | PASS |
| Time convergence against exact semidiscrete diffusion mode | PASS |
| Known pulsed patch input and open outlet budget | PASS |

Gaussian 공간격자 상대 L1 오차: 2.6164%, 0.6434%, 0.1405%

**OpenGeoSys 교차검증: 미실행.** 독립 소프트웨어 비교가 남아 있으므로 전체 Stage 1 검증 완료로 표현하지 않는다.

전체 조건·오차·축별 중심·분산·관측 수렴차수는 `validation.json`을 참조한다.
