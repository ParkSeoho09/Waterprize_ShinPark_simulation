# KJWP 2026 — 3D 질산염 수송 엔진 · Stage 1 v0.1.0

**실행 가능한 Python 수치해석 코드, 자동시험, 예시 계산 결과를 포함한다.**

전체 개발 순서와 최종 목표는 [확정 로드맵](docs/ROADMAP.md)에 원문으로 기록했다. 이후 개발은 Stage 1~7의 문구·순서를 유지하며 진행한다. 개발 작업자는 먼저 `AGENTS.md`를 읽는다.

Stage 1은 **일정한 체적함수율과 정상 물 플럭스가 주어졌을 때의 보존성 질산염 이동**을 계산한다. x·y·z 세 방향의 셀 간 수송을 실제로 풀며, 표시용 그림은 계산 결과 배열에서 생성한다.

수치검증은 통과했으며 **OpenGeoSys와의 독립 비교는 미실행**이다. 실제 토양 파라미터 보정 및 토조 실험 검증도 남아 있다. 따라서 연구용 수송 엔진의 초기 버전이며, 현장 정확도나 전체 Stage 1 검증 완료를 주장하지 않는다.

## 결과부터 보기

- `RESULTS.html`: 압축을 푼 뒤 브라우저에서 열 수 있는 결과 요약. 인터넷 없이 그림·애니메이션을 볼 수 있다.
- `outputs/column_pulse/figures/overview.png`: 세 방향 단면, 계산 셀의 3D 분포, 깊이별 BTC, 질량수지.
- `outputs/column_pulse/figures/transport.gif`: 실제 저장 농도장의 시간 변화.
- `outputs/verification/VALIDATION_REPORT.md`: 수치검증 요약.
- `outputs/verification/validation.json`: 검증 조건·오차·수렴차수의 전체 수치.
- `outputs/unit_tests.txt`: 자동 회귀시험 실행 기록.

**예시 계산은 실측 결과가 아니다.** 60×20×30 cm 영역, θ=0.30, 하향 Darcy 플럭스 10⁻⁶ m/s 등의 값은 코드 동작을 확인하기 위한 가상 조건이다. 공급한 질산염이 하부로 빠져나가는 과정이며, 정화·탈질·반응은 없다.

## 실행

Python 3.10 이상이 필요하다. 압축을 풀고 이 README가 있는 폴더에서 실행한다.

```bash
python -m pip install .
python -m unittest discover -s tests -v
python -m kjwp_stage1 validate --out outputs/verification
python -m kjwp_stage1 run configs/column_pulse.json --out outputs/column_pulse --plots --gif
```

별도의 예시 Gaussian 분포 계산:

```bash
python -m kjwp_stage1 run configs/gaussian_3d.json --out outputs/gaussian_3d --plots
```

저장된 결과를 다시 그릴 때는 계산을 반복하지 않는다.

```bash
python -m kjwp_stage1 plot outputs/column_pulse --gif
```

`validate`는 실패한 검증이 있으면 종료코드 1을 반환한다. `unittest`는 표준 라이브러리이므로 pytest를 추가 설치할 필요가 없다. 환경에 따라 최초 Matplotlib 폰트 캐시 생성에는 시간이 더 걸릴 수 있다.

## 현재 구현

| 기능 | 내용 |
|---|---|
| 격자·좌표 | 균일 직교 3D 셀 중심 격자. x,y는 수평, z는 아래로 증가 |
| 유동장 | 일정 θ, 공극률, Darcy 플럭스 q. 공극수 속도는 u=q/θ |
| 물리모델 | 보존형 이류·분산 방정식. 일정 대각 분산계수 Dx,Dy,Dz |
| 초기조건 | 균일, Gaussian 셀 평균, cosine 모드, 사용자 NPY 3D 배열 |
| 경계조건 | 밀폐, 총 질량 플럭스 유입, 대류 유출, 지정 농도, 축별 주기경계 |
| 유입 | 일정·유한 시간 펄스·직사각형 질산염 농도 패치 |
| 수치법 | 자체 NumPy 유한체적법. MUSCL-MC 또는 1차 Upwind 이류, 중심차분 분산, SSPRK2 |
| 질량수지 | 모든 시간단계에서 실제 계산한 공유면 플럭스로 적분. 국소 셀 잔차 포함 |
| 진단 | 깊이별 resident BTC, 하부 flux BTC, 질량·중심·분산, 음수·NaN·Inf 검사 |
| 출력 | NPZ 3D 원본, CSV, 입력·단위·버전·SHA256 JSON, PNG·GIF |

농도는 `NO3` 또는 `NO3-N` 질량 기준을 필수로 선언한다. 두 기준 사이를 자동 변환하지 않는다. 농도 입력은 mg/L 또는 kg/m³ water이며 내부 계산은 kg/m³ water다. 그 밖의 입력 단위는 SI다.

표면의 농도 패치는 **질산염 공급 농도만 공간적으로 다르다**. 물은 표면 전체에서 같은 속도로 들어간다. 국소 관수나 주입으로 물의 흐름 자체가 변하는 모형은 Stage 2 이후다.

## 파일 구조

| 경로 | 책임 |
|---|---|
| `kjwp_stage1/core` | 단위·입력 검사·격자 |
| `kjwp_stage1/flow` | 현재 일정 θ,q 공급자 |
| `kjwp_stage1/physics` | 분산계수·경계조건 계약 |
| `kjwp_stage1/numerics` | 면 플럭스·시간적분·안정 시간간격 |
| `kjwp_stage1/analysis` | 질량·공간 모멘트·오차 |
| `kjwp_stage1/io` | 결과 저장·실행조건 기록 |
| `kjwp_stage1/visualization` | 저장 결과에서 그림 생성 |
| `kjwp_stage1/validation`, `tests` | 해석해·수렴성·회귀시험 |
| `configs` | 바꿔 실행할 수 있는 JSON 예시 |
| `docs` | 수학 모델·계산 알고리즘·입력 설명·남은 검증 |

## 기존 설계안에서 달라진 점

설계 검토안 v0.1은 FiPy+Upwind+후진 Euler를 제안했다. 실제 구현에서는 **면 플럭스와 시간 적분을 직접 일치시키고 이류의 수치분산을 줄이기 위해 자체 NumPy 유한체적법+MUSCL-MC+SSPRK2**를 채택했다. Upwind도 같은 엔진에서 비교할 수 있다. 정확도는 채택한 라이브러리 이름이 아니라 해석해와 수렴시험으로 확인한다.

FiPy·Clawpack·OpenGeoSys의 코드는 사용하지 않았다. SciPy는 Gaussian 셀 평균을 계산하는 `erf`, NumPy는 배열 연산, Matplotlib·Pillow는 출력 그림과 애니메이션에 사용한다. 계산에 선형 반복 솔버가 없으므로 선형계 잔차나 반복 수를 출력하지 않는다.

## 적용 한계와 다음 단계

1. θ와 q가 시간·공간에 따라 변하지 않는다. Richards 방정식, 젖음 전선, 불균질 토양, 우선흐름을 아직 계산하지 않는다.
2. 분산계수는 일정한 대각 성분만 지원한다. 사선 유동의 Gaussian 시험은 수학적 ADE 시험이다. 실제 사선 유동에서 종·횡 분산이 만드는 비대각 텐서를 재현한 결과가 아니다.
3. 반응·흡착·황·탄산칼슘·주입수·입자·관 구조·성능 최적화는 구현하지 않았다.
4. 양수 유지와 해석해 정확도는 시험한 조건에서 확인했다. 명시적 시간적분이므로 높은 D와 매우 작은 격자는 계산비용을 크게 늘린다. 주어진 안정 제한을 넘는 시간간격은 자동으로 줄인다.
5. OpenGeoSys 실행 파일이 현재 환경에 없어서 동조건 비교는 수행하지 않았다. `docs/NEXT_VALIDATION.md`의 조건으로 진행하며, 이 결과 없이 전문 소프트웨어 수준의 정확도로 표현하지 않는다.

방정식·경계·검증 근거는 `docs/METHODS.md`, 설정 변경은 `docs/CONFIGURATION.md`에 있다.
