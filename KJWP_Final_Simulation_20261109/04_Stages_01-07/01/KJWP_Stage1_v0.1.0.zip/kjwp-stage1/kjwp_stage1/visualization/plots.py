"""Postprocessing only: reads saved computed arrays; never invokes the solver."""
from pathlib import Path
import csv
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation,PillowWriter


def render(directory,make_gif=False):
    out=Path(directory);figs=out/'figures';figs.mkdir(exist_ok=True)
    with np.load(out/'fields.npz',allow_pickle=False) as f:
        C=f['C_kg_m3']*1000;times=f['times_s'];x=f['x_m'];y=f['y_m'];z=f['z_m']
        lengths=f['lengths_m'];basis=str(f['nitrate_basis'])
    with (out/'mass_balance.csv').open() as stream:
        rows=list(csv.DictReader(stream))
    with (out/'breakthrough.csv').open() as stream:
        btc_rows=list(csv.DictReader(stream))
    def series(key): return np.array([float(r[key]) if r[key] else np.nan for r in rows])
    T=series('time_s')/3600
    totals=C.sum(axis=(1,2,3))
    resident_depth=(C.sum(axis=(2,3))*z).sum(axis=1)/np.maximum(totals,1e-300)
    candidates=np.where(totals>totals.max()*.1)[0]
    frame=int(candidates[np.argmin(abs(resident_depth[candidates]-lengths[2]/2))]) if len(candidates) else 0
    field=C[frame];vmax=max(float(C.max()),1e-12)
    plt.rcParams.update({'font.size':9,'axes.spines.top':False,'axes.spines.right':False})
    fig=plt.figure(figsize=(14,8.4),layout='constrained')
    axs=[fig.add_subplot(2,3,i) for i in range(1,4)]
    images=[]
    images.append(axs[0].imshow(field[:,len(y)//2,:],origin='upper',extent=[0,lengths[0],lengths[2],0],
        aspect='auto',vmin=0,vmax=vmax,cmap='viridis'))
    axs[0].set(xlabel='x (m)',ylabel='depth z (m)',title=f'XZ slice at y={y[len(y)//2]:.3f} m')
    axs[1].imshow(field[:,:,len(x)//2],origin='upper',extent=[0,lengths[1],lengths[2],0],
        aspect='auto',vmin=0,vmax=vmax,cmap='viridis')
    axs[1].set(xlabel='y (m)',ylabel='depth z (m)',title=f'YZ slice at x={x[len(x)//2]:.3f} m')
    iz=int(np.argmin(abs(z-resident_depth[frame])))
    axs[2].imshow(field[iz],origin='lower',extent=[0,lengths[0],0,lengths[1]],
        aspect='auto',vmin=0,vmax=vmax,cmap='viridis')
    axs[2].set(xlabel='x (m)',ylabel='y (m)',title=f'XY slice at depth={z[iz]:.3f} m')
    fig.colorbar(images[0],ax=axs,label=f'{basis} (mg/L water)',shrink=.8)
    ax=fig.add_subplot(2,3,4,projection='3d')
    Z,Y,X=np.meshgrid(z,y,x,indexing='ij');mask=field>vmax*.02
    ix=np.flatnonzero(mask)[::max(1,int(np.count_nonzero(mask)/5000))]
    ax.scatter(X.ravel()[ix],Y.ravel()[ix],Z.ravel()[ix],c=field.ravel()[ix],s=5,
        cmap='viridis',vmin=0,vmax=vmax,alpha=.5)
    ax.set(xlabel='x (m)',ylabel='y (m)',zlabel='depth (m)',xlim=(0,lengths[0]),
        ylim=(0,lengths[1]),zlim=(lengths[2],0),title='3D cell centers >2% of global peak (subsampled)')
    ax=fig.add_subplot(2,3,5)
    for frac in (.25,.5,.75):
        iz=int(np.argmin(abs(z-lengths[2]*frac)))
        # Resident and flux BTCs both use EVERY numerical step, not movie frames.
        key=f'resident_z_{z[iz]:.7g}_m_mg_L'
        ax.plot(T,[float(row[key]) for row in btc_rows],label=f'resident z={z[iz]:.3f} m')
    ax.plot(T,series('bottom_flux_concentration_kg_m3')*1000,'k',label='bottom flux BTC',linewidth=1.8)
    ax.set(xlabel='time (h)',ylabel=f'{basis} (mg/L)',title='Breakthrough curves');ax.legend(fontsize=7)
    ax=fig.add_subplot(2,3,6)
    ax.plot(T,(series('initial_kg')+series('in_kg'))*1e6,label='initial + input')
    ax.plot(T,series('stored_kg')*1e6,label='stored')
    ax.plot(T,series('out_kg')*1e6,label='all outlets')
    ax.plot(T,(series('stored_kg')+series('out_kg'))*1e6,'--',label='stored + outlets')
    ax.set(xlabel='time (h)',ylabel=f'mass (mg, {basis})',title='Mass budget (no reactions)');ax.legend(fontsize=7)
    fig.suptitle(f'KJWP Stage 1 | Synthetic constant-flow transport | slices at {times[frame]/3600:.2f} h\n'
                 'Prescribed water content and flux; not a calibrated soil experiment',fontsize=13)
    fig.savefig(figs/'overview.png',dpi=160);plt.close(fig)
    if make_gif:
        fig,ax=plt.subplots(figsize=(8,4.5),layout='constrained')
        im=ax.imshow(C[0,:,len(y)//2,:],origin='upper',extent=[0,lengths[0],lengths[2],0],
            aspect='auto',vmin=0,vmax=vmax,cmap='viridis')
        fig.colorbar(im,ax=ax,label=f'{basis} (mg/L water)')
        ax.set(xlabel='x (m)',ylabel='depth z (m)')
        title=ax.set_title('')
        def update(i):
            im.set_data(C[i,:,len(y)//2,:])
            title.set_text(f'Computed XZ concentration | t={times[i]/3600:.2f} h\nSynthetic steady-flow ADE; no reactions')
            return im,title
        FuncAnimation(fig,update,frames=len(times),interval=150,blit=False).save(
            figs/'transport.gif',writer=PillowWriter(fps=7),dpi=110)
        plt.close(fig)
    return figs/'overview.png'
