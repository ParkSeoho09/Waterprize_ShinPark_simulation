import argparse
from pathlib import Path
from .core.config import load
from .numerics.solver import solve
from .io.results import save_result


def main(argv=None):
    p=argparse.ArgumentParser(description='KJWP Stage 1 constant-flow 3D transport')
    sub=p.add_subparsers(dest='command',required=True)
    run=sub.add_parser('run');run.add_argument('config');run.add_argument('--out',required=True)
    run.add_argument('--plots',action='store_true');run.add_argument('--gif',action='store_true')
    plot=sub.add_parser('plot');plot.add_argument('directory');plot.add_argument('--gif',action='store_true')
    val=sub.add_parser('validate');val.add_argument('--out',default='outputs/verification')
    a=p.parse_args(argv)
    if a.command=='run':
        cfg,parts=load(a.config)
        grid,flow,dis,b,initial,options=parts
        r=solve(grid,flow,dis,b,initial,**options)
        save_result(r,a.out,cfg)
        if a.plots or a.gif:
            from .visualization.plots import render
            render(a.out,a.gif)
        h=r.history[-1]
        print(f"Saved {len(r.times_s)} 3D fields; {r.numerical['steps']} steps to {Path(a.out).resolve()}")
        print(f"Input {h['in_kg']:.9g} kg; stored {h['stored_kg']:.9g} kg; out {h['out_kg']:.9g} kg")
        print(f"Relative mass residual {h['relative_residual']:.3g}")
    elif a.command=='plot':
        from .visualization.plots import render
        print(render(a.directory,a.gif))
    else:
        from .validation.benchmarks import run_benchmarks
        data=run_benchmarks(a.out)
        print(f"Verification: {data['status']}; OpenGeoSys: NOT_RUN")
        return 0 if data['status']=='PASS' else 1
    return 0


if __name__=='__main__':
    raise SystemExit(main())
