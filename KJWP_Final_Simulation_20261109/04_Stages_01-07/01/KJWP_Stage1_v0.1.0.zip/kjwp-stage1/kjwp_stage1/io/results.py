from pathlib import Path
import csv,hashlib,json,platform
from dataclasses import asdict
import numpy as np
import scipy
from .. import __version__
from ..physics.boundary import FACES


def clean_json(v):
    if isinstance(v,dict): return {k:clean_json(x) for k,x in v.items()}
    if isinstance(v,(list,tuple)): return [clean_json(x) for x in v]
    if isinstance(v,np.ndarray): return clean_json(v.tolist())
    if isinstance(v,(float,np.floating)) and not np.isfinite(v): return None
    if isinstance(v,np.generic): return v.item()
    return v


def write_json(path,data):
    Path(path).write_text(json.dumps(clean_json(data),ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')


def save_result(result,directory,config):
    out=Path(directory);out.mkdir(parents=True,exist_ok=True)
    r=result; x,y,z=r.grid.centers_xyz
    qx,qy,qz=r.flow.face_fluxes(r.grid)
    np.savez_compressed(out/'fields.npz',times_s=r.times_s,C_kg_m3=r.concentration,
        x_m=x,y_m=y,z_m=z,theta=np.full(r.grid.shape,r.flow.theta),
        qx_m_s=qx,qy_m_s=qy,qz_m_s=qz,D_diagonal_m2_s=r.dispersion.diagonal_m2_s,
        nitrate_basis=config['nitrate_basis'],array_order='time,z,y,x',
        lengths_m=r.grid.lengths_m,cells_xyz=r.grid.cells_xyz)
    scalar_keys=[k for k in r.history[0] if k not in ('depth_means_kg_m3','moments','face_cumulative_kg')]
    with (out/'mass_balance.csv').open('w',newline='',encoding='utf-8') as stream:
        writer=csv.DictWriter(stream,fieldnames=scalar_keys)
        writer.writeheader()
        for row in r.history:
            writer.writerow({k:'' if isinstance(row[k],float) and not np.isfinite(row[k]) else row[k] for k in scalar_keys})
    with (out/'breakthrough.csv').open('w',newline='',encoding='utf-8') as stream:
        writer=csv.writer(stream)
        writer.writerow(['time_s','bottom_flux_concentration_mg_L']+[f'resident_z_{v:.7g}_m_mg_L' for v in z])
        for h in r.history:
            bc=h['bottom_flux_concentration_kg_m3']
            writer.writerow([h['time_s'],bc*1000 if np.isfinite(bc) else '']+list(h['depth_means_kg_m3']*1000))
    with (out/'metrics.csv').open('w',newline='',encoding='utf-8') as stream:
        writer=csv.writer(stream);writer.writerow(['time_s','center_x_m','variance_x_m2',
            'center_y_m','variance_y_m2','center_z_m','variance_z_m2'])
        for h in r.history:
            writer.writerow([h['time_s']]+[v if np.isfinite(v) else '' for v in h['moments']])
    with (out/'boundary_mass.csv').open('w',newline='',encoding='utf-8') as stream:
        writer=csv.writer(stream);writer.writerow(['time_s']+[f'{f}_{v}_kg' for f in FACES for v in ('in','out')])
        for h in r.history:
            writer.writerow([h['time_s']]+h['face_cumulative_kg'].ravel().tolist())
    canonical=json.dumps(config,sort_keys=True,ensure_ascii=False).encode()
    p=r.numerical
    metadata=dict(version=__version__,input_sha256=hashlib.sha256(canonical).hexdigest(),input=config,
        units=dict(length='m',time='s',concentration='kg/m3 water',darcy_flux='m/s',
            dispersion='m2/s',mass='kg',nitrate_basis=config['nitrate_basis']),
        coordinates='x,y horizontal; z depth positive down; arrays time,z,y,x',
        numerical=p,flow=asdict(r.flow),grid=asdict(r.grid),dispersion=asdict(r.dispersion),
        boundaries={k:asdict(v) for k,v in r.boundaries.items()},
        actual_solute_patch_area_m2={f:float(np.count_nonzero(r.boundaries[f].values(
            r.boundaries[f].pulse_start_s,r.grid,i//2))*r.grid.face_area(i//2))
            for i,f in enumerate(FACES) if r.boundaries[f].kind in ('inflow_flux','dirichlet')},
        courant_sum=sum(abs(u)*p['max_dt_s']/h for u,h in zip(r.flow.pore_velocity_m_s,r.grid.spacing_xyz)),
        cell_peclet=[abs(u)*h/d if d>0 else None for u,h,d in zip(r.flow.pore_velocity_m_s,
            r.grid.spacing_xyz,r.dispersion.diagonal_m2_s)],
        dependencies=dict(python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__),
        limitations=['Prescribed constant water content and Darcy flux; no Richards equation.',
            'Homogeneous diagonal dispersion only; no off-diagonal tensor.',
            'No reactions, adsorption, injection water or service pipes.',
            'Example parameters are synthetic, not calibrated soil data.',
            'OpenGeoSys cross-validation NOT performed.'],
        references=['https://doi.org/10.5772/63496','https://www.clawpack.org/pyclaw/evolve/limiters.html'])
    write_json(out/'run_metadata.json',metadata)
    return out
