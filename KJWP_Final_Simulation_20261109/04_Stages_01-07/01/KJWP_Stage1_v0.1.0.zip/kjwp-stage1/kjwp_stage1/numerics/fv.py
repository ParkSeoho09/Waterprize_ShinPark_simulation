"""Shared-face finite volumes: MUSCL/MC (or upwind), centered dispersion, SSPRK2.

This is a project-owned NumPy backend, NOT FiPy or Clawpack code. No concentration
clipping or mass renormalization is performed. Units of every returned face flux:
kg/(m2 s), using the selected nitrate mass basis.
"""
import numpy as np
from ..physics.boundary import FACES


def mc_slopes(c, periodic=False):
    """Monotonized-central cell increments along last axis; zero at physical edges."""
    if periodic:
        dl=c-np.roll(c,1,axis=-1)
        dr=np.roll(c,-1,axis=-1)-c
    else:
        dl=np.zeros_like(c); dr=np.zeros_like(c)
        dl[...,1:]=np.diff(c,axis=-1)
        dr[...,:-1]=np.diff(c,axis=-1)
    same=((dl > 0) & (dr > 0)) | ((dl < 0) & (dr < 0))
    magnitude=np.minimum(np.minimum(2*np.abs(dl),2*np.abs(dr)),.5*np.abs(dl+dr))
    return np.where(same, np.sign(dl)*magnitude, 0.)


def fluxes(c, grid, flow, dispersion, boundaries, t, scheme="muscl_mc"):
    all_flux=[]
    for a,(h,q,d) in enumerate(zip(grid.spacing_xyz,flow.darcy_flux_m_s,
                                  dispersion.diagonal_m2_s)):
        axis=2-a
        v=np.moveaxis(c,axis,-1)
        lo,hi=boundaries[FACES[2*a]],boundaries[FACES[2*a+1]]
        periodic=lo.kind == "periodic"
        slope=mc_slopes(v,periodic) if scheme == "muscl_mc" else np.zeros_like(v)
        f=np.empty(v.shape[:-1]+(v.shape[-1]+1,))
        left=v[...,:-1]+.5*slope[...,:-1]
        right=v[...,1:]-.5*slope[...,1:]
        f[...,1:-1]=q*(left if q >= 0 else right)-flow.theta*d*np.diff(v,axis=-1)/h
        if periodic:
            face=q*(v[...,-1]+.5*slope[...,-1] if q >= 0 else v[...,0]-.5*slope[...,0])
            face=face-flow.theta*d*(v[...,0]-v[...,-1])/h
            f[...,0]=face; f[...,-1]=face
        else:
            for side,b in ((0,lo),(-1,hi)):
                edge=v[...,side]
                if b.kind == "closed":
                    f[...,side]=0.
                elif b.kind == "inflow_flux":
                    # Total, not just advective, prescribed mass flux.
                    f[...,side]=q*b.values(t,grid,a)
                elif b.kind == "outflow":
                    f[...,side]=q*edge
                elif b.kind == "dirichlet":
                    cb=b.values(t,grid,a)
                    inward=q > 0 if side == 0 else q < 0
                    adv=q*(cb if inward else edge)
                    grad=(edge-cb)/(h/2) if side == 0 else (cb-edge)/(h/2)
                    f[...,side]=adv-flow.theta*d*grad
        all_flux.append(np.moveaxis(f,-1,axis))
    return tuple(all_flux)


def concentration_rate(face_fluxes, grid, theta):
    rate=np.zeros(grid.shape)
    for a,(f,h) in enumerate(zip(face_fluxes,grid.spacing_xyz)):
        rate-=np.diff(f,axis=2-a)/(h*theta)
    return rate


def boundary_rates(face_fluxes, grid, boundaries):
    """Per-face IN and OUT kg/s. Periodic crossings are internal, not external input."""
    rates=np.zeros((6,2))
    for a,f in enumerate(face_fluxes):
        if boundaries[FACES[2*a]].kind == "periodic":
            continue
        for side,sign,offset in ((0,-1,0),(-1,1,1)):
            outward=sign*np.take(f,side,axis=2-a)*grid.face_area(a)
            rates[2*a+offset]=(-np.minimum(outward,0).sum(),np.maximum(outward,0).sum())
    return rates


def stable_step(grid, flow, dispersion, boundaries, cfl):
    # MC reconstruction may double the advective donor-cell loss coefficient.
    # A Dirichlet half-cell adds another diffusion face conductance.
    rate=0.
    for a,(h,u,d) in enumerate(zip(grid.spacing_xyz,flow.pore_velocity_m_s,
                                  dispersion.diagonal_m2_s)):
        extra=any(boundaries[FACES[2*a+i]].kind == "dirichlet" for i in (0,1))
        rate+=2*abs(u)/h+(3 if extra else 2)*d/h**2
    return cfl/rate if rate > 0 else np.inf
