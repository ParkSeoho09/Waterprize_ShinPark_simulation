from dataclasses import dataclass
import numpy as np
from .fv import fluxes,concentration_rate,boundary_rates,stable_step
from ..physics.boundary import check_boundaries
from ..analysis.diagnostics import mass,moments


@dataclass
class Result:
    times_s: np.ndarray
    concentration: np.ndarray  # saved frames [time,z,y,x]
    history: list             # diagnostics EVERY numerical step
    grid: object
    flow: object
    dispersion: object
    boundaries: dict
    numerical: dict


def solve(grid,flow,dispersion,boundaries,initial,*,end_s,save_times_s,
          max_dt_s,cfl=.8,scheme="muscl_mc",concentration_scale_kg_m3=.1,
          max_steps=1_000_000):
    check_boundaries(boundaries,flow,grid)
    if scheme not in ("muscl_mc","upwind"):
        raise ValueError("scheme must be muscl_mc or upwind")
    if not np.isfinite(end_s) or end_s <= 0 or not np.isfinite(max_dt_s) or max_dt_s <= 0:
        raise ValueError("end_s and max_dt_s must be finite and positive")
    if not np.isfinite(cfl) or not 0 < cfl <= .8:
        raise ValueError("require 0 < cfl <= 0.8 for this explicit method")
    if not np.isfinite(concentration_scale_kg_m3) or concentration_scale_kg_m3 <= 0:
        raise ValueError("positive fixed concentration scale required")
    if isinstance(max_steps,bool) or not isinstance(max_steps,int) or max_steps < 1:
        raise ValueError("max_steps must be a positive integer")
    c=np.asarray(initial,dtype=float).copy()
    eps=1e-12*concentration_scale_kg_m3

    def check_state(a):
        if a.shape != grid.shape or not np.all(np.isfinite(a)):
            raise FloatingPointError("invalid concentration shape or nonfinite concentration")
        if np.min(a) < -eps:
            raise FloatingPointError(f"negative concentration {np.min(a):.6g}; no clipping applied")

    check_state(c)
    if np.any(c < 0):
        raise ValueError("initial concentrations must be nonnegative")
    save=np.asarray(save_times_s,dtype=float)
    if save.ndim != 1 or save.size == 0 or not np.all(np.isfinite(save)) or np.any(save<0) \
            or np.any(save>end_s) or np.any(np.diff(save)<=0):
        raise ValueError("save_times_s must be strictly increasing within [0,end_s]")
    save=np.unique(np.r_[0.,save,end_s])
    events=[e for b in boundaries.values() for e in b.events if 0 < e < end_s]
    stops=np.unique(np.r_[save,events,end_s])
    limit=min(max_dt_s,stable_step(grid,flow,dispersion,boundaries,cfl))
    m0=mass(c,grid,flow.theta)
    cumulative=np.zeros((6,2))
    history=[]; fields=[c.copy()]; actual_times=[0.]
    t=0.; step=0; smallest_dt=np.inf; largest_dt=0.

    def record(local_residual,dt):
        fs=fluxes(c,grid,flow,dispersion,boundaries,t,scheme)
        rates=boundary_rates(fs,grid,boundaries)
        m=mass(c,grid,flow.theta)
        mi,mo=cumulative.sum(axis=0)
        denominator=m0+mi
        residual=m0+mi-m-mo
        bottom_water=max(flow.darcy_flux_m_s[2],0.)*grid.lengths_m[0]*grid.lengths_m[1]
        bottom_c=rates[5,1]/bottom_water if bottom_water > 0 and boundaries['z+'].kind == 'outflow' else np.nan
        history.append(dict(time_s=t,step=step,dt_s=dt,initial_kg=m0,in_kg=float(mi),
            stored_kg=m,out_kg=float(mo),bottom_out_kg=float(cumulative[5,1]),
            residual_kg=residual,relative_residual=abs(residual)/denominator if denominator>0 else np.nan,
            minimum_kg_m3=float(c.min()),maximum_kg_m3=float(c.max()),
            negative_mass_kg=float(np.minimum(c,0).sum()*flow.theta*grid.volume),
            local_residual_max_kg=local_residual,bottom_flux_kg_s=float(rates[5,1]),
            bottom_flux_concentration_kg_m3=float(bottom_c),
            depth_means_kg_m3=c.mean(axis=(1,2)).copy(),moments=moments(c,grid),
            face_cumulative_kg=cumulative.copy()))

    record(0.,0.)
    for stop in stops[1:]:
        while t < stop:
            if step >= max_steps:
                raise RuntimeError("max_steps exceeded")
            dt=min(limit,stop-t)
            if t+dt == t:
                raise FloatingPointError("time step cannot advance floating-point time")
            # Left limit at a discontinuity: the preceding interval uses its old
            # boundary value. Next interval starts at the exact event using new value.
            t2=np.nextafter(t+dt,t)
            f0=fluxes(c,grid,flow,dispersion,boundaries,t,scheme)
            a=c+dt*concentration_rate(f0,grid,flow.theta)
            check_state(a)
            f1=fluxes(a,grid,flow,dispersion,boundaries,t2,scheme)
            new=.5*c+.5*(a+dt*concentration_rate(f1,grid,flow.theta))
            check_state(new)
            integrated=tuple(.5*dt*(f+g) for f,g in zip(f0,f1))
            local=(new-c)*flow.theta*grid.volume
            for axis,face in enumerate(integrated):
                local+=np.diff(face,axis=2-axis)*grid.face_area(axis)
            local_error=float(np.max(np.abs(local)))
            cumulative+=.5*dt*(boundary_rates(f0,grid,boundaries)+boundary_rates(f1,grid,boundaries))
            c=new; t=stop if dt == stop-t else t+dt
            step+=1; smallest_dt=min(smallest_dt,dt); largest_dt=max(largest_dt,dt)
            record(local_error,dt)
        if np.any(save == stop):
            fields.append(c.copy()); actual_times.append(float(stop))
    numerical=dict(scheme=scheme,time_integrator="SSPRK2",dispersion_stencil="centered",
        backend="project-owned NumPy finite volumes",cfl=cfl,stability_dt_s=float(limit),
        requested_max_dt_s=max_dt_s,steps=step,min_dt_s=smallest_dt,max_dt_s=largest_dt,
        concentration_scale_kg_m3=concentration_scale_kg_m3,
        negative_tolerance_kg_m3=eps,clipping=False,mass_renormalization=False,
        max_local_residual_kg=max(h['local_residual_max_kg'] for h in history))
    return Result(np.array(actual_times),np.stack(fields),history,grid,flow,dispersion,boundaries,numerical)
