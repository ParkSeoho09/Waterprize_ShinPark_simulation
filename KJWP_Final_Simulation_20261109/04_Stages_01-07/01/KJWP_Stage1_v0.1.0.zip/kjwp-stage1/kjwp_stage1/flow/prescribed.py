"""This provider deliberately rejects spatial/time variation until flow coupling is verified."""
from dataclasses import dataclass
import numpy as np


@dataclass(frozen=True)
class ConstantFlow:
    theta: float
    porosity: float
    darcy_flux_m_s: tuple[float, float, float]

    def __post_init__(self):
        if not (np.isfinite(self.theta) and np.isfinite(self.porosity)
                and 0 < self.theta <= self.porosity <= 1):
            raise ValueError("require 0 < theta <= porosity <= 1")
        if len(self.darcy_flux_m_s) != 3 or not np.all(np.isfinite(self.darcy_flux_m_s)):
            raise ValueError("darcy_flux_m_s must contain three finite values")

    @property
    def pore_velocity_m_s(self):
        return tuple(q/self.theta for q in self.darcy_flux_m_s)

    def face_fluxes(self, grid):
        nz,ny,nx = grid.shape
        qx,qy,qz = self.darcy_flux_m_s
        return (np.full((nz,ny,nx+1),qx), np.full((nz,ny+1,nx),qy),
                np.full((nz+1,ny,nx),qz))
