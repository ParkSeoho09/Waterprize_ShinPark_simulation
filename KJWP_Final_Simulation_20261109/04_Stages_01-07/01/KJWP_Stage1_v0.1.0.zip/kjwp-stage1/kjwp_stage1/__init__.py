"""Stage 1 only: homogeneous water content, steady flow, conservative solute."""
__version__ = "0.1.0"
