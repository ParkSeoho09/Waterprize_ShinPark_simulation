import numpy as np


def mass(c,grid,theta):
    return float(c.sum()*theta*grid.volume)


def moments(c,grid):
    weight=float(c.sum())
    if weight <= 0:
        return (float("nan"),)*6
    out=[]
    for a,coord in enumerate(grid.centers_xyz):
        v=c.sum(axis=tuple(i for i in range(3) if i != 2-a))
        mean=float(np.dot(v,coord)/weight)
        var=float(np.dot(v,(coord-mean)**2)/weight)
        out.extend([mean,var])
    return tuple(out)


def relative_l1(c,exact):
    den=float(np.abs(exact).sum())
    return float(np.abs(c-exact).sum()/den) if den > 0 else float("nan")
