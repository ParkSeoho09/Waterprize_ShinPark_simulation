"""Boundary flux contract. All numerical face fluxes point in the positive axis direction."""
from dataclasses import dataclass
import numpy as np

FACES = ("x-", "x+", "y-", "y+", "z-", "z+")


@dataclass(frozen=True)
class Boundary:
    kind: str
    concentration_kg_m3: object = 0.0
    pulse_start_s: float = 0.0
    pulse_end_s: float | None = None
    # Bounds of a rectangular solute concentration patch in the two tangential axes.
    # The water flux is uniform across the whole inlet, including outside this patch.
    patch_m: tuple[tuple[float,float],tuple[float,float]] | None = None

    def __post_init__(self):
        if self.kind not in ("closed", "inflow_flux", "outflow", "dirichlet", "periodic"):
            raise ValueError(f"unsupported boundary kind: {self.kind}")
        c = np.asarray(self.concentration_kg_m3)
        if not np.all(np.isfinite(c)) or np.any(c < 0):
            raise ValueError("invalid boundary concentration")
        if not np.isfinite(self.pulse_start_s) or self.pulse_start_s < 0:
            raise ValueError("invalid pulse start")
        if self.pulse_end_s is not None and (not np.isfinite(self.pulse_end_s)
                or self.pulse_end_s <= self.pulse_start_s):
            raise ValueError("pulse end must exceed start")
        if self.patch_m is not None:
            p=np.asarray(self.patch_m, dtype=float)
            if p.shape != (2,2) or not np.all(np.isfinite(p)) or np.any(p[:,1] <= p[:,0]):
                raise ValueError("patch_m needs two increasing finite intervals")
            if self.kind not in ("inflow_flux", "dirichlet"):
                raise ValueError("only inflow_flux/dirichlet support patches")

    @property
    def events(self):
        return [self.pulse_start_s] + ([] if self.pulse_end_s is None else [self.pulse_end_s])

    def values(self, t, grid, axis_xyz):
        # Tangential arrays follow z,y,x order with the normal removed.
        coords = list(reversed(grid.centers_xyz))
        coords.pop(2-axis_xyz)
        shape = tuple(len(c) for c in coords)
        active = self.pulse_start_s <= t and (self.pulse_end_s is None or t < self.pulse_end_s)
        out = np.broadcast_to(np.asarray(self.concentration_kg_m3, dtype=float), shape).copy()
        if not active:
            return np.zeros(shape)
        if self.patch_m is not None:
            # patch order is ascending physical axes: y,z on x; x,z on y; x,y on z.
            intervals = list(reversed(self.patch_m))
            bounds = np.asarray(intervals)
            tangential_lengths = list(reversed(grid.lengths_m))
            tangential_lengths.pop(2-axis_xyz)
            if np.any(bounds[:,0] < 0) or np.any(bounds[:,1] > tangential_lengths):
                raise ValueError("patch lies outside the boundary")
            meshes = np.meshgrid(*coords, indexing="ij")
            for mesh, (lo,hi) in zip(meshes, intervals):
                out *= (mesh >= lo) & (mesh < hi)
        return out


def check_boundaries(boundaries, flow, grid):
    if set(boundaries) != set(FACES):
        raise ValueError("specify exactly all six boundary faces")
    for a,q in enumerate(flow.darcy_flux_m_s):
        lo,hi = boundaries[FACES[2*a]], boundaries[FACES[2*a+1]]
        if (lo.kind == "periodic") != (hi.kind == "periodic"):
            raise ValueError("periodic boundaries must be paired")
        for sign,b in ((-1,lo),(1,hi)):
            qn=sign*q
            if b.kind == "closed" and qn != 0:
                raise ValueError("closed wall conflicts with prescribed nonzero normal water flux")
            if b.kind == "inflow_flux" and qn >= 0:
                raise ValueError("inflow_flux requires inward water flux")
            if b.kind == "outflow" and qn <= 0:
                raise ValueError("outflow requires outward water flux")
            # Force shape and patch validation before a run starts.
            b.values(b.pulse_start_s, grid, a)
