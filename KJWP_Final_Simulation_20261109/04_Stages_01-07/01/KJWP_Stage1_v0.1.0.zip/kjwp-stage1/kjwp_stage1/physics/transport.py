from dataclasses import dataclass
import numpy as np


@dataclass(frozen=True)
class Dispersion:
    diagonal_m2_s: tuple[float,float,float]

    def __post_init__(self):
        if len(self.diagonal_m2_s) != 3 or not np.all(np.isfinite(self.diagonal_m2_s)) \
                or np.any(np.asarray(self.diagonal_m2_s) < 0):
            raise ValueError("only three finite, nonnegative diagonal dispersion coefficients supported")
