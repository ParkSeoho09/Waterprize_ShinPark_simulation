"""Reproducible numerical verification; synthetic benchmark values are not soil observations."""
from pathlib import Path
import time
import numpy as np
from ..core.grid import Grid
from ..flow.prescribed import ConstantFlow
from ..physics.transport import Dispersion
from ..physics.boundary import Boundary,FACES
from ..numerics.solver import solve
from ..analysis.diagnostics import relative_l1,moments
from ..io.results import write_json
from .analytical import gaussian_cell_average,cosine_cell_average


def flow_boundaries(flow):
    b={}
    for a,q in enumerate(flow.darcy_flux_m_s):
        for side,sign in ((0,-1),(1,1)):
            b[FACES[2*a+side]]=Boundary('inflow_flux' if q*sign<0 else 'outflow' if q*sign>0 else 'closed')
    return b


def gaussian_case(n,dt=.01,scheme='muscl_mc'):
    grid=Grid((1.,1.,1.),(n,n,n))
    u=(.04,-.03,.02); d=(.001,.0007,.0004)
    center=(.43,.53,.46); sigma=(.055,.06,.05); end=.4
    flow=ConstantFlow(.3,.45,tuple(.3*v for v in u))
    dispersion=Dispersion(d); b=flow_boundaries(flow)
    exact=lambda t:gaussian_cell_average(grid,t,center,sigma,u,d,.1)
    r=solve(grid,flow,dispersion,b,exact(0),end_s=end,save_times_s=[0.,.2,end],max_dt_s=dt,scheme=scheme)
    metrics=[]
    for i,t in enumerate(r.times_s[1:],start=1):
        ex=exact(t); actual=moments(r.concentration[i],grid); target=moments(ex,grid)
        center_error=[abs(actual[2*a]-target[2*a])/np.sqrt(target[2*a+1]) for a in range(3)]
        variance_error=[abs(actual[2*a+1]/target[2*a+1]-1) for a in range(3)]
        widths=np.sqrt(np.array(sigma)**2+2*np.array(d)*t)
        centers=np.array(center)+np.array(u)*t
        margin=float(np.min(np.minimum(centers,1-centers)/widths))
        full_mass=flow.theta*.1*(2*np.pi)**1.5*np.prod(sigma)
        metrics.append(dict(time_s=float(t),relative_l1=relative_l1(r.concentration[i],ex),
            center_error_in_sigma=center_error,relative_variance_error=variance_error,
            minimum_boundary_distance_in_sigma=margin,
            analytical_mass_truncated_fraction=float(1-ex.sum()*flow.theta*grid.volume/full_mass)))
    return r,metrics


def run_benchmarks(directory):
    out=Path(directory);out.mkdir(parents=True,exist_ok=True)
    start=time.monotonic(); checks=[]
    gaussian=[]; gaussian_fields=[]
    for n in (24,48,96):
        before=time.monotonic()
        r,m=gaussian_case(n)
        gaussian_fields.append(r.concentration[-1].copy())
        gaussian.append(dict(cells_per_axis=n,seconds=time.monotonic()-before,metrics=m,
            max_mass_residual=max(h['relative_residual'] for h in r.history),
            minimum_concentration=min(h['minimum_kg_m3'] for h in r.history)))
        print(f'Gaussian {n}^3: L1={m[-1]["relative_l1"]:.5g}',flush=True)
    fine=gaussian[-1]['metrics']
    ok=all(m['relative_l1']<=.05 and max(m['center_error_in_sigma'])<=.02
        and max(m['relative_variance_error'])<=.05 and m['minimum_boundary_distance_in_sigma']>=6
        for m in fine)
    checks.append(dict(name='3D Gaussian continuum solution at two positive times',passed=ok,
        targets=dict(relative_l1=.05,center_error_sigma=.02,relative_variance_error=.05),data=gaussian))
    errs=[g['metrics'][-1]['relative_l1'] for g in gaussian]
    # An explicit small-time-step check at the finest mesh prevents spatial
    # refinement from hiding a time error floor.
    half_dt_r,half_dt_metrics=gaussian_case(96,dt=.005)
    time_contamination=abs(half_dt_metrics[-1]['relative_l1']-errs[-1])/errs[-1]
    coarse,medium,fine_field=gaussian_fields
    restricted=fine_field.reshape(48,2,48,2,48,2).mean(axis=(1,3,5))
    last_grid_difference=relative_l1(medium,restricted)
    spatial_pass=errs[2]<errs[1]<errs[0] and errs[-1]<=.05 and time_contamination<.05 and last_grid_difference<.05
    checks.append(dict(name='Gaussian spatial convergence (24,48,96)',passed=spatial_pass,
        relative_l1=errs,observed_orders=[float(np.log2(errs[i]/errs[i+1])) for i in (0,1)],
        finest_half_dt_l1=half_dt_metrics[-1]['relative_l1'],
        finest_error_change_on_dt_halving=time_contamination,
        medium_vs_restricted_fine_relative_l1=last_grid_difference))
    _,up=gaussian_case(48,scheme='upwind')
    checks.append(dict(name='MC reduces numerical spreading compared with upwind',
        passed=gaussian[1]['metrics'][-1]['relative_l1']<up[-1]['relative_l1'],
        muscl_mc=gaussian[1]['metrics'][-1],upwind=up[-1]))

    diffusion=[]; closed={f:Boundary('closed') for f in FACES}
    d=(.01,.008,.006); bg=.03; amp=.7; end=2.
    for n in (8,16,32):
        g=Grid((1.,1.,1.),(n,n,n)); flow=ConstantFlow(.3,.45,(0.,0.,0.)); dis=Dispersion(d)
        initial=cosine_cell_average(g,0,d,bg,amp)
        r=solve(g,flow,dis,closed,initial,end_s=end,save_times_s=[0,end],max_dt_s=.005)
        exact=cosine_cell_average(g,end,d,bg,amp)
        error=relative_l1(r.concentration[-1]-bg,exact-bg)
        diffusion.append(dict(cells_per_axis=n,fluctuation_relative_l1=error,
            max_mass_residual=max(h['relative_residual'] for h in r.history)))
    checks.append(dict(name='Closed 3D diffusion cosine continuum solution',
        passed=diffusion[-1]['fluctuation_relative_l1']<=.02 and all(
            diffusion[i+1]['fluctuation_relative_l1']<diffusion[i]['fluctuation_relative_l1'] for i in (0,1)),
        target_fluctuation_relative_l1=.02,data=diffusion))
    checks.append(dict(name='Closed system mass conservation',
        passed=max(v['max_mass_residual'] for v in diffusion)<1e-6,
        target=1e-6,measured=max(v['max_mass_residual'] for v in diffusion)))

    # Discrete diffusion eigenmode isolates time integration from spatial error.
    temporal=[]; n=12; d=(.003,.002,.001); end=1.
    g=Grid((1.,1.,1.),(n,n,n)); f=ConstantFlow(.3,.45,(0.,0.,0.)); dis=Dispersion(d)
    initial=cosine_cell_average(g,0.,d,bg,amp)
    exact=cosine_cell_average(g,end,d,bg,amp,discrete=True)
    states=[]
    for dt in (.2,.1,.05):
        r=solve(g,f,dis,closed,initial,end_s=end,save_times_s=[0,end],max_dt_s=dt)
        temporal.append(dict(max_dt_s=dt,actual_max_dt_s=r.numerical['max_dt_s'],
            fluctuation_relative_l1=relative_l1(r.concentration[-1]-bg,exact-bg)))
        states.append(r.concentration[-1])
    err=[v['fluctuation_relative_l1'] for v in temporal]
    order=[float(np.log2(err[i]/err[i+1])) for i in (0,1)]
    last_diff=relative_l1(states[-1]-bg,states[-2]-bg)
    checks.append(dict(name='Time convergence against exact semidiscrete diffusion mode',
        passed=all(e>0 for e in err) and err[2]<err[1]<err[0] and min(order)>1.8 and last_diff<.05,
        data=temporal,observed_orders=order,last_two_fluctuation_difference=last_diff))

    # Independent Q*C*duration calculation, with patch edges aligned to face cells.
    g=Grid((.6,.2,.3),(24,8,20)); f=ConstantFlow(.3,.45,(0.,0.,3e-6)); dis=Dispersion((2e-9,2e-9,2e-8))
    b=flow_boundaries(f); b['z-']=Boundary('inflow_flux',.04,137.,2354.,((.2,.4),(.05,.15)))
    r=solve(g,f,dis,b,np.zeros(g.shape),end_s=50000.,save_times_s=[0,50000.],max_dt_s=333.)
    expected=3e-6*.2*.1*.04*(2354-137)
    measured=r.history[-1]['in_kg']; mass_res=max(h['relative_residual'] for h in r.history if np.isfinite(h['relative_residual']))
    checks.append(dict(name='Known pulsed patch input and open outlet budget',
        passed=abs(measured/expected-1)<1e-12 and mass_res<1e-6,
        independently_expected_input_kg=expected,numerical_input_kg=measured,
        max_relative_mass_residual=mass_res,bottom_out_kg=r.history[-1]['bottom_out_kg'],
        final_stored_kg=r.history[-1]['stored_kg']))

    data=dict(status='PASS' if all(c['passed'] for c in checks) else 'FAIL',checks=checks,
        elapsed_s=time.monotonic()-start,external_comparison=dict(OpenGeoSys='NOT_RUN',
            reason='OpenGeoSys executable is not installed; no cross-validation claim is made.'),
        scope='Numerical verification of synthetic constant-flow ADE; not physical calibration.')
    write_json(out/'validation.json',data)
    write_markdown(out/'VALIDATION_REPORT.md',data)
    return data


def write_markdown(path,data):
    lines=['# Stage 1 수치검증 결과', '',f"상태: **{data['status']}**. 자동 실행으로 생성한 수치이며 실측 연구결과가 아니다.",'',
        '| 검증 | 결과 |','|---|---|']
    lines += [f"| {c['name']} | {'PASS' if c['passed'] else 'FAIL'} |" for c in data['checks']]
    for c in data['checks']:
        if 'relative_l1' in c:
            lines += ['', 'Gaussian 공간격자 상대 L1 오차: '+', '.join(f'{v:.4%}' for v in c['relative_l1'])]
    lines += ['', '**OpenGeoSys 교차검증: 미실행.** 독립 소프트웨어 비교가 남아 있으므로 전체 Stage 1 검증 완료로 표현하지 않는다.',
        '', '전체 조건·오차·축별 중심·분산·관측 수렴차수는 `validation.json`을 참조한다.']
    Path(path).write_text('\n'.join(lines)+'\n',encoding='utf-8')
