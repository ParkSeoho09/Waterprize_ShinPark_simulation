"""Independent continuum cell averages; Gaussian integration uses scipy.special.erf."""
import numpy as np
from scipy.special import erf


def gaussian_cell_average(grid,t,center_xyz,sigma_xyz,velocity_xyz,dispersion_xyz,peak):
    if any(s<=0 for s in sigma_xyz):
        raise ValueError("Gaussian sigma must be positive")
    factors=[]
    for edges,c,s,u,d,h in zip(grid.edges_xyz,center_xyz,sigma_xyz,velocity_xyz,
                                dispersion_xyz,grid.spacing_xyz):
        width=np.sqrt(s*s+2*d*t)
        integral=s*np.sqrt(np.pi/2)*np.diff(erf((edges-c-u*t)/(np.sqrt(2)*width)))
        factors.append(integral/h)
    x,y,z=factors
    return peak*z[:,None,None]*y[None,:,None]*x[None,None,:]


def cosine_cell_average(grid,t,dispersion_xyz,background,amplitude,discrete=False):
    """Closed-wall product cosine; discrete=True gives exact spatial semidiscrete mode."""
    factors=[]; decay=0.
    for edges,L,h,d in zip(grid.edges_xyz,grid.lengths_m,grid.spacing_xyz,dispersion_xyz):
        factors.append(np.diff(np.sin(np.pi*edges/L))/(np.pi*h/L))
        decay+=4*d*np.sin(np.pi*h/(2*L))**2/h**2 if discrete else d*(np.pi/L)**2
    x,y,z=factors
    return background*(1+amplitude*np.exp(-decay*t)*z[:,None,None]*y[None,:,None]*x[None,None,:])
