"""Concentrations use a declared mass basis; NO3 and NO3-N never mix silently."""
import numpy as np


def concentration_to_si(value, unit, basis):
    if basis not in ("NO3", "NO3-N"):
        raise ValueError("nitrate_basis must explicitly be NO3 or NO3-N")
    factors = {"kg/m3": 1.0, "mg/L": 1.e-3}
    if unit not in factors:
        raise ValueError("concentration unit must be kg/m3 or mg/L")
    a = np.asarray(value, dtype=float)
    if not np.all(np.isfinite(a)) or np.any(a < 0):
        raise ValueError("concentrations must be finite and nonnegative")
    out = a*factors[unit]
    return float(out) if out.ndim == 0 else out


def si_to_mg_l(value):
    return np.asarray(value)*1000
