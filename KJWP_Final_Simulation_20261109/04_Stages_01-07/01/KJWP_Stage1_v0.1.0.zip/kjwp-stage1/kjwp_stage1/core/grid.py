"""Public coordinates are x,y,z; array axes are z,y,x. z is depth positive down."""
from dataclasses import dataclass
import numpy as np


@dataclass(frozen=True)
class Grid:
    lengths_m: tuple[float, float, float]
    cells_xyz: tuple[int, int, int]

    def __post_init__(self):
        if len(self.lengths_m) != 3 or len(self.cells_xyz) != 3:
            raise ValueError("grid needs three lengths and three cell counts")
        if any(not np.isfinite(v) or v <= 0 for v in self.lengths_m):
            raise ValueError("lengths_m must be finite and positive")
        if any(isinstance(n, bool) or not isinstance(n, (int, np.integer)) or n < 2
               for n in self.cells_xyz):
            raise ValueError("each axis requires an integer cell count >= 2")

    @property
    def shape(self):
        return tuple(reversed(self.cells_xyz))

    @property
    def spacing_xyz(self):
        return tuple(L/n for L, n in zip(self.lengths_m, self.cells_xyz))

    @property
    def volume(self):
        return float(np.prod(self.spacing_xyz))

    @property
    def centers_xyz(self):
        return tuple((np.arange(n)+0.5)*h for n,h in zip(self.cells_xyz, self.spacing_xyz))

    @property
    def edges_xyz(self):
        return tuple(np.linspace(0, L, n+1) for L,n in zip(self.lengths_m, self.cells_xyz))

    def mesh_zyx(self):
        x,y,z = self.centers_xyz
        return np.meshgrid(z,y,x,indexing="ij")

    def face_area(self, axis_xyz):
        return self.volume/self.spacing_xyz[axis_xyz]
