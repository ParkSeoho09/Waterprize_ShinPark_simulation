"""JSON input with strict key checking. All non-concentration quantities are SI."""
from pathlib import Path
import json
import numpy as np
from .grid import Grid
from .units import concentration_to_si
from ..flow.prescribed import ConstantFlow
from ..physics.transport import Dispersion
from ..physics.boundary import Boundary,check_boundaries
from ..validation.analytical import gaussian_cell_average,cosine_cell_average


def keys(d, allowed, required=()):
    if not isinstance(d,dict):
        raise ValueError("configuration section must be an object")
    unknown=set(d)-set(allowed); missing=set(required)-set(d)
    if unknown or missing:
        raise ValueError(f"unknown keys {sorted(unknown)}; missing keys {sorted(missing)}")


def build(config,base_dir=Path('.')):
    keys(config,("schema_version","nitrate_basis","concentration_unit","grid","flow",
                 "dispersion_m2_s","boundaries","initial","time","numerics","description"),
         ("schema_version","nitrate_basis","concentration_unit","grid","flow",
          "dispersion_m2_s","boundaries","initial","time"))
    if config['schema_version'] != 1:
        raise ValueError("unsupported schema_version")
    basis=config['nitrate_basis']; unit=config['concentration_unit']
    cv=lambda v: concentration_to_si(v,unit,basis)
    cv(0.)
    g=config['grid']; keys(g,('lengths_m','cells_xyz'),('lengths_m','cells_xyz'))
    grid=Grid(tuple(g['lengths_m']),tuple(g['cells_xyz']))
    f=config['flow']; keys(f,('theta','porosity','darcy_flux_m_s'),('theta','porosity','darcy_flux_m_s'))
    flow=ConstantFlow(f['theta'],f['porosity'],tuple(f['darcy_flux_m_s']))
    dispersion=Dispersion(tuple(config['dispersion_m2_s']))
    boundaries={}
    for face,b in config['boundaries'].items():
        keys(b,('kind','concentration','pulse_start_s','pulse_end_s','patch_m'),('kind',))
        boundaries[face]=Boundary(b['kind'],cv(b.get('concentration',0.)),
            b.get('pulse_start_s',0.),b.get('pulse_end_s'),
            tuple(tuple(v) for v in b['patch_m']) if 'patch_m' in b else None)
    check_boundaries(boundaries,flow,grid)
    i=config['initial']
    if not isinstance(i,dict) or 'kind' not in i:
        raise ValueError("initial.kind required")
    if i['kind']=='uniform':
        keys(i,('kind','concentration'),('kind','concentration'))
        initial=np.full(grid.shape,cv(i['concentration']))
    elif i['kind']=='gaussian':
        keys(i,('kind','peak','center_m','sigma_m'),('kind','peak','center_m','sigma_m'))
        for field in ('center_m','sigma_m'):
            if len(i[field]) != 3 or not np.all(np.isfinite(i[field])):
                raise ValueError("Gaussian parameters need three finite values")
        initial=gaussian_cell_average(grid,0.,i['center_m'],i['sigma_m'],(0.,)*3,(0.,)*3,cv(i['peak']))
    elif i['kind']=='cosine':
        keys(i,('kind','background','amplitude'),('kind','background','amplitude'))
        if not np.isfinite(i['amplitude']) or not 0 <= i['amplitude'] < 1:
            raise ValueError("cosine amplitude must lie in [0,1)")
        initial=cosine_cell_average(grid,0.,dispersion.diagonal_m2_s,cv(i['background']),i['amplitude'])
    elif i['kind']=='npy':
        keys(i,('kind','path'),('kind','path'))
        initial=cv(np.load(Path(base_dir)/i['path'],allow_pickle=False))
    else:
        raise ValueError("initial.kind must be uniform, gaussian, cosine or npy")
    if initial.shape != grid.shape:
        raise ValueError(f"initial shape {initial.shape} != required z,y,x {grid.shape}")
    t=config['time']; keys(t,('end_s','max_dt_s','save_times_s'),('end_s','max_dt_s','save_times_s'))
    n=config.get('numerics',{})
    keys(n,('scheme','cfl','concentration_scale','max_steps'))
    scale=cv(n['concentration_scale']) if 'concentration_scale' in n else max(
        float(initial.max()), max(float(np.max(b.concentration_kg_m3)) for b in boundaries.values()), 1.e-3)
    return grid,flow,dispersion,boundaries,initial,dict(end_s=t['end_s'],max_dt_s=t['max_dt_s'],
        save_times_s=t['save_times_s'],scheme=n.get('scheme','muscl_mc'),cfl=n.get('cfl',.8),
        concentration_scale_kg_m3=scale,max_steps=n.get('max_steps',1_000_000))


def load(path):
    path=Path(path)
    config=json.loads(path.read_text(encoding='utf-8'))
    return config,build(config,path.parent)
