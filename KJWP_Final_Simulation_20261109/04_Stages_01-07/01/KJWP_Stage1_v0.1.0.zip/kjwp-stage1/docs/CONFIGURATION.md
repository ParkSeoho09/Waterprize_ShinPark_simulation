# 설정파일 사용법

`configs/column_pulse.json`을 복사해 변경한다. 계산 단위는 SI이며 농도만 최상위 `concentration_unit`에 따른다. 지정하지 않은 알 수 없는 키는 거부한다.

| 항목 | 의미·허용값 |
|---|---|
| schema_version | 현재 1 |
| nitrate_basis | NO3 또는 NO3-N, 필수. 실행 안에서 기준 자동변환 없음 |
| concentration_unit | mg/L 또는 kg/m3 |
| grid.lengths_m | [Lx,Ly,Lz], 모두 양수 |
| grid.cells_xyz | [nx,ny,nz], 축마다 2 이상 정수 |
| flow.theta | 0<θ≤porosity |
| flow.porosity | θ≤공극률≤1 |
| flow.darcy_flux_m_s | [qx,qy,qz]. 아래쪽 유동은 양의 qz |
| dispersion_m2_s | [Dx,Dy,Dz], 각 성분 0 이상 |
| initial.kind | uniform, gaussian, cosine, npy |
| time.end_s | 종료시각, 양수 |
| time.max_dt_s | 최대 계산 시간간격. 안정 제한이 더 작으면 자동 감소 |
| time.save_times_s | 엄격히 증가하는 3D 출력 시각. 0과 종료시각은 자동 포함 |
| numerics.scheme | muscl_mc(기본) 또는 upwind |
| numerics.cfl | 0보다 크고 0.8 이하 |
| numerics.concentration_scale | 현재 농도 단위의 고정 농도스케일. 음수 판정에 사용 |
| numerics.max_steps | 최대 계산 단계수, 기본 1,000,000 |

## 초기조건

- uniform: `{"kind":"uniform","concentration":0}`
- gaussian: `{"kind":"gaussian","peak":40,"center_m":[0.3,0.1,0.1],"sigma_m":[0.03,0.02,0.02]}`. peak는 연속 Gaussian의 최대값이며 셀 평균은 이보다 작을 수 있다.
- cosine: `{"kind":"cosine","background":20,"amplitude":0.7}`. 0≤amplitude<1. 닫힌 확산 시험용이다.
- npy: `{"kind":"npy","path":"initial.npy"}`. 설정파일 기준 상대경로. [nz,ny,nx] 형태의 양수 배열, 단위는 concentration_unit.

## 경계조건

여섯 면 x-,x+,y-,y+,z-,z+를 모두 지정한다. 지표는 z-, 바닥은 z+다.

```json
"z-": {
  "kind": "inflow_flux",
  "concentration": 40,
  "pulse_start_s": 0,
  "pulse_end_s": 14400,
  "patch_m": [[0.2, 0.4], [0.05, 0.15]]
},
"z+": {"kind": "outflow"}
```

위 예는 x=0.2~0.4 m, y=0.05~0.15 m의 **질산염 공급 농도** 패치다. 물 플럭스는 표면 전체에서 일정하다. 펄스 전후에는 유입수 농도만 0이 되며 물은 계속 들어간다.

patch_m의 두 구간 순서: x면에서 [y,z], y면에서 [x,z], z면에서 [x,y]. 구간은 [하한,상한)이며 면 셀 중심에 적용한다. 패치를 생략하면 전면 공급이다. `concentration`에 면 형태와 같은 2D 배열을 주는 것도 가능하며 배열 차원은 z,y,x 중 법선 방향을 제거한 순서다.

밀폐면은 해당 방향의 q가 0이어야 한다. q 방향을 바꾸면 inflow_flux/outflow 위치도 바꿔야 한다. 역류를 0으로 숨겨 처리하지 않는다. 주기경계는 같은 축 양 끝에 쌍으로 지정해야 한다.

## 원본 결과

`fields.npz`는 `np.load(..., allow_pickle=False)`로 읽는다.

| 키 | 의미 |
|---|---|
| C_kg_m3 | [time,z,y,x] 3D 농도 배열 |
| times_s | 저장 시각 |
| x_m,y_m,z_m | 셀 중심 좌표 |
| theta | [z,y,x] 일정 함수율 배열 |
| qx_m_s | [z,y,x_face] 물 플럭스 |
| qy_m_s | [z,y_face,x] 물 플럭스 |
| qz_m_s | [z_face,y,x] 물 플럭스 |
| D_diagonal_m2_s | [Dx,Dy,Dz] |
| nitrate_basis | 실행에서 사용한 질량 기준 |

`mass_balance.csv`와 `boundary_mass.csv`는 kg, `breakthrough.csv`는 mg/L, `metrics.csv`는 m와 m²다. 후속 보고서에 사용할 때 단위와 NO3/NO3-N 기준을 함께 표시한다.
