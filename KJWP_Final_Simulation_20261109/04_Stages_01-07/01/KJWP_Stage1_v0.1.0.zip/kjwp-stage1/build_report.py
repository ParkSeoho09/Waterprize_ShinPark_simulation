"""Rebuild the offline results summary from existing numerical output (no PDE solve)."""
from pathlib import Path
import csv,html,json


def main():
    root=Path(__file__).resolve().parent
    validation=json.loads((root/'outputs/verification/validation.json').read_text())
    with (root/'outputs/column_pulse/mass_balance.csv').open() as f:
        history=list(csv.DictReader(f))
    final=history[-1]
    spatial=next(c for c in validation['checks'] if c['name'].startswith('Gaussian spatial'))
    data=[(24,spatial['relative_l1'][0]),(48,spatial['relative_l1'][1]),(96,spatial['relative_l1'][2])]
    cells=''.join(f'<tr><td>{n}³</td><td>{e:.4%}</td></tr>' for n,e in data)
    tests=''.join(f'<tr><td>{html.escape(c["name"])}</td><td class="pass">'
        f'{"PASS" if c["passed"] else "FAIL"}</td></tr>' for c in validation['checks'])
    record=json.loads((root/'outputs/column_pulse/run_metadata.json').read_text())
    document='''<!doctype html><html lang="ko"><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>KJWP Stage 1 — 계산 결과</title>
<style>
*{box-sizing:border-box}body{margin:0;background:#f5f7fa;color:#202b3c;font:16px/1.7 system-ui,sans-serif}
main{max-width:1120px;margin:auto;padding:38px 24px 70px}h1{font-size:34px;letter-spacing:-1px;line-height:1.3}
h2{font-size:23px;margin-top:42px}.label{color:#426ba6;font-size:13px;font-weight:700;letter-spacing:2px}
.lead{font-size:19px;max-width:900px}.note{padding:18px 22px;border-left:4px solid #d99a2b;background:#fff7e7}
.cards{display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin:25px 0}
.card{padding:20px;border:1px solid #dae1ec;border-radius:12px;background:white}.number{font-size:28px;font-weight:750;color:#225e9a}
img{max-width:100%;height:auto;background:white;border:1px solid #d9e0ea;border-radius:8px}
table{border-collapse:collapse;background:white;width:100%;font-size:14px}td,th{text-align:left;padding:10px 14px;border-bottom:1px solid #dde3eb}
th{background:#eaf0f8}.pass{color:#18704d;font-weight:700}.grid{display:grid;grid-template-columns:1fr 1fr;gap:24px}
a{color:#1d5eaa}code{font-size:14px;background:#e8edf3;padding:2px 5px;border-radius:4px}.caption{color:#5d6878;font-size:14px}
@media(max-width:720px){h1{font-size:28px}.cards,.grid{grid-template-columns:1fr}main{padding:25px 16px}}
</style><main><div class="label">KJWP 2026 · STAGE 1 · v0.1.0</div>
<h1>3D 질산염 수송 엔진<br>실행 결과와 수치검증</h1>
<p class="lead">일정한 함수율과 물 플럭스에서 질산염의 이동·분산·하부 유출을 계산했다.
아래 그림과 애니메이션은 저장한 실제 3D 농도 배열에서 생성했다.</p>
<p class="note"><strong>수치검증 범위:</strong> 해석해·수렴성·보존성 검증 통과.
OpenGeoSys 비교와 실제 토양 파라미터 보정은 미실행이다. 예시 조건은 가상 값이며 정화 반응은 포함하지 않았다.</p>
<div class="cards">
<div class="card"><div class="number">{input_mg:.2f} mg</div>예시의 총 질산염 공급량<br><small>NO3 질량 기준</small></div>
<div class="card"><div class="number">{l1:.3%}</div>96³ Gaussian 상대 L1 오차<br><small>t=0.4 s, 가상 검증 문제</small></div>
<div class="card"><div class="number">{mass:.2e}</div>예시 최종 상대 질량수지 잔차<br><small>농도 정확도와 별도 지표</small></div>
</div>
<h2>예시: 표면의 질산염 펄스가 아래로 이동</h2>
<p>영역 0.6×0.2×0.3 m, 48×16×30 셀, 함수율 0.30, 공극률 0.45,
하향 Darcy 플럭스 10⁻⁶ m/s. 표면 전체로 물이 들어가며,
x=0.2~0.4 m · y=0.05~0.15 m 패치에서만 처음 4시간 동안 40 mg/L의 질산염을 공급했다.
분산계수는 Dx=Dy=2×10⁻⁹, Dz=2×10⁻⁸ m²/s이다.</p>
<img src="outputs/column_pulse/figures/overview.png" alt="3방향 농도 단면, 3D 분포, 통과곡선, 질량수지">
<p class="caption">아래로 갈수록 깊은 좌표다. 3D 점 그림은 전역 최대농도의 2%를 넘는 셀 중심을 일부 표시했다.
BTC는 매 시간단계의 계산값을 사용한다. 저장량 감소는 하부 유출이며 질산염 제거가 아니다.</p>
<img src="outputs/column_pulse/figures/transport.gif" alt="계산 농도장의 XZ 단면 시간 변화">
<p class="caption">고정된 농도 색 범위로 표시한 XZ 단면. 화면상 분포 이동을 임의 생성하지 않았다.</p>
<h2>수치검증</h2><div class="grid"><div><table><tr><th>Gaussian 격자</th><th>상대 L1 오차</th></tr>{cells}</table>
<p>공간격자 관측 수렴차수는 약 {order1:.2f}, {order2:.2f}이다.
시간 수렴은 공간오차를 분리한 확산 고유모드에서 약 2차로 확인했다.</p></div>
<div><table><tr><th>검증</th><th>결과</th></tr>{tests}</table></div></div>
<p>회귀시험 25개 통과. 입력 오류, q와 u의 구분, 6방향 유입·유출,
주기경계, 지정농도 확산, 펄스 공급량, 고 Peclet 수의 양수 유지, 출력 재로딩 등을 포함한다.</p>
<h2>파일과 재실행</h2>
<ul><li><a href="README.md">실행 안내 · README</a></li>
<li><a href="docs/CONFIGURATION.md">입력값과 단위 설명</a> / <a href="docs/METHODS.md">계산식·수치법·출처</a></li>
<li><a href="outputs/verification/validation.json">검증 수치 전체</a> / <a href="outputs/unit_tests.txt">회귀시험 기록</a></li>
<li><a href="outputs/column_pulse/fields.npz">3D 원본 NPZ</a> / <a href="outputs/column_pulse/mass_balance.csv">질량수지 CSV</a>
 / <a href="outputs/column_pulse/breakthrough.csv">BTC CSV</a></li>
<li><a href="outputs/column_pulse/run_metadata.json">실행조건·단위·의존성 버전·입력 해시</a></li></ul>
<p><code>python -m kjwp_stage1 run configs/column_pulse.json --out outputs/new_run --plots --gif</code></p>
<p class="caption">입력 SHA256: {sha}. 코드와 출력 원본은 같은 패키지에 포함되어 있다.</p>
</main></html>'''
    # Only replace known tokens so CSS braces remain intact.
    values=dict(input_mg=f'{float(final["in_kg"])*1e6:.2f}',l1=f'{data[-1][1]:.3%}',
        mass=f'{float(final["relative_residual"]):.2e}',cells=cells,tests=tests,
        order1=f'{spatial["observed_orders"][0]:.2f}',order2=f'{spatial["observed_orders"][1]:.2f}',
        sha=record['input_sha256'])
    for key,value in values.items():
        import re
        document=re.sub(r'\{'+key+r'(?::[^}]*)?\}',lambda _:value,document)
    (root/'RESULTS.html').write_text(document,encoding='utf-8')


if __name__=='__main__':main()
