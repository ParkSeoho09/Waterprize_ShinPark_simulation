# 인용 문헌과 적용 범위

2026-11-07. DOI 서지를 출판사 등록 기록과 대조했다. Odsæter 논문은 저자 공개 원문의 유량 투영 절을 확인했고, Zalesak 논문은 OSTI에 공개된 초록과 서지를 확인했다. 아래 번호는 METHODS.md와 결과 보고서에서 공통으로 사용한다.

| 번호 | 논문 | 이번 계산에 사용한 내용 |
|---|---|---|
| [1] | Odsæter, L. H., Wheeler, M. F., Kvamsdal, T. & Larson, M. G. (2017). *Postprocessing of non-conservative flux for compatibility with transport in heterogeneous media*. Computer Methods in Applied Mechanics and Engineering, 315, 799–830. [DOI 10.1016/j.cma.2016.11.018](https://doi.org/10.1016/j.cma.2016.11.018) · [저자 공개 원문](https://arxiv.org/abs/1605.04076) | 면 유량을 가중 최소제곱으로 보정해 셀별 수지를 충족하는 원리. 여기서는 균질 직교 격자에 맞춰 면적/중심 간 거리 가중치와 저장량 변화 항을 적용했다. |
| [2] | Zalesak, S. T. (1979). *Fully multidimensional flux-corrected transport algorithms for fluids*. Journal of Computational Physics, 31(3), 335–362. [DOI 10.1016/0021-9991(79)90051-2](https://doi.org/10.1016/0021-9991%2879%2990051-2) · [OSTI 기록](https://www.osti.gov/biblio/5312964) | 저차 보존 플럭스에 면별 보정 플럭스를 더하고, 양쪽 셀의 허용량으로 보정량을 제한하는 FCT 원리. |
| [3] | Gottlieb, S. & Shu, C.-W. (1998). *Total variation diminishing Runge–Kutta schemes*. Mathematics of Computation, 67(221), 73–85. [DOI 10.1090/S0025-5718-98-00913-2](https://doi.org/10.1090/S0025-5718-98-00913-2) | 제한된 Euler 단계를 조합하는 2단 SSP Runge–Kutta 수송 시간적분. |
| [4] | Celia, M. A., Bouloutas, E. T. & Zarba, R. L. (1990). *A general mass-conservative numerical solution for the unsaturated flow equation*. Water Resources Research, 26(7), 1483–1496. [DOI 10.1029/WR026i007p01483](https://doi.org/10.1029/WR026i007p01483) | 기존 자작 모델의 혼합형 Richards 물수지 기준. |
| [5] | van Genuchten, M. Th. (1980). *A Closed-form Equation for Predicting the Hydraulic Conductivity of Unsaturated Soils*. Soil Science Society of America Journal, 44(5), 892–898. [DOI 10.2136/sssaj1980.03615995004400050002x](https://doi.org/10.2136/sssaj1980.03615995004400050002x) | 기존 토양 보수곡선과 불포화 수리전도 함수. |
| [6] | Mualem, Y. (1976). *A new model for predicting the hydraulic conductivity of unsaturated porous media*. Water Resources Research, 12(3), 513–522. [DOI 10.1029/WR012i003p00513](https://doi.org/10.1029/WR012i003p00513) | 기존 VG–Mualem 상대투수도 함수의 바탕. |

공식 소프트웨어 자료

- OGS 6.5.9 RichardsComponentTransport [생성 코드](https://github.com/ufz/ogs/blob/6.5.9/ProcessLib/RichardsComponentTransport/CreateRichardsComponentTransportProcess.cpp)와 [FEM 조립식](https://github.com/ufz/ogs/blob/6.5.9/ProcessLib/RichardsComponentTransport/RichardsComponentTransportFEM-impl.h). 기존 수송식의 계수 대응은 EQUATION_MAPPING.md에 유도했다.
- OGS 6.5.9 [불포화 물질 이동](https://www.opengeosys.org/6.5.9/docs/benchmarks/richards-flow/richards-component-transport/)과 [ComponentTransport의 FCT 예제](https://www.opengeosys.org/6.5.9/docs/benchmarks/hydro-component/flux_corrected_transport/). 기존 RCT 생성 코드에는 해당 안정화 입력을 읽는 부분이 없다. 이번 계산은 RCT 압력장과 별도 보존형 수송을 연결했다.
- 기존 모델의 구현 배경과 그때 인용한 자료는 `source/kjwp-simulator-3_1/docs/`에 함께 보존했다.
