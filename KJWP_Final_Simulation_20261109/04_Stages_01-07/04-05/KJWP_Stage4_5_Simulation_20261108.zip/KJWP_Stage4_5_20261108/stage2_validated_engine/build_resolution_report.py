"""Generate the research report from completed runs and check delivery evidence."""
import base64
import csv
import hashlib
import html
import json
import re

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

from compare_results import ROOT, RUNS, baseline, read_run
from conservative_transport import CartesianMesh


REPORT = 'KJWP_Stage2_Resolution_Report_20261107.html'


def read_json(path):
    return json.loads(path.read_text(encoding='utf-8'))


def final_percent(comparisons, pair, grid='union'):
    return 100*comparisons[pair][-1][f'L1_relative_{grid}']


def relative_change(grid, a, b):
    return float(np.sum(np.abs(a-b)*grid.volume)/np.sum(np.abs(b)*grid.volume))


def weighted_profile(run):
    mesh,_,fields = run
    x,y,z = mesh.edges_xyz
    def overlap(edges, lo, hi):
        width = np.maximum(0,np.minimum(edges[1:],hi)-np.maximum(edges[:-1],lo))
        return width/width.sum()
    averages = np.einsum('i,j,ijk->k',overlap(z,.17,.23),overlap(y,.065,.09),fields[-1])
    return x*100,averages*1000


def embed(path, alt):
    data = base64.b64encode(path.read_bytes()).decode()
    return f'<img alt="{html.escape(alt)}" src="data:image/png;base64,{data}">'


def plot_results(comparisons, output):
    plt.rcParams.update({'font.size':11,'axes.spines.top':False,'axes.spines.right':False})
    old_fv, old_ogs = baseline()
    fine_fv = read_run('fv_N96_dt10','custom/fields.npz',None)
    coarse = read_run('graded_s1_dt10','replay_fields.npz','mass_bulk_kg_m3')
    fine = read_run('graded_s4_dt10','replay_fields.npz','mass_bulk_kg_m3')
    native = read_run('graded_s4_dt10','replay_fields.npz','raw_mass_bulk_kg_m3')
    colors = ('#1d648f','#bc5136','#178471')
    fig, axes = plt.subplots(1,2,figsize=(11,4.2),sharey=True)
    for ax,curves,title in zip(axes,[(old_fv,old_ogs,coarse),(fine_fv,native,fine)],
                              ['Original N32 mesh','Refined source boundary']):
        for run,color,name in zip(curves,colors,['Custom FV','Native OGS','OGS flow + limited FV']):
            x,values = weighted_profile(run)
            ax.stairs(values,x,label=name,color=color,lw=1.8)
        ax.axvline(5,color='.5',ls=':',lw=1)
        ax.axhline(0,color='.5',lw=.6)
        ax.set(xlim=(2.5,8),xlabel='Horizontal position x (cm)',title=title)
        ax.grid(alpha=.18)
        ax.legend(fontsize=8,loc='upper left')
    axes[0].set_ylabel('Tracer mass density θC (mg/L bulk soil)')
    fig.suptitle('300 s profile near the injection boundary')
    fig.tight_layout()
    fig.savefig(output/'profiles.png',dpi=175)
    plt.close(fig)

    fig,axes = plt.subplots(1,2,figsize=(11,4.2))
    for key,color,label in [('OGS','#bc5136','Native OGS'),('replay','#178471','OGS flow + limited FV')]:
        values = [final_percent(comparisons,f'{key}_s{i}_vs_FV_N96') for i in (1,2,4)]
        axes[0].plot([1,2,4],values,'o-',color=color,label=label)
    axes[0].axhline(5,color='.5',ls='--',lw=1,label='5% internal target')
    axes[0].set(xticks=[1,2,4],xticklabels=['6.25','3.125','1.5625'],
                xlabel='Cell width near the source (mm)',ylabel='Relative L1 difference vs N96 FV (%)')
    for split,color in zip([1,2,4],['#972e29','#ca7444','#e49f48']):
        with (RUNS/f'graded_s{split}_dt10'/'replay_history.csv').open() as file:
            rows = list(csv.DictReader(file))
        axes[1].plot([float(r['time_s']) for r in rows],[1000*float(r['native_min_kg_m3']) for r in rows],
                     color=color,label=f'Native OGS, split {split}')
    axes[1].axhline(0,color='#178471',lw=1.6,label='Limited FV lower bound')
    axes[1].set(xlabel='Time (s)',ylabel='Minimum native nodal concentration (mg/L)')
    for ax in axes:
        ax.grid(alpha=.18)
        ax.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(output/'convergence.png',dpi=175)
    plt.close(fig)


def reference_rows():
    rows = []
    for line in (ROOT/'REFERENCES.md').read_text(encoding='utf-8').splitlines():
        if not line.startswith('| ['):
            continue
        parts = [html.escape(cell.strip()) for cell in line.split('|')[1:-1]]
        parts = [re.sub(r'\[([^\]]+)\]\((https://[^)]+)\)',r'<a href="\2">\1</a>',part) for part in parts]
        parts = [re.sub(r'\*([^*]+)\*',r'<em>\1</em>',part) for part in parts]
        rows.append('<tr>'+''.join(f'<td>{p}</td>' for p in parts)+'</tr>')
    return ''.join(rows)


def main():
    comparisons = read_json(ROOT/'comparison.json')
    summaries = {s:read_json(RUNS/f'graded_s{s}_dt10'/'replay_summary.json') for s in (1,2,4)}
    fine = summaries[4]
    final = fine['final']
    source = read_json(ROOT/'source_diagnostic/summary.json')
    limiter = read_json(ROOT/'source_diagnostic/limiter_check.json')
    base = read_json(ROOT/'baseline_source_hashes.json')
    unchanged = all(hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest for name,digest in base.items())
    regression = (ROOT/'regression.log').read_text(encoding='utf-8')
    tests = int(re.search(r'Ran (\d+) tests',regression).group(1))
    native_runs = []
    for split in [1,2,4]:
        folder = RUNS/f'graded_s{split}_dt10'
        execution = read_json(folder/'ogs/execution.json')
        log = (folder/'ogs/ogs.log').read_text(encoding='utf-8')
        native_runs.append(dict(split=split,exit_zero=execution['exit_code']==0,
                                completed='OGS completed on' in log,
                                input_hash=hashlib.sha256((folder/'input/flow.prj').read_bytes()).hexdigest()==execution['input_sha256'],
                                full_time_series=summaries[split]['snapshots']==31))
    with np.load(RUNS/'graded_s4_dt10'/'replay_fields.npz') as values:
        default = values['mass_bulk_kg_m3']
    mesh = CartesianMesh(read_json(RUNS/'graded_s4_dt10'/'contract.json')['edges_xyz_m'])
    sensitivity = {}
    for name in ['source_closure','transport_dt2p5','entrypoint_default']:
        with np.load(ROOT/'sensitivity'/name/'replay_fields.npz') as v:
            field = v['mass_bulk_kg_m3']
        sensitivity[name] = dict(final_relative_change=relative_change(mesh,field[-1],default[-1]),
                                 full_history_max_abs=float(np.max(abs(field-default))))
    old = final_percent(comparisons,'original_OGS_vs_original_FV_N32')
    same = final_percent(comparisons,'same_grid_replay_vs_original_FV_N32')
    direct = final_percent(comparisons,'OGS_s4_vs_FV_N96')
    result = final_percent(comparisons,'replay_s4_vs_FV_N96')
    result_common = final_percent(comparisons,'replay_s4_vs_FV_N96','N32')
    saved_max = max(100*r['L1_relative_union'] for r in comparisons['replay_s4_vs_FV_N96'])
    checks = dict(original_source_unchanged=unchanged,original_tests_passed=tests==57 and regression.rstrip().endswith('OK'),
                  three_completed_native_runs=all(all(v for k,v in r.items() if k!='split') for r in native_runs),
                  quarter_domain_reproduction=final_percent(comparisons,'quarter_OGS_vs_original_OGS_N32')<1e-6,
                  comparison_below_5pct=result<=5 and saved_max<=5,
                  replay_mass_balance_below_1pct=fine['max_relative_tracer_mass_residual']<=.01,
                  all_saved_replay_concentrations_nonnegative=fine['min_replay_kg_m3']>=0,
                  uniform_concentration_preserved=fine['max_uniform_error_kg_m3']<1e-12,
                  default_entrypoint_matches=sensitivity['entrypoint_default']['full_history_max_abs']==0.,
                  exact_source_refinement=source[2]['numerical_L1_relative']<source[1]['numerical_L1_relative']<source[0]['numerical_L1_relative'],
                  limiter_preserves_mass=abs(limiter['mass_residual_kg'])<1e-20)
    if not all(checks.values()):
        raise RuntimeError(f'Delivery validation failed {checks}')
    evidence = dict(checks=checks,native_runs=native_runs,original_tests=tests,source_files_checked=len(base),
                    old_comparison_pct=old,same_grid_replay_comparison_pct=same,
                    native_refined_union_comparison_pct=direct,final_replay_union_comparison_pct=result,
                    final_replay_common_N32_comparison_pct=result_common,max_saved_replay_comparison_pct=saved_max,
                    sensitivity=sensitivity,replay_summaries=summaries,analytical_source_diagnostic=source,
                    limiter_check=limiter,validation_scope='Prescribed 3D volume source, conservative dissolved tracer, 300 s')
    (ROOT/'VALIDATION.json').write_text(json.dumps(evidence,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    output = ROOT/'figures'
    output.mkdir(exist_ok=True)
    plot_results(comparisons,output)
    rows = [
        ('기존 N32 원본 OGS ↔ 기존 자작',old,summaries[1]['min_native_kg_m3']*1000,'기존 기준 초과'),
        ('동일 N32 압력장 재구성 + FCT ↔ 기존 자작',same,0.,'같은 해상도에서 차이 감소'),
        ('경계 세분화 원본 OGS ↔ 자작 N96',direct,fine['min_native_kg_m3']*1000,'분포 기준 충족 · 음수 관측'),
        ('경계 세분화 + 보존형 수송 ↔ 자작 N96',result,0.,'분포·질량·비음수성 기준 충족'),
    ]
    table = ''.join(f'<tr><td>{label}</td><td>{error:.4f}%</td><td>{minimum:.7g}</td><td>{note}</td></tr>'
                    for label,error,minimum,note in rows)
    mesh_rows = ''.join(
        f'<tr><td>{s}</td><td>{w:g}</td><td>{n:,}</td>'
        f'<td>{final_percent(comparisons,f"OGS_s{s}_vs_FV_N96"):.4f}%</td>'
        f'<td>{final_percent(comparisons,f"replay_s{s}_vs_FV_N96"):.4f}%</td>'
        f'<td>{summaries[s]["min_native_kg_m3"]*1000:.7g}</td></tr>'
        for s,w,n in [(1,6.25,16384),(2,3.125,28800),(4,1.5625,68992)])
    css = """body{margin:0;background:#edf2f3;color:#1b2e37;font:16px/1.75 system-ui,sans-serif}
main{max-width:1120px;margin:24px auto;background:white;padding:30px;border-radius:15px}
h1{font-size:33px;line-height:1.35}h2{font-size:22px;margin-top:32px}
.eyebrow{color:#50717a}.notice{background:#e7f4ef;border-left:4px solid #178471;padding:16px}
.cards{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin:20px 0}
.card{background:#f0f5f6;padding:14px;border-radius:10px}.card strong{display:block;font-size:24px;color:#176b61}
table{width:100%;border-collapse:collapse;font-size:14px}td,th{padding:8px 10px;border-bottom:1px solid #d8e4e6;text-align:left}
th{background:#f0f5f6}td:first-child{font-weight:550}img{display:block;width:100%;max-width:1080px}
.scroll{overflow:auto}a{color:#156f93}code{background:#eff3f5;padding:2px 4px}
@media(max-width:650px){main{margin:0;padding:17px;border-radius:0}.cards{grid-template-columns:1fr}h1{font-size:27px}}
"""
    page = f"""<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>KJWP Stage 2 3D 주입 추적자 검증</title><style>{css}</style></head><body><main>
<p class="eyebrow">KJWP · 2026-11-07 · 3D 주입수·추적물질 이동 모델</p>
<h1>3D 주입 추적자 검증<br>급격한 공급원 경계와 음수 농도</h1>
<div class="notice"><strong>보존형 수송 경로가 3D 벤치마크의 분포·질량수지·비음수성 기준을 충족했다.</strong>
<br>OGS 압력장에서 면 유량을 재구성한 뒤, 주입원 경계에 맞춘 격자에서 제한 수송을 실행했다.</div>
<div class="cards"><div class="card">동일 N32 격자의 분포 차이<strong>{old:.2f}% → {same:.2f}%</strong>압력장 기반 유량 재구성 및 FCT</div>
<div class="card">세분화 결과와 자작 N96의 차이<strong>{result:.2f}%</strong>공통 세분 격자, 300초</div>
<div class="card">전체 영역 환산 추적자 저장<strong>{final['reconstructed_tracer_kg']*1e6:.6f} mg</strong>공급 0.600000 mg, 저장 시각 최저 농도 0 mg/L</div></div>
<h2>계산 조건과 실제 결과</h2>
<p>20×20×40 cm 영역의 10 cm 정육면체에 물 15 mL와 추적자 0.600 mg을 300초 동안 공급했다.
대칭을 사용해 전체의 1/4을 계산했고, 질량은 전체 영역 값으로 환산했다. 분산계수 10⁻⁸ m²/s와 토양 계수는 기존 문제를 따랐다.</p>
<div class="scroll"><table><tr><th>비교</th><th>300초 질량장 L1 차이</th><th>저장 시각 최저 농도(mg/L)</th><th>관찰</th></tr>{table}</table></div>
<p>오차의 분모는 각 행의 자작 참조 질량장이다. 동일 N32는 원래 셀에서, 다른 격자는 두 격자를 겹쳐 얻은 공통 세분 격자에서 비교했다.
최저 농도는 0초부터 300초까지 10초 간격으로 저장한 31개 시각에서 확인했다. 원본 OGS는 절점, 보존형 결과는 셀 평균을 사용했다.
세분화한 보존형 결과를 N32 공통 셀로 평균하면 자작 N96과의 차이는 {result_common:.4f}%다.</p>
{embed(output/'profiles.png','실제 300초 주입원 경계 주변 추적자 질량장 비교')}
<p>그림은 y=6.5–9 cm, z=17–23 cm 구간을 부피에 따라 평균한 x 방향 단면이다. 점선 x=5 cm가 공급원 경계다.</p>
<h2>원인 확인</h2>
<p>물 흐름과 확산을 모두 제거한 별도 3D 시험에서도, 급격한 상자형 공급원을 Q1의 일관 질량 행렬로 투영하면 절점 농도가 약
{source[0]['consistent_source_nodal_min_kg_m3']*1000:.3f} mg/L까지 내려갔다. 따라서 음수는 이류 없이도 발생할 수 있다.
실제 주입 계산에서는 같은 N32 OGS 압력장에서 유량 재구성과 수송을 함께 바꿨을 때 분포 차이가 {same:.4f}%였다.</p>
<p>확산만 포함한 해석해 대조에서 공급원 경계 폭을 6.25 → 3.125 → 1.5625 mm로 줄였을 때 상대 오차는
{source[0]['numerical_L1_relative']*100:.2f}% → {source[1]['numerical_L1_relative']*100:.2f}% → {source[2]['numerical_L1_relative']*100:.2f}%였다.
이 결과와 3D 재실행은 급격한 경계의 공간 표현과 수송 이산화가 차이에 기여한다는 근거다.</p>
<h2>세분화와 수치 안정화</h2>
<div class="scroll"><table><tr><th>경계 분할 배수</th><th>최소 폭(mm)</th><th>계산 셀 수</th><th>원본 OGS ↔ 자작 N96</th><th>보존형 ↔ 자작 N96</th><th>원본 OGS 전체 저장 시각 최저(mg/L)</th></tr>{mesh_rows}</table></div>
{embed(output/'convergence.png','경계 세분화에 따른 상대 차이와 OGS 원본 최소 농도')}
<p>공급원 면으로부터 ±12.5 mm 범위를 세분화했다. 수분 저장량과 면 유량을 각 셀에서 일치시키는 데 Odsæter 등 [1]의 가중 최소제곱
원리를 사용했다. Zalesak [2]의 FCT 제한 원리로 두 셀이 공유하는 추적자 플럭스를 제한했고, 시간적분에는 Gottlieb과 Shu [3]의 SSPRK2를 사용했다.</p>
<h2>수지와 민감도</h2>
<p>원본 OGS의 전체 영역 물수지 잔차는 최종 {final['raw_water_residual_m3']*1e6:.5f} mL였다.
재구성 계산에서는 이 차이를 저장량에 명시적으로 배분했고, 균일 보정의 최대 함수율 변화는 {fine['max_water_theta_shift']:.3g}였다.
최종 면 유량 보정의 절댓값 합은 원래 면 유량 절댓값 합의 {100*final['correction_face_L1_m3_s']/final['raw_face_L1_m3_s']:.2f}%였다.
원본 OGS 값과 보정 후 값은 별도 배열로 제공한다.</p>
<p>보정량을 주입원 내부에만 배분한 결과의 최종 질량장 변화는 {100*sensitivity['source_closure']['final_relative_change']:.5f}%였다.
수송 하위 간격을 최대 2.5초로 제한한 경우 변화는 {100*sensitivity['transport_dt2p5']['final_relative_change']:.6f}%였다.
자작 N64의 물 시간간격 10초와 5초 비교 차이는 {final_percent(comparisons,'FV_N64_dt10_vs_dt5'):.5f}%였다.</p>
<p>공급량 기준 보존형 추적자 질량 상대 잔차는 최대 {fine['max_relative_tracer_mass_residual']:.3g}이었다.
균일 농도 대조의 최대 편차는 {fine['max_uniform_error_kg_m3']:.3g} kg/m³였다.
상대 L1 비교는 50, 100, 150, 200, 250, 300초 모두 5% 기준 이내였고, 가장 큰 값은 {saved_max:.4f}%였다.</p>
<h2>검증 범위와 실행</h2>
<p>판정은 닫힌 균질 토양의 비반응 체적 주입 벤치마크에 해당한다. 세분화한 원본 OGS RCT는 300초에
{final['native_min_kg_m3']*1000:.7g} mg/L, 전체 저장 시각에서 {fine['min_native_kg_m3']*1000:.7g} mg/L의 음수 농도가 남았다.
별도 보존형 수송 경로의 결과는 원본을 자르거나 질량을 재정규화한 값과 구분한다.
압력·입자 시연은 동봉한 기존 프로그램의 예시 계산이며, 실제 토양과 노즐 조건은 별도 검증 대상이다.</p>
<p>기존 회귀시험 {tests}개가 통과했다. 실행 진입점은 <code>simulate.py</code>다.
입력·실행 로그·31개 절점 시계열·원본 및 새 수송 결과·재현 명령은 ZIP에 포함했다.</p>
<h2>인용 논문</h2>
<div class="scroll"><table><tr><th>번호</th><th>논문 및 DOI</th><th>이번 사용 범위</th></tr>{reference_rows()}</table></div>
<p>OGS 구성은 공식 6.5.9의 <a href="https://github.com/ufz/ogs/blob/6.5.9/ProcessLib/RichardsComponentTransport/CreateRichardsComponentTransportProcess.cpp">RCT 생성 코드</a>,
<a href="https://github.com/ufz/ogs/blob/6.5.9/ProcessLib/RichardsComponentTransport/RichardsComponentTransportFEM-impl.h">조립식</a> 및
<a href="https://www.opengeosys.org/6.5.9/docs/benchmarks/hydro-component/flux_corrected_transport/">공식 FCT 예제</a>와 대조했다.</p>
</main></body></html>"""
    (ROOT/REPORT).write_text(page,encoding='utf-8')
    print(json.dumps({k:evidence[k] for k in ['checks','same_grid_replay_comparison_pct',
                                             'final_replay_union_comparison_pct','sensitivity']},ensure_ascii=False))


if __name__=='__main__':
    main()
