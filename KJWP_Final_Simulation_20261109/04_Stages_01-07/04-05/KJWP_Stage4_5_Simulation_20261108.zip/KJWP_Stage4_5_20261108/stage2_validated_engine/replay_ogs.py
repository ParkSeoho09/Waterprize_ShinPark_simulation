"""Use OGS pressure snapshots as independent hydraulics for conservative transport."""
import argparse
import csv
import json
from pathlib import Path
import xml.etree.ElementTree as ET

import numpy as np

import run_validation as baseline
from conservative_transport import (CartesianMesh, ConservativeProjection, advance,
                                    darcy_face_rates, native_cell_fields)


def load_native(folder, mesh):
    archive = folder/'native_nodes.npz'
    if archive.is_file():
        with np.load(archive) as stored:
            return stored['time_s'],stored['head_m'],stored['tracer_kg_m3']
    collection = ET.parse(folder/'ogs/flow.pvd')
    snapshots = sorted((float(e.attrib['timestep']),folder/'ogs'/e.attrib['file'])
                       for e in collection.findall('.//DataSet'))
    shape = tuple(n+1 for n in mesh.shape)
    time, head, tracer = [], [], []
    for t,path in snapshots:
        time.append(t)
        root = ET.parse(path)
        coords = root.find('.//Points/DataArray')
        points = np.fromstring(coords.text,sep=' ').reshape(-1,3)
        z,y,x = np.meshgrid(*mesh.edges_xyz[::-1],indexing='ij')
        if not np.allclose(points,np.column_stack([x.ravel(),y.ravel(),z.ravel()]),rtol=0,atol=1e-12):
            raise ValueError('OGS output node order does not match the declared mesh')
        p,c = [np.fromstring(root.find(f'.//PointData/DataArray[@Name="{name}"]').text,sep=' ').reshape(shape)
               for name in ['pressure','tracer']]
        head.append(p/(baseline.RHO*baseline.GRAV))
        tracer.append(c)
    np.savez_compressed(archive,time_s=time,head_m=head,tracer_kg_m3=tracer)
    return np.asarray(time),np.asarray(head),np.asarray(tracer)


def run(folder, output=None, storage_closure='uniform', max_transport_step=None):
    contract = json.loads((folder/'contract.json').read_text(encoding='utf-8'))
    mesh = CartesianMesh(contract['edges_xyz_m'])
    time,heads,tracers = load_native(folder,mesh)
    expected_times = np.arange(0,contract['end_s']+contract['dt_s']/2,contract['dt_s'])
    if not np.array_equal(time,expected_times):
        raise ValueError('Expected one native pressure/tracer field for every accepted step')
    if not np.isfinite(heads).all() or not np.isfinite(tracers).all():
        raise FloatingPointError('Nonfinite native fields')
    inlet = contract['inlet_tracer_kg_m3']
    diffusion = contract['dispersion_m2_s'][0]
    if contract['dispersion_m2_s']!=[diffusion]*3:
        raise ValueError('This replay expects scalar dispersion')
    factor = contract['symmetry_factor']
    source = mesh.source_rate()
    expected_rate = contract['total_rate_m3_s']
    if not np.isclose(source.sum(),expected_rate,rtol=1e-12,atol=0):
        raise ValueError('Source rate does not match the contract')
    soil = baseline.VanGenuchten(**contract['soil'])
    projection = ConservativeProjection(mesh)
    mass = np.zeros(mesh.shape)
    total_volume = mesh.volume.sum()
    output = folder if output is None else output
    output.mkdir(parents=True,exist_ok=True)
    if storage_closure=='uniform':
        closure_weight = np.full(mesh.shape,1/total_volume)
    elif storage_closure=='source':
        active = source>0
        closure_weight = active/np.sum(mesh.volume[active])
    else:
        raise ValueError('Unsupported storage-closure allocation')
    fields,rows = [],[]
    for i,t in enumerate(time):
        theta,raw_mass = native_cell_fields(mesh,heads[i],tracers[i],soil)
        if i==0:
            theta0 = theta.copy()
        raw_change = float(np.sum((theta-theta0)*mesh.volume))
        raw_residual = raw_change-t*expected_rate
        theta_shift = -raw_residual*closure_weight
        water = (theta+theta_shift)*mesh.volume
        if np.min(water/mesh.volume)<soil.theta_r or np.max(water/mesh.volume)>soil.theta_s:
            raise ValueError('Water closure exceeds the physical retention bounds')
        if i==0:
            uniform = inlet*water
            reconstruction = dict(max_local_balance_m3_s=0.,correction_face_L1_m3_s=0.,
                                  raw_face_L1_m3_s=0.,raw_local_balance_L1_m3_s=0.)
            substeps = 0
        else:
            dt = t-time[i-1]
            raw_flux = darcy_face_rates(mesh,heads[i],soil)
            flux,reconstruction = projection.correct(raw_flux,source-(water-previous_water)/dt)
            mass,substeps = advance(mesh,mass,previous_water,water,flux,source,inlet,diffusion,dt,
                                   max_step=max_transport_step)
            uniform,_ = advance(mesh,uniform,previous_water,water,flux,source,inlet,diffusion,dt,
                                max_step=max_transport_step)
        previous_water = water
        expected_mass = t*expected_rate*inlet
        rows.append(dict(time_s=float(t),original_ogs_tracer_kg=float(factor*np.sum(raw_mass*mesh.volume)),
                         reconstructed_tracer_kg=float(factor*mass.sum()), expected_tracer_kg=float(factor*expected_mass),
                         native_min_kg_m3=float(tracers[i].min()), replay_min_kg_m3=float((mass/water).min()),
                         raw_water_residual_m3=float(factor*raw_residual),
                         water_theta_shift=float(np.max(np.abs(theta_shift))),
                         replay_tracer_residual_kg=float(factor*(mass.sum()-expected_mass)),
                         uniform_max_error_kg_m3=float(np.max(abs(uniform/water-inlet))), substeps=substeps,
                         **reconstruction))
        if abs(t/50-round(t/50))<1e-12 or i==len(time)-1:
            fields.append((t,theta,water/mesh.volume,raw_mass,mass/mesh.volume,mass/water))
            print(folder.name, f't={t:g}s', 'OGS raw min', f'{tracers[i].min()*1000:.6g} mg/L',
                  'replay min',f'{(mass/water).min()*1000:.6g} mg/L',flush=True)
    names = ['time_s','raw_theta','theta','raw_mass_bulk_kg_m3','mass_bulk_kg_m3','tracer_kg_m3']
    np.savez_compressed(output/'replay_fields.npz',**dict(zip(names,map(np.asarray,zip(*fields)))))
    with (output/'replay_history.csv').open('w',newline='') as f:
        writer = csv.DictWriter(f,fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    summary = dict(final=rows[-1], snapshots=len(time), storage_closure=storage_closure,
                   max_transport_step_s=max_transport_step,
                   min_native_kg_m3=min(r['native_min_kg_m3'] for r in rows),
                   min_replay_kg_m3=min(r['replay_min_kg_m3'] for r in rows),
                   max_uniform_error_kg_m3=max(r['uniform_max_error_kg_m3'] for r in rows),
                   max_water_theta_shift=max(abs(r['water_theta_shift']) for r in rows),
                   max_water_local_residual_m3_s=max(r['max_local_balance_m3_s'] for r in rows),
                   max_relative_tracer_mass_residual=max(abs(r['replay_tracer_residual_kg'])/r['expected_tracer_kg'] for r in rows[1:]))
    baseline.write_json(output/'replay_summary.json',summary)
    print(json.dumps(summary),flush=True)


if __name__=='__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('case',type=Path)
    parser.add_argument('--output',type=Path)
    parser.add_argument('--storage-closure',choices=['uniform','source'],default='uniform')
    parser.add_argument('--max-transport-step',type=float)
    args = parser.parse_args()
    run(args.case.resolve(),args.output,args.storage_closure,args.max_transport_step)
