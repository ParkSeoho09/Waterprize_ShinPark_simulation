"""Matched 3D finite-volume/FEM pure-water volumetric injection test.

Uniform source support is a FIXED 10 cm cube, not the pressure outlet model.
No particle or chemistry processes are included. OGS source units are 1/s
for RICHARDS_FLOW (volume balance), checked against the official formulation.
"""
from pathlib import Path
import argparse,csv,json,sys
import numpy as np
import xml.etree.ElementTree as ET
from run_validation import ROOT,SOIL,RHO,GRAV,MU,write_json,write_mesh,prepare,ogs_run,nodal,fresh_case_path
from kjwp_stage1.core.grid import Grid
from kjwp_stage1.flow.hydraulics import VanGenuchten
from kjwp_stage1.flow.pressure import PressureFlow
from kjwp_stage1.flow.richards import WaterBoundary
from kjwp_stage1.physics.boundary import FACES

def setup(n,dt,end,folder):
    grid=Grid((.2,.2,.4),(n,n,2*n))
    base,_=prepare('source',2*n,dt,end,folder)
    x,y,z=grid.edges_xyz
    zz,yy,xx=np.meshgrid(z,y,x,indexing='ij')
    points=np.c_[xx.ravel(),yy.ravel(),zz.ravel()]
    ids=np.arange(len(points)).reshape(len(z),len(y),len(x))
    cells=[]
    for k in range(2*n):
        for j in range(n):
            for i in range(n):
                cells.append([ids[k,j,i],ids[k,j,i+1],ids[k,j+1,i+1],ids[k,j+1,i],
                              ids[k+1,j,i],ids[k+1,j,i+1],ids[k+1,j+1,i+1],ids[k+1,j+1,i]])
    cells=np.array(cells)
    zc,yc,xc=grid.mesh_zyx()
    mask=(xc>=.05)&(xc<.15)&(yc>=.05)&(yc<.15)&(zc>=.15)&(zc<.25)
    src=mask*5e-5
    write_mesh(folder/'input/line.vtu',points,cells,12,
        {'p_initial':(points[:,2]-.65)*RHO*GRAV,'bulk_node_ids':np.arange(len(points))},
        {'MaterialIDs':np.zeros(len(cells),int),'source_rate':src.ravel(),'bulk_element_ids':np.arange(len(cells))})
    p=folder/'input/flow.prj';t=ET.parse(p)
    meshes=t.find('meshes')
    for e in list(meshes)[1:]:meshes.remove(e)
    t.find('.//specific_body_force').text='0 0 9.81'
    t.write(p,encoding='utf-8',xml_declaration=True)
    c=dict(case='S2_3D_SOURCE_01',cells_xyz=grid.cells_xyz,lengths_m=grid.lengths_m,dt_s=dt,end_s=end,
        source_support_m={'x':[.05,.15],'y':[.05,.15],'z':[.15,.25]},source_rate_density_s_inv=5e-5,
        total_rate_m3_s=float(src.sum()*grid.volume),expected_water_in_m3=float(src.sum()*grid.volume*end),
        h_initial='z - 0.65 m, z positive down',boundaries='six closed faces',soil=SOIL,
        rho_kg_m3=RHO,g_m_s2=GRAV,mu_Pa_s=MU,
        comparison='Q1 pressure averaged at eight vertices; theta(h_Q1) integrated with 3x3x3 Gauss points',
        diagnostic_targets={'final_theta_mae_absolute':.002,'final_injection_perturbation_L1_relative':.10,'ogs_closed_volume_balance_relative':.01},
        target_note='Predeclared engineering diagnostics, not an external validation standard; passing does not validate all Stage 2',
        not_tested=['pressure-to-flow outlet relation','target dry-solid stopping','tracer transport','slurry','particle retention','chemistry','experiment'])
    write_json(folder/'contract.json',c)
    return grid,points,cells,src,c

def custom(grid,src,c,folder):
    soil=VanGenuchten(**SOIL)
    flow=PressureFlow(grid,soil,{f:WaterBoundary() for f in FACES},theta_tolerance=1e-13,max_iterations=200)
    flow.set_fluid({'carrier_mobility_ratio':1.,'gravity_ratio':1.})
    z,_,_=grid.mesh_zyx();h=z-.65;th0=flow.theta(h);stored0=float(th0.sum()*grid.volume)
    dt,end=c['dt_s'],c['end_s'];heads=[];thetas=[];rows=[]
    for i in range(round(end/dt)+1):
        if i:h=flow.step(h,(i-1)*dt,dt,src).head
        th=flow.theta(h);stored=float(th.sum()*grid.volume);injected=c['total_rate_m3_s']*i*dt
        rows.append(dict(time_s=i*dt,stored_m3=stored,injected_m3=injected,
                    residual_m3=stored-stored0-injected,head_min_m=float(h.min()),head_max_m=float(h.max())))
        heads.append(h.copy());thetas.append(th.copy())
    out=folder/'custom';out.mkdir(exist_ok=True)
    np.savez_compressed(out/'fields.npz',time_s=np.arange(len(heads))*dt,head_m=heads,theta=thetas,
        x_m=grid.centers_xyz[0],y_m=grid.centers_xyz[1],z_m=grid.centers_xyz[2],source_s_inv=src)
    with (out/'water_history.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
    write_json(out/'summary.json',dict(final=rows[-1],max_abs_water_balance_m3=max(abs(r['residual_m3']) for r in rows)))

def analyze(grid,points,cells,c,folder):
    soil=VanGenuchten(**SOIL);custom=np.load(folder/'custom/fields.npz')
    pvd=ET.parse(folder/'ogs/flow.pvd')
    files={round(float(e.attrib['timestep']),8):folder/'ogs'/e.attrib['file'] for e in pvd.findall('.//DataSet')}
    # Tensor-product Gauss integration for physical theta(p) per hexahedron.
    q,w=np.polynomial.legendre.leggauss(3)
    signs=np.array([[-1,-1,-1],[1,-1,-1],[1,1,-1],[-1,1,-1],[-1,-1,1],[1,-1,1],[1,1,1],[-1,1,1]])
    shapes=[];weights=[]
    for i,a in enumerate(q):
        for j,b in enumerate(q):
            for k,d in enumerate(q):
                shapes.append(np.prod(1+signs*np.array([a,b,d]),axis=1)/8)
                weights.append(w[i]*w[j]*w[k]/8)
    shapes=np.asarray(shapes);weights=np.array(weights)
    rows=[];hs=[];ths=[];base_ogs=None;base_custom=custom['theta'][0]
    for i,time in enumerate(custom['time_s']):
        h=nodal(files[round(float(time),8)],'pressure')/(RHO*GRAV)
        hv=h[cells];hc=hv.mean(axis=1).reshape(grid.shape)
        th=(soil.theta(hv@shapes.T)@weights).reshape(grid.shape)
        ch=custom['head_m'][i];ct=custom['theta'][i]
        if base_ogs is None:base_ogs=th.copy()
        delta_ogs=th-base_ogs;delta_custom=ct-base_custom
        perturb=float(abs(delta_custom).sum()*grid.volume)
        delta_diff=float(abs(delta_ogs-delta_custom).sum()*grid.volume)
        injected=c['total_rate_m3_s']*float(time);storage_change=float(delta_ogs.sum()*grid.volume)
        rows.append(dict(time_s=float(time),head_mae_m=float(abs(hc-ch).mean()),head_max_abs_m=float(abs(hc-ch).max()),
            theta_mae=float(abs(th-ct).mean()),theta_max_abs=float(abs(th-ct).max()),
            perturbation_L1_relative=None if perturb==0 else delta_diff/perturb,
            expected_in_m3=injected,ogs_storage_change_m3=storage_change,ogs_closed_balance_m3=storage_change-injected,
            ogs_balance_relative=None if not injected else abs(storage_change-injected)/injected))
        hs.append(hc);ths.append(th)
    out=folder/'analysis';out.mkdir(exist_ok=True)
    with (out/'comparison.csv').open('w',newline='') as f:
        wri=csv.DictWriter(f,fieldnames=rows[0]);wri.writeheader();wri.writerows(rows)
    np.savez_compressed(out/'ogs_fields.npz',time_s=custom['time_s'],head_m=hs,theta=ths)
    final=rows[-1];targets=c['diagnostic_targets']
    checks=dict(theta_mae=final['theta_mae']<=targets['final_theta_mae_absolute'],
        injection_distribution=final['perturbation_L1_relative']<=targets['final_injection_perturbation_L1_relative'],
        ogs_physical_water_balance=final['ogs_balance_relative']<=targets['ogs_closed_volume_balance_relative'])
    summary=dict(case=c['case'],cells_xyz=grid.cells_xyz,dt_s=c['dt_s'],final=final,diagnostic_checks=checks,
        status='PASS_DIAGNOSTIC_TARGETS' if all(checks.values()) else 'REVIEW_REQUIRED',
        scope='3D pure-water prescribed volumetric injection only; not all Stage 2',
        native_storage_note='OGS theta evaluated from native Q1 pressure by Gauss quadrature. Subtracted each solver own initial physical storage; no balance correction applied.')
    write_json(out/'summary.json',summary)
    print(json.dumps(summary,ensure_ascii=False),flush=True)

def main():
    p=argparse.ArgumentParser();p.add_argument('--n',type=int,default=8);p.add_argument('--dt',type=float,default=10.)
    p.add_argument('--end',type=float,default=300.);p.add_argument('--ogs-exe');p.add_argument('--skip-custom',action='store_true')
    p.add_argument('--iterative',action='store_true',help='CG/DIAGONAL at 1e-14 instead of SparseLU; physical input unchanged')
    a=p.parse_args()
    if a.n%4:raise ValueError('n divisible by 4 aligns fixed source support with both grids')
    folder=fresh_case_path(ROOT/'runs'/(f'injection3d_N{a.n}_dt{a.dt:g}'+('_CG' if a.iterative else '')));folder.mkdir(parents=True,exist_ok=True)
    grid,points,cells,src,c=setup(a.n,a.dt,a.end,folder)
    if a.iterative:
        from set_iterative_solver import apply
        apply(folder)
    if not a.skip_custom:custom(grid,src,c,folder)
    ogs_run(folder,a.ogs_exe);analyze(grid,points,cells,c,folder)

if __name__=='__main__':main()
