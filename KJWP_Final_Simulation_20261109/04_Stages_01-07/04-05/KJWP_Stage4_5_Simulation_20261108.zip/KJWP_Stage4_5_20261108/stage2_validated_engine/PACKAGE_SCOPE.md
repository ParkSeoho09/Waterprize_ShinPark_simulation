이 폴더는 최신 Stage 2 검증본의 코드와 문서 보관본입니다.
대용량 runs 배열과 원본 source 디렉터리는 중복하지 않았습니다.
여기서 Stage 2 재현을 실행하려면 PROVENANCE_STAGE3.json에 기록한 원본 Stage 2 ZIP을 사용하세요.
이 폴더의 기존 README 경로들은 원본 전체 패키지를 기준으로 합니다.
