"""Stage 2 pure-water flow comparisons; never changes the source simulator.

OGS 6.5.9, line FEM versus the original 3D FV solver in a transverse-uniform
limit. This is not a test of 3D point injection, slurry or particle retention.
"""
from pathlib import Path
import argparse, csv, hashlib, json, os, platform, subprocess, sys, time
import xml.etree.ElementTree as ET
import numpy as np

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT/'source/kjwp-simulator-3_1'))
from kjwp_stage1.core.grid import Grid
from kjwp_stage1.flow.hydraulics import VanGenuchten
from kjwp_stage1.flow.richards import WaterBoundary, boundary_water_rates
from kjwp_stage1.flow.pressure import PressureFlow
from kjwp_stage1.physics.boundary import FACES
from kjwp_stage1.physics.slurry import Slurry

RHO, GRAV, MU = 1000., 9.81, .001
L, AREA = .4, .01
SOIL = dict(theta_r=.08, theta_s=.43, alpha_m_inv=3.6, n=1.56, ks_m_s=1e-5)

def write_json(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2),encoding='utf-8')

def fresh_case_path(base):
    """Keep bundled execution evidence immutable when the user reruns a case."""
    base=Path(base)
    if not (base/'ogs/ogs.log').exists():return base
    for i in range(2,10000):
        candidate=base.with_name(base.name+f'_run{i:02d}')
        if not candidate.exists():return candidate
    raise RuntimeError('Too many existing attempts')

def data(parent, name, vals, kind='Float64', components=None):
    a=np.asarray(vals); attrs=dict(type=kind, Name=name, format='ascii')
    if components: attrs['NumberOfComponents']=str(components)
    ET.SubElement(parent,'DataArray',attrs).text=' '.join(str(x) for x in a.ravel())

def write_mesh(path, points, cells, cell_type, point_fields=None, cell_fields=None):
    root=ET.Element('VTKFile',type='UnstructuredGrid',version='0.1',byte_order='LittleEndian')
    piece=ET.SubElement(ET.SubElement(root,'UnstructuredGrid'),'Piece',NumberOfPoints=str(len(points)),NumberOfCells=str(len(cells)))
    pd=ET.SubElement(piece,'PointData');cd=ET.SubElement(piece,'CellData')
    for k,v in (point_fields or {}).items(): data(pd,k,v,'UInt64' if k=='bulk_node_ids' else 'Float64')
    for k,v in (cell_fields or {}).items(): data(cd,k,v,'UInt64' if k=='bulk_element_ids' else ('Int32' if k=='MaterialIDs' else 'Float64'))
    data(ET.SubElement(piece,'Points'),'Points',points,components=3)
    c=ET.SubElement(piece,'Cells');data(c,'connectivity',cells,'Int64')
    data(c,'offsets',np.arange(1,len(cells)+1)*len(cells[0]),'Int64')
    data(c,'types',np.full(len(cells),cell_type),'UInt8')
    ET.ElementTree(root).write(path,encoding='utf-8',xml_declaration=True)

def prop(name,value):
    return f'<property><name>{name}</name><type>Constant</type><value>{value}</value></property>'

def prepare(case,n,dt,end,folder):
    inp=folder/'input';inp.mkdir(parents=True,exist_ok=True)
    x=np.linspace(0,L,n+1);centers=(x[:-1]+x[1:])/2
    hydro=case in ('hydro','source')
    h0=x-.65 if hydro else np.full(n+1,-.5)
    source=np.where((centers>=.18)&(centers<.22),1e-4,0.) if case=='source' else np.zeros(n)
    write_mesh(inp/'line.vtu',np.c_[x,np.zeros((n+1,2))],np.c_[np.arange(n),np.arange(1,n+1)],3,
               {'p_initial':h0*RHO*GRAV,'bulk_node_ids':np.arange(n+1)},
               {'MaterialIDs':np.zeros(n,int),'source_rate':source,'bulk_element_ids':np.arange(n)})
    for name,j in [('top',0),('bottom',n)]:
        write_mesh(inp/(name+'.vtu'),[[x[j],0,0]],[[0]],1,{'bulk_node_ids':[j]})
    sr=SOIL['theta_r']/SOIL['theta_s'];m=1-1/SOIL['n'];pb=RHO*GRAV/SOIL['alpha_m_inv']
    sat=f'<property><name>saturation</name><type>SaturationVanGenuchten</type><residual_liquid_saturation>{sr}</residual_liquid_saturation><residual_gas_saturation>0</residual_gas_saturation><exponent>{m}</exponent><p_b>{pb}</p_b></property>'
    rel=f'<property><name>relative_permeability</name><type>RelativePermeabilityVanGenuchten</type><residual_liquid_saturation>{sr}</residual_liquid_saturation><residual_gas_saturation>0</residual_gas_saturation><minimum_relative_permeability_liquid>1e-20</minimum_relative_permeability_liquid><exponent>{m}</exponent></property>'
    top,bottom=(-.65,L-.65) if hydro else (-.1,-.5)
    bc='' if case=='source' else ''.join(f'<boundary_condition><mesh>{name}</mesh><type>Dirichlet</type><parameter>{name}_head</parameter></boundary_condition>' for name in ['top','bottom'])
    st='<source_terms><source_term><mesh>line</mesh><type>Volumetric</type><parameter>injection</parameter></source_term></source_terms>' if case=='source' else ''
    injection_parameter='<parameter><name>injection</name><type>MeshElement</type><mesh>line</mesh><field_name>source_rate</field_name></parameter>' if case=='source' else ''
    xml=f'''<?xml version="1.0"?>
<OpenGeoSysProject>
<meshes><mesh>line.vtu</mesh><mesh>top.vtu</mesh><mesh>bottom.vtu</mesh></meshes>
<processes><process><name>flow</name><type>RICHARDS_FLOW</type><integration_order>2</integration_order>
<process_variables><process_variable>pressure</process_variable></process_variables><secondary_variables><secondary_variable name="saturation"/><secondary_variable name="darcy_velocity"/></secondary_variables>
<specific_body_force>9.81</specific_body_force><mass_lumping>true</mass_lumping></process></processes>
<media><medium id="0"><phases><phase><type>AqueousLiquid</type><properties>{prop('density',RHO)}{prop('viscosity',MU)}</properties></phase></phases>
<properties>{prop('storage',0)}{prop('porosity',SOIL['theta_s'])}{prop('permeability',SOIL['ks_m_s']*MU/(RHO*GRAV))}{prop('reference_temperature',293.15)}{sat}{rel}</properties></medium></media>
<parameters><parameter><name>initial</name><type>MeshNode</type><field_name>p_initial</field_name></parameter>
<parameter><name>top_head</name><type>Constant</type><value>{top*RHO*GRAV}</value></parameter>
<parameter><name>bottom_head</name><type>Constant</type><value>{bottom*RHO*GRAV}</value></parameter>{injection_parameter}</parameters>
<process_variables><process_variable><name>pressure</name><components>1</components><order>1</order><initial_condition>initial</initial_condition><boundary_conditions>{bc}</boundary_conditions>{st}</process_variable></process_variables>
<time_loop><processes><process ref="flow"><nonlinear_solver>picard</nonlinear_solver><convergence_criterion><type>DeltaX</type><norm_type>INFINITY_N</norm_type><abstol>1e-9</abstol></convergence_criterion>
<time_discretization><type>BackwardEuler</type></time_discretization><time_stepping><type>FixedTimeStepping</type><t_initial>0</t_initial><t_end>{end}</t_end><timesteps><pair><repeat>{round(end/dt)}</repeat><delta_t>{dt}</delta_t></pair></timesteps></time_stepping></process></processes>
<output><type>VTK</type><prefix>flow</prefix><data_mode>Ascii</data_mode><timesteps><pair><repeat>1000000</repeat><each_steps>1</each_steps></pair></timesteps><variables><variable>pressure</variable><variable>saturation</variable><variable>darcy_velocity</variable></variables><suffix>_ts_{{:timestep}}_t_{{:time}}</suffix></output></time_loop>
<nonlinear_solvers><nonlinear_solver><name>picard</name><type>Picard</type><max_iter>150</max_iter><linear_solver>linear</linear_solver></nonlinear_solver></nonlinear_solvers>
<linear_solvers><linear_solver><name>linear</name><eigen><solver_type>SparseLU</solver_type></eigen></linear_solver></linear_solvers>
</OpenGeoSysProject>'''
    (inp/'flow.prj').write_text(xml,encoding='utf-8')
    contract=dict(case=case,n_elements=n,dt_s=dt,end_s=end,soil=SOIL,rho_kg_m3=RHO,g_m_s2=GRAV,mu_Pa_s=MU,
        coordinate='OGS x is custom z, positive DOWN',L_m=L,custom_area_m2=AREA,ogs_area_m2=1.,
        h_initial='depth - 0.65 m' if hydro else '-0.5 m',water_boundary='closed both ends' if case=='source' else {'top_head_m':top,'bottom_head_m':bottom},
        source_s_inv='1e-4 for depth in [0.18,0.22) m; otherwise zero' if case=='source' else 'zero',
        source_rate_m3_s_custom=float(source.sum()*L/n*AREA),source_rate_m2_s_ogs=float(source.sum()*L/n),
        comparison='P1 pressure integrated per FV cell, theta(h_P1) by 8-point Gauss quadrature; no parameter fitting',
        not_tested=['3D local outlet','pressure-controlled spherical resistance','tracer transport','slurry','particle retention','chemistry','soil experiment'],
        ogs_storage_note='RICHARDS_FLOW pressure-based storage; compare time-step dependence against mixed-form FV; OGS physical water balance is diagnosed independently')
    write_json(folder/'contract.json',contract)
    return contract,source

def custom_run(c,source,folder):
    n=c['n_elements'];dt=c['dt_s'];end=c['end_s'];kind=c['case']
    grid=Grid((.1,.1,L),(2,2,n));soil=VanGenuchten(**SOIL)
    boundaries={f:WaterBoundary() for f in FACES}
    if kind!='source':
        for face,key in [('z-','top_head_m'),('z+','bottom_head_m')]:boundaries[face]=WaterBoundary('head',c['water_boundary'][key])
    flow=PressureFlow(grid,soil,boundaries,theta_tolerance=1e-13,max_iterations=200)
    flow.set_fluid({'carrier_mobility_ratio':1.,'gravity_ratio':1.})
    z,_,_=grid.mesh_zyx();h=z-.65 if kind in ('hydro','source') else np.full(grid.shape,-.5)
    src=np.broadcast_to(source[:,None,None],grid.shape)
    initial=float(flow.theta(h).sum()*grid.volume);vin=vout=0.;hist=[];heads=[];thetas=[]
    for i in range(round(end/dt)+1):
        if i:
            w=flow.step(h,(i-1)*dt,dt,src);h=w.head
            incoming,outgoing=boundary_water_rates(w.fluxes,grid)
            vin+=(incoming+float(src.sum()*grid.volume))*dt;vout+=outgoing*dt
        th=flow.theta(h);stored=float(th.sum()*grid.volume)
        hist.append(dict(time_s=i*dt,stored_m3=stored,in_m3=vin,out_m3=vout,residual_m3=stored-initial-vin+vout,
                         max_cell_residual=0. if not i else w.cell_balance_max,
                         q_top_m_s=0. if not i else float(w.fluxes[2][0].mean()),q_bottom_m_s=0. if not i else float(w.fluxes[2][-1].mean())))
        heads.append(h.mean(axis=(1,2)));thetas.append(th.mean(axis=(1,2)))
    out=folder/'custom';out.mkdir(exist_ok=True)
    np.savez_compressed(out/'fields.npz',times_s=np.arange(len(heads))*dt,depth_m=grid.centers_xyz[2],head_m=heads,theta=thetas)
    with (out/'water_history.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=hist[0]);w.writeheader();w.writerows(hist)
    write_json(out/'summary.json',dict(final=hist[-1],max_abs_water_residual_m3=max(abs(r['residual_m3']) for r in hist),
               flow_class='PressureFlow pure carrier limit, inherited mixed-form step; no source code modification'))

def ogs_run(folder,exe):
    out=folder/'ogs';out.mkdir(exist_ok=True)
    if exe: cmd=[exe,'input/flow.prj','-o','ogs']
    else:
        cmd=[sys.executable,str(ROOT/'ogs_runner.py'),'input/flow.prj','-o','ogs']
    env=os.environ.copy();env.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
    env['PYTHONPATH']=str(ROOT/'runtime')+os.pathsep+env.get('PYTHONPATH','')
    if exe and os.name=='nt':
        # Reuse the user's recovered standalone runtime; child environment only.
        executable=Path(exe).resolve()
        support=executable.parent.parent.parent/'S1_ENV_01_v0_1/runtime_support'
        env['PATH']=str(executable.parent)+os.pathsep+env.get('PATH','')
        if support.is_dir():
            env.update(PYTHONHOME=str(support),PYTHONPATH=str(support/'Lib'),
                       PYTHONNOUSERSITE='1',PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1')
    started=time.time()
    with (out/'ogs.log').open('w') as log:
        p=subprocess.run(cmd,cwd=folder,env=env,stdout=log,stderr=subprocess.STDOUT)
    write_json(out/'execution.json',dict(command=cmd,working_directory=str(folder),exit_code=p.returncode,
               wall_seconds=time.time()-started,python=sys.version,platform=platform.platform(),
               input_sha256=hashlib.sha256((folder/'input/flow.prj').read_bytes()).hexdigest()))
    if p.returncode:raise RuntimeError(f'OGS exit {p.returncode}: {out}/ogs.log')

def nodal(path,name):
    e=ET.parse(path).find(f'.//PointData/DataArray[@Name="{name}"]')
    if e is None: raise ValueError(f'{name} missing in {path}')
    return np.fromstring(e.text,sep=' ')

def analyze(c,folder):
    soil=VanGenuchten(**SOIL);n=c['n_elements'];dx=L/n
    custom=np.load(folder/'custom/fields.npz');times=custom['times_s']
    pvd=ET.parse(folder/'ogs/flow.pvd')
    files={round(float(e.attrib['timestep']),8):folder/'ogs'/e.attrib['file'] for e in pvd.findall('.//DataSet')}
    qx,qw=np.polynomial.legendre.leggauss(8);rows=[];hs=[];ths=[]
    for i,t in enumerate(times):
        path=files[round(float(t),8)];h=nodal(path,'pressure')/(RHO*GRAV)
        hc=(h[:-1]+h[1:])/2;hq=hc[:,None]+.5*(h[1:]-h[:-1])[:,None]*qx
        theta=(soil.theta(hq)*qw).sum(axis=1)/2
        ch=custom['head_m'][i];ct=custom['theta'][i]
        rows.append(dict(time_s=float(t),head_mae_m=float(np.mean(abs(hc-ch))),head_max_abs_m=float(np.max(abs(hc-ch))),
                 theta_mae=float(np.mean(abs(theta-ct))),theta_max_abs=float(np.max(abs(theta-ct))),
                 ogs_storage_m_per_area=float(theta.sum()*dx),custom_storage_m_per_area=float(ct.sum()*dx)))
        hs.append(hc);ths.append(theta)
    a=folder/'analysis';a.mkdir(exist_ok=True)
    with (a/'comparison.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
    np.savez_compressed(a/'ogs_cell_averages.npz',times_s=times,depth_m=custom['depth_m'],head_m=hs,theta=ths)
    source=c['source_rate_m2_s_ogs']*c['end_s']
    balance=rows[-1]['ogs_storage_m_per_area']-rows[0]['ogs_storage_m_per_area']-source if c['case']=='source' else None
    summary=dict(case=c['case'],n=n,dt_s=c['dt_s'],final=rows[-1],
        max_head_mae_m=max(r['head_mae_m'] for r in rows),max_theta_mae=max(r['theta_mae'] for r in rows),
        ogs_source_closed_physical_balance_m_per_area=balance,
        ogs_source_balance_relative_to_injected=None if balance is None else abs(balance)/source,
        initial_boundary_representation_note='Both store uniform initial h=-0.5 m at t=0. At t>0 OGS enforces h=-0.1 m at the boundary node; FV enforces it at the boundary face. Initial wetting boundary-layer representations differ; refine before interpreting the transient discrepancy.' if c['case']=='wet' else '',
        status='COMPARISON_EXECUTED; diagnostic metrics, not whole-Stage-2 validation')
    write_json(a/'summary.json',summary)
    print(json.dumps(summary,ensure_ascii=False),flush=True)

def main():
    p=argparse.ArgumentParser();p.add_argument('--case',choices=['hydro','wet','source'],required=True)
    p.add_argument('--n',type=int,default=40);p.add_argument('--dt',type=float,default=10.);p.add_argument('--end',type=float,default=1200.)
    p.add_argument('--ogs-exe');p.add_argument('--skip-custom',action='store_true');a=p.parse_args()
    if abs(a.end/a.dt-round(a.end/a.dt))>1e-8:raise ValueError('end must be divisible by dt')
    folder=fresh_case_path(ROOT/'runs'/f'{a.case}_N{a.n}_dt{a.dt:g}');folder.mkdir(parents=True,exist_ok=True)
    c,source=prepare(a.case,a.n,a.dt,a.end,folder)
    if not a.skip_custom:custom_run(c,source,folder)
    ogs_run(folder,a.ogs_exe);analyze(c,folder)

if __name__=='__main__':main()
