"""Run the original OGS process on a source-aligned, graded quarter domain."""
import argparse
from pathlib import Path
import xml.etree.ElementTree as ET

import numpy as np

import run_tracer
import run_validation as base


def refined_edges(length, count, interfaces, radius, split):
    edges = np.linspace(0, length, count + 1)
    result = [0.]
    for lo, hi in zip(edges[:-1], edges[1:]):
        center = (lo + hi) / 2
        subdivisions = split if any(abs(center - face) < radius for face in interfaces) else 1
        result.extend(np.linspace(lo, hi, subdivisions + 1)[1:])
    return np.asarray(result)


def setup(folder, dt, split):
    # Start from the previously run RCT input so the material and weak-form
    # mapping remain identical. Replace only the structured grid and output.
    _, _, _, contract = run_tracer.setup(4, dt, 'injection', folder)
    x = refined_edges(.1, 16, [.05], .0125, split)
    y = x.copy()
    z = refined_edges(.4, 64, [.15, .25], .0125, split)
    zz, yy, xx = np.meshgrid(z, y, x, indexing='ij')
    points = np.column_stack((xx.ravel(), yy.ravel(), zz.ravel()))
    ids = np.arange(len(points)).reshape(zz.shape)
    cells = np.stack((ids[:-1,:-1,:-1], ids[:-1,:-1,1:], ids[:-1,1:,1:], ids[:-1,1:,:-1],
                      ids[1:,:-1,:-1], ids[1:,:-1,1:], ids[1:,1:,1:], ids[1:,1:,:-1]), axis=-1).reshape(-1,8)
    centers = [(edges[1:] + edges[:-1]) / 2 for edges in (x,y,z)]
    zc,yc,xc = np.meshgrid(centers[2], centers[1], centers[0], indexing='ij')
    source = ((xc >= .05) & (yc >= .05) & (zc >= .15) & (zc < .25)) * 5e-5
    volume = np.diff(z)[:,None,None] * np.diff(y)[None,:,None] * np.diff(x)[None,None,:]
    rate = float(np.sum(volume * source))
    if not np.isclose(4 * rate * 300, 15e-6, rtol=1e-12, atol=0):
        raise ValueError('Physical water supply changed')
    base.write_mesh(folder/'input/line.vtu', points, cells, 12,
                    {'p_initial':(points[:,2]-.65)*base.RHO*base.GRAV, 'bulk_node_ids':np.arange(len(points))},
                    {'MaterialIDs':np.zeros(len(cells),int), 'source_rate':source.ravel(),
                     'tracer_source_rate':(source*run_tracer.CIN).ravel(), 'bulk_element_ids':np.arange(len(cells))})
    project = folder/'input/flow.prj'
    tree = ET.parse(project)
    tree.find('.//output/timesteps/pair/each_steps').text = '1'
    tree.write(project,encoding='utf-8',xml_declaration=True)
    contract.update(cells_xyz=[len(x)-1,len(y)-1,len(z)-1], lengths_m=[.1,.1,.4],
                    symmetry_factor=4, source_support_m={'x':[.05,.1],'y':[.05,.1],'z':[.15,.25]},
                    total_rate_m3_s=rate, expected_water_in_m3=rate*300,
                    expected_tracer_input_kg=rate*300*run_tracer.CIN,
                    edges_xyz_m=[x.tolist(),y.tolist(),z.tolist()],
                    refinement={'base_full_equivalent_N':32,'near_source_faces_m':.0125,'split':split},
                    boundaries='Six closed faces; x=.1 and y=.1 are exact symmetry planes for this case')
    base.write_json(folder/'contract.json',contract)
    print(f'Prepared {len(cells)} elements, dt={dt:g}s, {4*rate*300*1e6:.6g} mL full-domain supply',flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--split',type=int,choices=[1,2,4,8],default=4)
    parser.add_argument('--dt',type=float,choices=[5.,10.],default=10.)
    parser.add_argument('--ogs-exe')
    args = parser.parse_args()
    folder = args.output.resolve()
    folder.mkdir(parents=True)
    setup(folder,args.dt,args.split)
    base.ogs_run(folder,args.ogs_exe)


if __name__=='__main__':
    main()
