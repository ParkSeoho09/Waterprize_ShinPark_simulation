"""Closed-domain conservative water-flux reconstruction and FV tracer transport.

The flux projection follows the weighted least-squares principle of
Odsæter et al. (2017). The face limiter follows Zalesak (1979).
See REFERENCES.md for the published sources and the adaptations used here.
"""
from dataclasses import dataclass
from itertools import product

import numpy as np
from scipy.linalg import eigh_tridiagonal


def along(matrix, field, axis):
    """Apply a one-dimensional operator to one tensor axis."""
    moved = np.moveaxis(field, axis, 0)
    result = (matrix @ moved.reshape(moved.shape[0], -1)).reshape(
        (matrix.shape[0],) + moved.shape[1:])
    return np.moveaxis(result, 0, axis)


@dataclass
class Axis:
    index: int
    left: tuple
    right: tuple
    area_over_distance: np.ndarray
    left_weight: np.ndarray
    width: np.ndarray


class CartesianMesh:
    """Tensor product mesh. All fields are stored in z, y, x order."""

    def __init__(self, edges_xyz):
        self.edges_xyz = tuple(np.asarray(e, dtype=float) for e in edges_xyz)
        self.widths = tuple(np.diff(e) for e in self.edges_xyz[::-1])
        if any(len(w)<2 or not np.isfinite(w).all() or np.any(w<=0) for w in self.widths):
            raise ValueError('Each direction needs at least two positive finite cell widths')
        self.shape = tuple(len(w) for w in self.widths)
        self.volume = self.widths[0][:,None,None]*self.widths[1][None,:,None]*self.widths[2][None,None,:]
        self.axes = []
        for axis, width in enumerate(self.widths):
            left, right = [slice(None)]*3, [slice(None)]*3
            left[axis], right[axis] = slice(None,-1), slice(1,None)
            left, right = tuple(left), tuple(right)
            dims = [1]*3
            dims[axis] = len(width)-1
            distance = ((width[:-1]+width[1:])/2).reshape(dims)
            area = self.volume[left]/width[:-1].reshape(dims)
            self.axes.append(Axis(axis,left,right,area/distance,
                                  (width[1:]/(width[:-1]+width[1:])).reshape(dims),width))

    def divergence(self, fluxes):
        """Cellwise net outward flow, in the units of the face flux."""
        out = np.zeros(self.shape)
        for axis, flux in zip(self.axes, fluxes):
            out[axis.left] += flux
            out[axis.right] -= flux
        return out

    def source_rate(self):
        x,y,z = [(e[:-1]+e[1:])/2 for e in self.edges_xyz]
        zz,yy,xx = np.meshgrid(z,y,x,indexing='ij')
        return 5e-5*self.volume*((xx>=.05)&(xx<.15)&(yy>=.05)&(yy<.15)&(zz>=.15)&(zz<.25))

    def project_averages(self, data, target):
        """Conservative overlap projection of piecewise-constant cell averages."""
        for axis,(source, dest) in enumerate(zip(self.edges_xyz[::-1],target.edges_xyz[::-1])):
            overlap = np.minimum(dest[1:,None],source[None,1:])-np.maximum(dest[:-1,None],source[None,:-1])
            weights = np.maximum(overlap,0)/np.diff(dest)[:,None]
            if not np.allclose(weights.sum(axis=1),1,rtol=0,atol=1e-12):
                raise ValueError('Target cells are not covered by the source mesh')
            data = along(weights,data,axis)
        return data


class ConservativeProjection:
    """Minimum area/distance weighted correction with zero boundary flux.

    The weighted graph Laplacian has a tensor-product eigensystem. Its single
    constant null mode is removed using the closed-domain compatibility condition.
    """

    def __init__(self, mesh):
        self.mesh = mesh
        self.sqrt_volume = np.sqrt(mesh.volume)
        values, vectors = [], []
        for w in mesh.widths:
            conductance = 2/(w[1:]+w[:-1])
            diagonal = (np.r_[0.,conductance]+np.r_[conductance,0.])/w
            off = -conductance/np.sqrt(w[1:]*w[:-1])
            eigenvalues,eigenvectors = eigh_tridiagonal(diagonal,off)
            eigenvalues[0] = 0.
            values.append(eigenvalues)
            vectors.append(eigenvectors)
        self.vectors = vectors
        self.denominator = values[0][:,None,None]+values[1][None,:,None]+values[2][None,None,:]
        self.denominator[0,0,0] = 1.

    def correct(self, raw_fluxes, target_net):
        residual = target_net-self.mesh.divergence(raw_fluxes)
        if abs(residual.sum())>1e-16:
            raise ValueError('Closed-domain water budget is incompatible with zero boundary flux')
        coefficients = residual/self.sqrt_volume
        for axis, transform in enumerate(self.vectors):
            coefficients = along(transform.T,coefficients,axis)
        coefficients[0,0,0] = 0.
        solution = coefficients/self.denominator
        for axis, transform in enumerate(self.vectors):
            solution = along(transform,solution,axis)
        potential = solution/self.sqrt_volume
        correction = tuple(a.area_over_distance*(potential[a.left]-potential[a.right])
                           for a in self.mesh.axes)
        fluxes = tuple(q+dq for q,dq in zip(raw_fluxes,correction))
        error = np.max(np.abs(self.mesh.divergence(fluxes)-target_net))
        if error>1e-16:
            raise FloatingPointError(f'Local water closure failed, {error:g} m³/s')
        return fluxes, dict(max_local_balance_m3_s=float(error),
                            correction_face_L1_m3_s=float(sum(np.abs(dq).sum() for dq in correction)),
                            raw_face_L1_m3_s=float(sum(np.abs(q).sum() for q in raw_fluxes)),
                            raw_local_balance_L1_m3_s=float(np.abs(residual).sum()))


def native_cell_fields(mesh, head, tracer, soil):
    """3x3x3 Gauss quadrature of Q1 head and native tracer in each element."""
    points, weights = np.polynomial.legendre.leggauss(3)
    theta = np.zeros(mesh.shape)
    mass = np.zeros(mesh.shape)
    for indices in product(range(3), repeat=3):
        local = [(points[i]+1)/2 for i in indices]
        factor = np.prod([weights[i]/2 for i in indices])
        h = np.zeros(mesh.shape)
        c = np.zeros(mesh.shape)
        for vertex in product((0,1), repeat=3):
            weight = np.prod([x if v else 1-x for v,x in zip(vertex,local)])
            sl = tuple(slice(1,None) if v else slice(None,-1) for v in vertex)
            h += weight*head[sl]
            c += weight*tracer[sl]
        water = soil.theta(h)
        theta += factor*water
        mass += factor*water*c
    return theta,mass


def darcy_face_rates(mesh, head, soil):
    """Integrate averaged one-sided Q1 Darcy traces across interior faces."""
    gauss = (0.5-0.5/np.sqrt(3),0.5+0.5/np.sqrt(3))
    rates = []
    for geometry in mesh.axes:
        axis = geometry.index
        h = np.moveaxis(head,axis,-1)
        gradients = np.diff(h,axis=-1)/geometry.width
        head_at_face = h[...,1:-1]
        grad_at_face = (gradients[...,:-1]+gradients[...,1:])/2
        rate = np.zeros(tuple(s-1 for s in h.shape[:2])+(h.shape[-1]-2,))
        for u,v in product(gauss,repeat=2):
            def bilinear(field):
                return ((1-u)*(1-v)*field[:-1,:-1]+u*(1-v)*field[1:,:-1]
                        +(1-u)*v*field[:-1,1:]+u*v*field[1:,1:])
            gravity = 1. if axis==0 else 0.
            rate += -.25*soil.ks_m_s*soil.relative_k(bilinear(head_at_face))*(bilinear(grad_at_face)-gravity)
        transverse = [w for i,w in enumerate(mesh.widths) if i!=axis]
        rates.append(np.moveaxis(rate*transverse[0][:,None,None]*transverse[1][None,:,None],-1,axis))
    return tuple(rates)


def _euler(mesh, mass, water, next_water, fluxes, source, inlet, diffusion, step):
    concentration = mass/water
    lower = concentration.copy()
    upper = concentration.copy()
    active_source = source>0
    lower[active_source] = np.minimum(lower[active_source],inlet)
    upper[active_source] = np.maximum(upper[active_source],inlet)
    low_flux, correction = [], []
    for axis,flow in zip(mesh.axes,fluxes):
        left,right = concentration[axis.left],concentration[axis.right]
        lower[axis.left] = np.minimum(lower[axis.left],right)
        lower[axis.right] = np.minimum(lower[axis.right],left)
        upper[axis.left] = np.maximum(upper[axis.left],right)
        upper[axis.right] = np.maximum(upper[axis.right],left)
        theta = water/mesh.volume
        theta_face = axis.left_weight*theta[axis.left]+(1-axis.left_weight)*theta[axis.right]
        upwind = np.where(flow>=0,left,right)
        centered = axis.left_weight*left+(1-axis.left_weight)*right
        low_flux.append(flow*upwind-diffusion*axis.area_over_distance*theta_face*(right-left))
        correction.append(step*flow*(centered-upwind))
    low = mass+step*(source*inlet-mesh.divergence(low_flux))
    if np.min(low/next_water)<-1e-12:
        raise FloatingPointError('Low-order step violated nonnegativity')

    positive, negative = np.zeros(mesh.shape), np.zeros(mesh.shape)
    for axis,delta in zip(mesh.axes,correction):
        forward,backward = np.maximum(delta,0),np.maximum(-delta,0)
        positive[axis.left] += backward
        negative[axis.left] += forward
        positive[axis.right] += forward
        negative[axis.right] += backward
    add,remove = np.ones(mesh.shape),np.ones(mesh.shape)
    headroom = np.maximum(next_water*upper-low,0)
    available = np.maximum(low-next_water*lower,0)
    np.divide(headroom,positive,out=add,where=positive>headroom)
    np.divide(available,negative,out=remove,where=negative>available)
    limited = []
    for axis,delta in zip(mesh.axes,correction):
        forward = np.minimum(remove[axis.left],add[axis.right])
        backward = np.minimum(add[axis.left],remove[axis.right])
        limited.append(delta*np.minimum(1,np.where(delta>=0,forward,backward)))
    updated = low-mesh.divergence(limited)
    result = updated/next_water
    if not np.isfinite(result).all() or np.min(result)<-1e-12:
        raise FloatingPointError('Limited step violated nonnegativity')
    if np.max(np.maximum(result-upper,lower-result))>1e-11:
        raise FloatingPointError('Limited step violated the local concentration bounds')
    return updated


def advance(mesh, mass, water0, water1, fluxes, source, inlet, diffusion, dt, *,
            tracer_source=None, max_step=None):
    """SSPRK2 of tracer mass using a low-order step plus bounded face corrections.

    source is water in m³/s and inlet is kg/m³. tracer_source can override the
    tracer input for the separate fixed-water analytical diffusion diagnostic.
    """
    if not (dt>0 and diffusion>=0 and inlet>=0) or np.any(source<0):
        raise ValueError('Invalid time, diffusion, or source')
    if np.min(water0)<=0 or np.min(water1)<=0 or np.min(mass)<0:
        raise ValueError('Storage must be positive and incoming mass nonnegative')
    delta = water1-water0
    if np.max(np.abs(delta/dt+mesh.divergence(fluxes)-source))>1e-16:
        raise ValueError('Water storage and face flux must satisfy discrete continuity')
    loss = np.zeros(mesh.shape)
    theta_bound = np.max(np.maximum(water0,water1)/mesh.volume)
    for axis,flux in zip(mesh.axes,fluxes):
        diffusive = 2*diffusion*axis.area_over_distance*theta_bound
        loss[axis.left] += np.maximum(flux,0)+diffusive
        loss[axis.right] += np.maximum(-flux,0)+diffusive
    substeps = max(1,int(np.ceil(dt*np.max(loss/np.minimum(water0,water1))/.45)))
    if max_step is not None:
        if not np.isfinite(max_step) or max_step<=0:
            raise ValueError('Maximum transport step must be positive and finite')
        substeps = max(substeps,int(np.ceil(dt/max_step)))
    if tracer_source is not None:
        # Exact source half-steps keep the fixed-water analytical diagnostic
        # separate from the physically coupled injection concentration bounds.
        half_source = tracer_source*dt/(2*substeps)
    step = dt/substeps
    increment = delta/substeps
    for j in range(substeps):
        w = water0+j*increment
        if tracer_source is not None:
            mass = mass+half_source
        stage = _euler(mesh,mass,w,w+increment,fluxes,source,inlet,diffusion,step)
        stage = _euler(mesh,stage,w+increment,w+2*increment,fluxes,source,inlet,diffusion,step)
        mass = .5*(mass+stage)
        if tracer_source is not None:
            mass = mass+half_source
    return mass,substeps
