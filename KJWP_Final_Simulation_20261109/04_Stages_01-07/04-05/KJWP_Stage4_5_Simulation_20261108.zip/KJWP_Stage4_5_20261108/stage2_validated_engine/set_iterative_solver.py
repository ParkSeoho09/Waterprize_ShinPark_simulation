"""Change ONLY the OGS linear algebra solver in a not-yet-started input.

The physical input, FEM discretization and nonlinear tolerance stay identical.
Run on a fresh case, never on a running/completed OGS input.
"""
import argparse
from pathlib import Path
import xml.etree.ElementTree as ET
from run_validation import write_json

def apply(folder):
    folder=Path(folder)
    if (folder/'ogs/ogs.log').exists():raise RuntimeError('OGS log exists: preserve this case instead of editing')
    p=folder/'input/flow.prj';raw=p.read_bytes()
    (folder/'input/flow_SparseLU_original.prj').write_bytes(raw)
    tree=ET.fromstring(raw);e=tree.find('.//linear_solvers/linear_solver/eigen')
    for old in list(e):e.remove(old)
    for key,value in [('solver_type','CG'),('precon_type','DIAGONAL'),('max_iteration_step','10000'),('error_tolerance','1e-14')]:
        ET.SubElement(e,key).text=value
    ET.ElementTree(tree).write(p,encoding='utf-8',xml_declaration=True)
    write_json(folder/'linear_solver_change.json',dict(change='SparseLU -> CG / DIAGONAL',linear_relative_tolerance=1e-14,
        physical_parameters_changed=False,spatial_discretization_changed=False,
        reason='Reduce sparse factorization cost on refined 3D grids; validate against SparseLU on the coarse grid'))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('folder');apply(p.parse_args().folder)
