"""Matched conservative passive tracer through the original water kernel.

OGS 6.5.9 legacy RCT has phi*R*dC/dt + q.grad(C), not d(theta*C)/dt.
Its input is algebraically mapped by R=S, Dp=S*D, lambda=Sw/theta.
These numerical coefficient slots DO NOT represent adsorption or chemistry.
Original solver sources are never edited. See EQUATION_MAPPING.md.
"""
from pathlib import Path
import argparse,csv,json,time
import xml.etree.ElementTree as ET
import numpy as np
import run_validation as rv
import run_3d_injection as water_case
from precision_linear_backend import checked_cg,SOLVES
import kjwp_stage1.flow.richards as richards
from kjwp_stage1.physics.boundary import Boundary
from kjwp_stage1.numerics.transient_muscl import transport_muscl

ROOT=Path(__file__).resolve().parent
CIN=.04
D=1e-8


def save_csv(path,rows):
    with Path(path).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)


def function(name,expression):
    p=ET.Element('property');ET.SubElement(p,'name').text=name
    ET.SubElement(p,'type').text='Function'
    ET.SubElement(ET.SubElement(p,'value'),'expression').text=expression
    return p


def setup(n,dt,mode,folder):
    grid,points,cells,src,contract=water_case.setup(n,dt,300.,folder)
    project=folder/'input/flow.prj';tree=ET.parse(project)
    process=tree.find('./processes/process')
    process.find('type').text='RichardsComponentTransport'
    process.remove(process.find('mass_lumping'))
    pv=process.find('process_variables');pv.clear()
    ET.SubElement(pv,'concentration').text='tracer'
    ET.SubElement(pv,'pressure').text='pressure'
    medium=tree.find('./media/medium')
    phase=medium.find('./phases/phase')
    components=ET.SubElement(phase,'components');comp=ET.SubElement(components,'component')
    ET.SubElement(comp,'name').text='tracer';props=ET.SubElement(comp,'properties')
    sr=rv.SOIL['theta_r']/rv.SOIL['theta_s'];m=1-1/rv.SOIL['n']
    saturation=f'({sr:.17g}+(1-{sr:.17g})*(1+(3.6*max(capillary_pressure,0)/9810)^1.56)^(-{m:.17g}))'
    sw='if((x>=0.05) and (x<0.15) and (y>=0.05) and (y<0.15) and (z>=0.15) and (z<0.25),5e-5,0)'
    props.append(function('retardation_factor',saturation))
    props.append(function('pore_diffusion',f'{D:.17g}*{saturation}'))
    props.append(function('decay_rate',f'({sw})/(0.43*{saturation})'))
    for name in ('longitudinal_dispersivity','transversal_dispersivity'):
        medium.find('properties').append(ET.fromstring(rv.prop(name,0)))
    # pressure source units are 1/s in this incompressible pressure-head form.
    pars=tree.find('parameters')
    for name,value in [('tracer_initial',CIN if mode=='uniform' else 0.),('tracer_source',5e-5*CIN)]:
        p=ET.SubElement(pars,'parameter');ET.SubElement(p,'name').text=name
        if name=='tracer_initial':
            ET.SubElement(p,'type').text='Constant';ET.SubElement(p,'value').text=str(value)
        else:
            ET.SubElement(p,'type').text='MeshElement';ET.SubElement(p,'mesh').text='line'
            ET.SubElement(p,'field_name').text='tracer_source_rate'
    meshpath=folder/'input/line.vtu';mesh=ET.parse(meshpath)
    rv.data(mesh.find('.//CellData'),'tracer_source_rate',(src*CIN).ravel())
    mesh.write(meshpath,encoding='utf-8',xml_declaration=True)
    global_pv=tree.find('./process_variables')
    c=ET.Element('process_variable');ET.SubElement(c,'name').text='tracer'
    ET.SubElement(c,'components').text='1';ET.SubElement(c,'order').text='1'
    ET.SubElement(c,'initial_condition').text='tracer_initial';ET.SubElement(c,'boundary_conditions')
    term=ET.SubElement(ET.SubElement(c,'source_terms'),'source_term')
    ET.SubElement(term,'mesh').text='line';ET.SubElement(term,'type').text='Volumetric'
    ET.SubElement(term,'parameter').text='tracer_source';global_pv.insert(0,c)
    conv=tree.find('.//convergence_criterion');conv.clear()
    ET.SubElement(conv,'type').text='PerComponentDeltaX'
    ET.SubElement(conv,'norm_type').text='INFINITY_N'
    ET.SubElement(conv,'abstols').text='1e-12 1e-9'
    solver=tree.find('.//linear_solvers/linear_solver/eigen');solver.clear()
    for k,v in [('solver_type','BiCGSTAB'),('precon_type','DIAGONAL'),('max_iteration_step','20000'),('error_tolerance','1e-14')]:
        ET.SubElement(solver,k).text=v
    tree.find('.//output/timesteps/pair/each_steps').text=str(round(50/dt))
    output=tree.find('.//output/variables');output.clear()
    for v in ('pressure','tracer'):ET.SubElement(output,'variable').text=v
    tree.write(project,encoding='utf-8',xml_declaration=True)
    contract.update(case='S2_PASSIVE_TRACER_01',mode=mode,
        concentration_units='kg tracer / m3 liquid water',initial_tracer_kg_m3=CIN if mode=='uniform' else 0.,
        inlet_tracer_kg_m3=CIN,dispersion_m2_s=[D,D,D],
        expected_tracer_input_kg=contract['expected_water_in_m3']*CIN,
        ogs_transport_mapping={'retardation_slot':'S(p), numerical water storage weight, no adsorption',
          'pore_diffusion_slot':'S(p)*D','decay_slot':'Sw/theta, conservative dilution coefficient, no reaction'},
        equations='d(theta*C)/dt + div(q*C-theta*D*grad(C)) = Sw*Cin',
        internal_targets={'tracer_bulk_mass_L1_relative':.05,'injection_mass_balance_relative':.01},
        scope='Passive dissolved tracer only; no pressure outlet/slurry/particles/chemistry',
        comparison='Q1 pressure and tracer, theta*C integrated by Gauss points')
    rv.write_json(folder/'contract.json',contract)
    return grid,cells,src,contract


def custom(grid,src,contract,folder):
    richards.spsolve=checked_cg
    soil=rv.VanGenuchten(**rv.SOIL)
    flow=rv.PressureFlow(grid,soil,{f:rv.WaterBoundary() for f in rv.FACES},theta_tolerance=1e-13,max_iterations=200)
    flow.set_fluid(dict(carrier_mobility_ratio=1.,gravity_ratio=1.))
    z,_,_=grid.mesh_zyx();h=z-.65;theta0=flow.theta(h)
    c=np.full(grid.shape,contract['initial_tracer_kg_m3'])
    mass0=float((theta0*c).sum()*grid.volume);water0=float(theta0.sum()*grid.volume)
    bounds={f:Boundary('closed') for f in rv.FACES}
    dt=contract['dt_s'];nsteps=round(300/dt);stride=round(50/dt)
    times=[];heads=[];thetas=[];fields=[];rows=[];inmass=0.;started=time.perf_counter()
    for i in range(nsteps+1):
        if i:
            water=flow.step(h,(i-1)*dt,dt,src)
            c,budget=transport_muscl(grid,water,c,dt,(D,D,D),bounds,i*dt,src*CIN)
            inmass+=budget['source_in_kg'];h=water.head
        theta=flow.theta(h);mass=float((theta*c).sum()*grid.volume)
        rows.append(dict(time_s=i*dt,tracer_initial_kg=mass0,tracer_input_kg=inmass,tracer_stored_kg=mass,
            tracer_residual_kg=mass-mass0-inmass,
            tracer_balance_relative_to_input=None if not inmass else abs(mass-mass0-inmass)/inmass,
            water_residual_m3=float(theta.sum()*grid.volume-water0-contract['total_rate_m3_s']*i*dt),
            tracer_min_kg_m3=float(c.min()),tracer_max_kg_m3=float(c.max())))
        if i%stride==0:
            times.append(i*dt);heads.append(h.copy());thetas.append(theta.copy());fields.append(c.copy())
            print(f'custom {folder.name} t={i*dt:g}s wall={time.perf_counter()-started:.1f}s',flush=True)
    out=folder/'custom';out.mkdir(exist_ok=True)
    np.savez_compressed(out/'fields.npz',time_s=times,head_m=heads,theta=thetas,tracer_kg_m3=fields,
        x_m=grid.centers_xyz[0],y_m=grid.centers_xyz[1],z_m=grid.centers_xyz[2])
    save_csv(out/'mass_history.csv',rows)
    rv.write_json(out/'summary.json',dict(final=rows[-1],wall_seconds=time.perf_counter()-started,
        uniform_max_abs_error_kg_m3=float(np.max(abs(c-CIN))) if contract['mode']=='uniform' else None,
        max_linear_residual=max(x['relative_residual'] for x in SOLVES)))


def analyze(grid,cells,contract,folder):
    fields=np.load(folder/'custom/fields.npz')
    files={float(e.attrib['timestep']):folder/'ogs'/e.attrib['file'] for e in ET.parse(folder/'ogs/flow.pvd').findall('.//DataSet')}
    q,w=np.polynomial.legendre.leggauss(3)
    signs=np.array([[-1,-1,-1],[1,-1,-1],[1,1,-1],[-1,1,-1],[-1,-1,1],[1,-1,1],[1,1,1],[-1,1,1]])
    shapes=[];weights=[]
    for i,a in enumerate(q):
        for j,b in enumerate(q):
            for k,c in enumerate(q):
                shapes.append(np.prod(1+signs*np.array([a,b,c]),axis=1)/8);weights.append(w[i]*w[j]*w[k]/8)
    shapes=np.asarray(shapes);weights=np.asarray(weights);soil=rv.VanGenuchten(**rv.SOIL)
    rows=[];theta_all=[];c_all=[];mass_all=[]
    for i,t in enumerate(fields['time_s']):
        head=rv.nodal(files[float(t)],'pressure')/(rv.RHO*rv.GRAV)
        cn=rv.nodal(files[float(t)],'tracer');hv=head[cells];cv=cn[cells]
        thetaq=soil.theta(hv@shapes.T);cq=cv@shapes.T
        theta=(thetaq@weights).reshape(grid.shape);c=cv.mean(axis=1).reshape(grid.shape)
        mass=((thetaq*cq)@weights).reshape(grid.shape)
        own_mass=fields['theta'][i]*fields['tracer_kg_m3'][i]
        if i==0:initial=mass.copy();initial_theta=theta.copy()
        incoming=contract['total_rate_m3_s']*CIN*float(t)
        norm=float(abs(own_mass).sum()*grid.volume)
        row=dict(time_s=float(t),tracer_mass_bulk_L1_relative=None if norm==0 else float(abs(mass-own_mass).sum()*grid.volume/norm),
            tracer_concentration_mae_kg_m3=float(abs(c-fields['tracer_kg_m3'][i]).mean()),
            ogs_tracer_stored_kg=float(mass.sum()*grid.volume),expected_tracer_input_kg=incoming,
            ogs_tracer_balance_relative_to_input=None if not incoming else float(abs((mass-initial).sum()*grid.volume-incoming)/incoming),
            ogs_water_storage_change_m3=float((theta-initial_theta).sum()*grid.volume),
            ogs_native_tracer_min_kg_m3=float(cn.min()),ogs_native_tracer_max_kg_m3=float(cn.max()),
            ogs_cell_tracer_min_kg_m3=float(c.min()),
            ogs_uniform_max_abs_error_kg_m3=float(np.max(abs(cn-CIN))) if contract['mode']=='uniform' else None)
        rows.append(row);theta_all.append(theta);c_all.append(c);mass_all.append(mass)
    out=folder/'analysis';out.mkdir(exist_ok=True);save_csv(out/'comparison.csv',rows)
    np.savez_compressed(out/'ogs_fields.npz',time_s=fields['time_s'],theta=theta_all,tracer_kg_m3=c_all,mass_bulk_kg_m3=mass_all)
    summary=dict(n=grid.cells_xyz[0],dt_s=contract['dt_s'],mode=contract['mode'],final=rows[-1],
        native_undershoot_present=rows[-1]['ogs_native_tracer_min_kg_m3']<-1e-12,
        scope=contract['scope'],status='DIAGNOSTIC_ONLY_NO_AUTOMATIC_VALIDATION_CLAIM')
    rv.write_json(out/'summary.json',summary);print(json.dumps(summary),flush=True)


def main():
    p=argparse.ArgumentParser();p.add_argument('--n',type=int,required=True);p.add_argument('--dt',type=float,default=10.)
    p.add_argument('--mode',choices=['uniform','injection'],default='injection')
    p.add_argument('--output-root',type=Path,default=ROOT/'runs')
    p.add_argument('--ogs-exe',help='Recovered OGS 6.5.9 executable; omit for installed Python package')
    a=p.parse_args()
    if a.n%4 or abs(50/a.dt-round(50/a.dt))>1e-10:raise ValueError('source-aligned N and snapshot-aligned dt required')
    folder=a.output_root.resolve()/f'tracer_{a.mode}_N{a.n}_dt{a.dt:g}'
    if folder.exists():raise RuntimeError('Preserve existing evidence; choose a fresh case')
    folder.mkdir(parents=True)
    grid,cells,src,contract=setup(a.n,a.dt,a.mode,folder)
    custom(grid,src,contract,folder);rv.ogs_run(folder,a.ogs_exe);analyze(grid,cells,contract,folder)
    rv.write_json(folder/'complete.json',dict(complete=True))


if __name__=='__main__':main()
