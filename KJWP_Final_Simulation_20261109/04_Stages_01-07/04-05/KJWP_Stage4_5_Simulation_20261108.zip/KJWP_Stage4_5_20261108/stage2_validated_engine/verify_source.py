"""Check spatial source representation independently of the flow solution."""
from pathlib import Path
import json

import numpy as np
from scipy.linalg import solve_banded
from scipy.special import erf

from conservative_transport import CartesianMesh, advance
from run_graded_ogs import refined_edges

ROOT = Path(__file__).resolve().parent
SOURCE_BOX = ((.05,.15),(.05,.15),(.15,.25))
THETA = .3
DIFFUSION = 1e-8
END = 300.
INLET = .04


def make_mesh(split):
    x = refined_edges(.1,16,[.05],.0125,split)
    z = refined_edges(.4,64,[.15,.25],.0125,split)
    return CartesianMesh((x,x,z))


def exact_diffusing_source(mesh, order):
    """Average the infinite-domain box-source heat solution in each cell.

    Horizontal symmetry cuts the full source in quarters. The other closed
    boundaries are far from the concentration front at this diagnostic time.
    """
    times, weights = np.polynomial.legendre.leggauss(order)
    result = np.zeros(mesh.shape)
    for point,weight in zip(times,weights):
        u = (point+1)/2
        width = np.sqrt(4*DIFFUSION*END)*u
        factors = []
        for edges,(a,b) in zip(mesh.edges_xyz,SOURCE_BOX):
            def primitive(x):
                return x*erf(x/width)+width*np.exp(-(x/width)**2)/np.sqrt(np.pi)
            factors.append(np.diff((primitive(edges-a)-primitive(edges-b))/2)/np.diff(edges))
        x,y,z = factors
        result += weight*END*u*z[:,None,None]*y[None,:,None]*x[None,None,:]
    return 5e-5*INLET*result


def consistent_source_projection(mesh):
    """Q1 Galerkin source projection with a consistent mass matrix and q=D=0."""
    functions = []
    for edges,(a,b) in zip(mesh.edges_xyz,SOURCE_BOX):
        width = np.diff(edges)
        left,right = np.r_[0.,width],np.r_[width,0.]
        source_width = width*((edges[:-1]+edges[1:])/2>=a)*((edges[:-1]+edges[1:])/2<b)
        rhs = (np.r_[0.,source_width]+np.r_[source_width,0.])/2
        matrix = np.zeros((3,len(edges)))
        matrix[1] = (left+right)/3
        matrix[0,1:] = width/6
        matrix[2,:-1] = width/6
        functions.append(solve_banded((1,1),matrix,rhs))
    x,y,z = functions
    return 5e-5*INLET*END/THETA*z[:,None,None]*y[None,:,None]*x[None,None,:]


def relative_l1(mesh, a, b):
    return float(np.sum(np.abs(a-b)*mesh.volume)/np.sum(np.abs(b)*mesh.volume))


def check_limiter():
    """Closed circulation with a discontinuous pulse exercises the face limiter."""
    mesh = CartesianMesh((np.array([0.,.05,.1]),)*3)
    water = THETA*mesh.volume
    fluxes = tuple(np.zeros_like(a.area_over_distance) for a in mesh.axes)
    z,y,x = fluxes
    x[0,0,0],x[0,1,0] = 2e-6,-2e-6
    y[0,0,1],y[0,0,0] = 2e-6,-2e-6
    source = np.zeros(mesh.shape)
    initial = source.copy()
    initial[0,0,0] = INLET*water[0,0,0]
    centered = tuple(q*(initial[a.left]/water[a.left]+initial[a.right]/water[a.right])/2
                     for a,q in zip(mesh.axes,fluxes))
    unbounded = initial-5*mesh.divergence(centered)
    limited,_ = advance(mesh,initial,water,water,fluxes,source,INLET,0.,5.)
    result = dict(centered_euler_min_kg_m3=float((unbounded/water).min()),
                  limited_min_kg_m3=float((limited/water).min()),
                  limited_max_kg_m3=float((limited/water).max()),
                  mass_residual_kg=float(limited.sum()-initial.sum()))
    if not (result['centered_euler_min_kg_m3']<0<=result['limited_min_kg_m3']
            and result['limited_max_kg_m3']<=INLET and abs(result['mass_residual_kg'])<1e-20):
        raise RuntimeError('Closed circulation limiter check failed')
    return result


def main():
    result = []
    output = ROOT/'source_diagnostic'
    output.mkdir(exist_ok=True)
    for split in [1,2,4]:
        mesh = make_mesh(split)
        reference = exact_diffusing_source(mesh,128)
        quad_change = relative_l1(mesh,exact_diffusing_source(mesh,64),reference)
        if quad_change>1e-8:
            raise RuntimeError('Analytical temporal quadrature failed to converge')
        water = THETA*mesh.volume
        fluxes = tuple(np.zeros_like(a.area_over_distance) for a in mesh.axes)
        zero = np.zeros(mesh.shape)
        supply = mesh.source_rate()*INLET
        mass = zero
        for _ in range(30):
            mass,_ = advance(mesh,mass,water,water,fluxes,zero,INLET,DIFFUSION,10.,tracer_source=supply)
        gal = consistent_source_projection(mesh)
        row = dict(split=split,shape_zyx=mesh.shape,
                   min_width_mm=float(min(w.min() for w in mesh.widths)*1000),
                   numerical_L1_relative=relative_l1(mesh,mass/mesh.volume,reference),
                   analytical_quadrature_L1_relative=quad_change,
                   numerical_mass_residual_kg=float(4*(mass.sum()-END*supply.sum())),
                   min_numerical_kg_m3=float((mass/water).min()),
                   consistent_source_nodal_min_kg_m3=float(gal.min()),
                   consistent_source_nodal_max_kg_m3=float(gal.max()))
        result.append(row)
        np.savez_compressed(output/f'split{split}.npz',exact_mass_bulk_kg_m3=reference,
                            calculated_mass_bulk_kg_m3=mass/mesh.volume,
                            consistent_source_nodal_kg_m3=gal,
                            x_edges_m=mesh.edges_xyz[0],y_edges_m=mesh.edges_xyz[1],
                            z_edges_m=mesh.edges_xyz[2])
        print(json.dumps(row),flush=True)
    (output/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
    (output/'limiter_check.json').write_text(json.dumps(check_limiter(),indent=2)+'\n')


if __name__=='__main__':
    main()
