import ctypes
import sys
import time
from ogs import cli
code=cli.ogs(*sys.argv[1:])
# The wheel returns after completing the solve; let pending native log writes
# drain before interpreter shutdown. This does not change the numerical solve.
time.sleep(.25)
sys.stdout.flush()
sys.stderr.flush()
if sys.platform!='win32':
    ctypes.CDLL(None).fflush(None)
sys.exit(code)
