"""Compare conservative cell averages on the same and on union partitions."""
import csv
import json
from pathlib import Path

import numpy as np

from conservative_transport import CartesianMesh

ROOT = Path(__file__).resolve().parent
RUNS = ROOT/'runs'


def read_run(name, filename, field):
    case = RUNS/name
    contract = json.loads((case/'contract.json').read_text())
    mesh = CartesianMesh(contract['edges_xyz_m'])
    with np.load(case/filename) as a:
        time = a['time_s']
        mass = a['theta']*a['tracer_kg_m3'] if field is None else a[field]
    return mesh,time,mass


def baseline():
    with np.load(ROOT/'baseline_N32_fields.npz') as a:
        mesh = CartesianMesh([a[f'{axis}_edges_m'] for axis in 'xyz'])
        time = a['time_s']
        return (mesh,time,a['fv_mass_bulk_kg_m3']),(mesh,time,a['ogs_mass_bulk_kg_m3'])


def compare(a,b):
    mesh_a,time_a,field_a = a
    mesh_b,time_b,field_b = b
    if not np.array_equal(time_a,time_b):
        raise ValueError('Sample times differ')
    n32 = CartesianMesh((np.linspace(0,.1,17),np.linspace(0,.1,17),np.linspace(0,.4,65)))
    union = CartesianMesh([np.unique(np.round(np.r_[x,y],12))
                           for x,y in zip(mesh_a.edges_xyz,mesh_b.edges_xyz)])
    rows = []
    for t,u,v in zip(time_a[1:],field_a[1:],field_b[1:]):
        row = {'time_s':float(t)}
        for tag,mesh in [('N32',n32),('union',union)]:
            x,y = mesh_a.project_averages(u,mesh),mesh_b.project_averages(v,mesh)
            native_mass = np.sum(v*mesh_b.volume)
            if abs(np.sum(y*mesh.volume)-native_mass)>1e-17:
                raise RuntimeError('Projection does not conserve the reference mass')
            native_mass = np.sum(u*mesh_a.volume)
            if abs(np.sum(x*mesh.volume)-native_mass)>1e-17:
                raise RuntimeError('Projection does not conserve the compared mass')
            row[f'L1_relative_{tag}'] = float(np.sum(abs(x-y)*mesh.volume)/np.sum(abs(y)*mesh.volume))
        rows.append(row)
    return rows


def main():
    original_fv,original_ogs = baseline()
    fv = {k:read_run(k,'custom/fields.npz',None) for k in ['fv_N64_dt5','fv_N64_dt10','fv_N96_dt10']}
    native,replay = {},{}
    for split in [1,2,4]:
        name = f'graded_s{split}_dt10'
        native[split] = read_run(name,'replay_fields.npz','raw_mass_bulk_kg_m3')
        replay[split] = read_run(name,'replay_fields.npz','mass_bulk_kg_m3')
    reference = fv['fv_N96_dt10']
    pairs = {
        'original_OGS_vs_original_FV_N32':(original_ogs,original_fv),
        'quarter_OGS_vs_original_OGS_N32':(native[1],original_ogs),
        'same_grid_replay_vs_original_FV_N32':(replay[1],original_fv),
        'FV_N64_vs_FV_N96_dt10':(fv['fv_N64_dt10'],reference),
        'FV_N64_dt10_vs_dt5':(fv['fv_N64_dt10'],fv['fv_N64_dt5']),
    }
    for split in [1,2,4]:
        pairs[f'OGS_s{split}_vs_FV_N96'] = (native[split],reference)
        pairs[f'replay_s{split}_vs_FV_N96'] = (replay[split],reference)
    result = {name:compare(a,b) for name,(a,b) in pairs.items()}
    (ROOT/'comparison.json').write_text(json.dumps(result,indent=2)+'\n')
    with (ROOT/'comparison.csv').open('w',newline='') as f:
        writer = csv.DictWriter(f,fieldnames=['pair','time_s','L1_relative_N32','L1_relative_union'])
        writer.writeheader()
        for name,rows in result.items():
            writer.writerows(dict(pair=name,**r) for r in rows)
    for name,rows in result.items():
        print(f'{name:42s}', 'N32',f"{rows[-1]['L1_relative_N32']*100:7.4f}%",
              'union',f"{rows[-1]['L1_relative_union']*100:7.4f}%")


if __name__=='__main__':
    main()
