"""Run the unchanged custom transport on a finer quarter-domain grid."""
import argparse
from pathlib import Path

import run_tracer as tracer
from kjwp_stage1.core.grid import Grid


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--n',type=int,required=True,help='Full-domain equivalent horizontal resolution')
    parser.add_argument('--dt',type=float,choices=[5.,10.],default=10.)
    parser.add_argument('--output',type=Path,required=True)
    args = parser.parse_args()
    if args.n < 4 or args.n % 4:
        raise ValueError('N must be a positive multiple of four')
    folder = args.output.resolve()
    folder.mkdir(parents=True)
    n = args.n
    grid = Grid((.1,.1,.4),(n//2,n//2,2*n))
    z,y,x = grid.mesh_zyx()
    source = ((x>=.05)&(y>=.05)&(z>=.15)&(z<.25))*5e-5
    contract = dict(dt_s=args.dt,total_rate_m3_s=float(source.sum()*grid.volume),
                    initial_tracer_kg_m3=0.,mode='injection',symmetry_factor=4,
                    cells_xyz=grid.cells_xyz,lengths_m=grid.lengths_m,
                    edges_xyz_m=[v.tolist() for v in grid.edges_xyz],
                    dispersion_m2_s=[tracer.D]*3,inlet_tracer_kg_m3=tracer.CIN,end_s=300.)
    tracer.rv.write_json(folder/'contract.json',contract)
    tracer.custom(grid,source,contract,folder)


if __name__=='__main__':
    main()
