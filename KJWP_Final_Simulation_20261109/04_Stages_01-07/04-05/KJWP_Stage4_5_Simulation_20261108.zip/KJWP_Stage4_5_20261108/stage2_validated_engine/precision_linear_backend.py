"""Stage 2 refinement, preserving v0.3.0 equations and physical parameters.

The original source tree is immutable. Only its linear solve is replaced at
runtime by residual-checked Jacobi-CG; a saved direct-solve case verifies this.
Output cadence is independent of the integration time step.
"""
from pathlib import Path
import argparse, csv, hashlib, json, time
import xml.etree.ElementTree as ET
import numpy as np
from scipy.sparse.linalg import cg, LinearOperator
import run_validation as rv
import run_3d_injection as base
from set_iterative_solver import apply as ogs_cg
import kjwp_stage1.flow.richards as richards

ROOT = Path(__file__).resolve().parent
OLD = ROOT.parent / 'KJWP_Stage2_OGS_Validation_20261103_v1'
SOLVES = []


def checked_cg(A, b):
    diagonal = A.diagonal()
    if np.any(diagonal <= 0):
        raise RuntimeError('Jacobi-CG requires positive diagonal')
    preconditioner = LinearOperator(A.shape, matvec=lambda x: x / diagonal)
    iterations = [0]
    def count(_):
        iterations[0] += 1
    started = time.perf_counter()
    x, info = cg(A, b, rtol=1e-13, atol=0., maxiter=10000,
                 M=preconditioner, callback=count)
    relative = float(np.linalg.norm(A @ x - b) / max(np.linalg.norm(b), 1e-300))
    SOLVES.append(dict(iterations=iterations[0], relative_residual=relative,
                       seconds=time.perf_counter() - started, info=int(info)))
    if info or relative > 5e-12 or not np.all(np.isfinite(x)):
        raise RuntimeError(f'CG failed: info={info}, actual relative residual={relative}')
    return x


def save_csv(path, rows):
    with Path(path).open('w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def run_custom(grid, src, contract, folder):
    soil = rv.VanGenuchten(**rv.SOIL)
    flow = rv.PressureFlow(grid, soil, {f: rv.WaterBoundary() for f in rv.FACES},
                           theta_tolerance=1e-13, max_iterations=200)
    flow.set_fluid(dict(carrier_mobility_ratio=1., gravity_ratio=1.))
    z, _, _ = grid.mesh_zyx()
    h = z - .65
    theta0 = flow.theta(h)
    stored0 = float(theta0.sum() * grid.volume)
    dt = contract['dt_s']
    nsteps = round(contract['end_s'] / dt)
    stride = round(50. / dt)
    snapshots, heads, thetas, history = [], [], [], []
    started = time.perf_counter()
    for step in range(nsteps + 1):
        water = None
        if step:
            water = flow.step(h, (step-1)*dt, dt, src)
            h = water.head
        theta = flow.theta(h)
        stored = float(theta.sum() * grid.volume)
        injected = contract['total_rate_m3_s'] * step * dt
        history.append(dict(time_s=step*dt, stored_m3=stored, injected_m3=injected,
                            residual_m3=stored-stored0-injected,
                            max_cell_residual=0. if water is None else water.cell_balance_max,
                            nonlinear_iterations=0 if water is None else water.iterations))
        if step % stride == 0 or step == nsteps:
            snapshots.append(step*dt)
            heads.append(h.copy())
            thetas.append(theta.copy())
            print(f'custom {folder.name} t={step*dt:g}s wall={time.perf_counter()-started:.2f}s', flush=True)
    out = folder / 'custom'
    out.mkdir(exist_ok=True)
    np.savez_compressed(out/'fields.npz', time_s=snapshots, head_m=heads, theta=thetas,
                        x_m=grid.centers_xyz[0], y_m=grid.centers_xyz[1],
                        z_m=grid.centers_xyz[2], source_s_inv=src)
    save_csv(out/'water_history.csv', history)
    summary = dict(wall_seconds=time.perf_counter()-started, final=history[-1],
                   max_abs_water_balance_m3=max(abs(x['residual_m3']) for x in history),
                   max_cell_residual=max(x['max_cell_residual'] for x in history),
                   linear_backend='Jacobi-CG rtol=1e-13; explicit residual check <=5e-12',
                   nonlinear_theta_tolerance=1e-13,
                   linear_calls=len(SOLVES),
                   max_actual_linear_relative_residual=max(x['relative_residual'] for x in SOLVES))
    rv.write_json(out/'summary.json', summary)
    rv.write_json(out/'linear_solves.json', SOLVES)


def physical_metrics(theta, theta0, grid):
    delta = theta - theta0
    weight = np.maximum(delta, 0.) * grid.volume
    total = float(weight.sum())
    z, y, x = grid.mesh_zyx()
    result = dict(storage_change_m3=float(delta.sum()*grid.volume),
                  positive_change_m3=total, negative_change_m3=float(np.minimum(delta, 0.).sum()*grid.volume),
                  max_delta_theta=float(delta.max()))
    if total > 0:
        result.update(centroid_x_m=float((weight*x).sum()/total),
                      centroid_y_m=float((weight*y).sum()/total),
                      centroid_z_m=float((weight*z).sum()/total),
                      radial_rms_m=float(np.sqrt((weight*((x-.1)**2+(y-.1)**2)).sum()/total)))
        layer = weight.sum(axis=(1, 2))
        cumulative = np.r_[0., np.cumsum(layer)]/total
        result['z05_m'] = float(np.interp(.05, cumulative, grid.edges_xyz[2]))
        result['z95_m'] = float(np.interp(.95, cumulative, grid.edges_xyz[2]))
    return result


def analyze(grid, cells, contract, folder):
    custom = np.load(folder/'custom/fields.npz')
    files = {round(float(e.attrib['timestep']), 8): folder/'ogs'/e.attrib['file']
             for e in ET.parse(folder/'ogs/flow.pvd').findall('.//DataSet')}
    q, w = np.polynomial.legendre.leggauss(3)
    signs = np.array([[-1,-1,-1],[1,-1,-1],[1,1,-1],[-1,1,-1],
                      [-1,-1,1],[1,-1,1],[1,1,1],[-1,1,1]])
    shapes, weights = [], []
    for i, a in enumerate(q):
        for j, b in enumerate(q):
            for k, c in enumerate(q):
                shapes.append(np.prod(1+signs*np.array([a,b,c]), axis=1)/8)
                weights.append(w[i]*w[j]*w[k]/8)
    shapes, weights = np.asarray(shapes), np.asarray(weights)
    soil = rv.VanGenuchten(**rv.SOIL)
    rows, heads, thetas = [], [], []
    for i, t in enumerate(custom['time_s']):
        hv = (rv.nodal(files[round(float(t),8)], 'pressure')/(rv.RHO*rv.GRAV))[cells]
        head = hv.mean(axis=1).reshape(grid.shape)
        theta = (soil.theta(hv @ shapes.T) @ weights).reshape(grid.shape)
        if not i:
            initial = theta.copy()
        co = custom['theta'][i]
        dc = co-custom['theta'][0]
        do = theta-initial
        norm = float(np.abs(dc).sum()*grid.volume)
        injected = contract['total_rate_m3_s']*float(t)
        storage = float(do.sum()*grid.volume)
        rows.append(dict(time_s=float(t), head_mae_m=float(np.abs(head-custom['head_m'][i]).mean()),
                         theta_mae=float(np.abs(theta-co).mean()),
                         theta_max_abs=float(np.abs(theta-co).max()),
                         perturbation_L1_relative=None if norm==0 else float(np.abs(do-dc).sum()*grid.volume/norm),
                         expected_in_m3=injected, ogs_storage_change_m3=storage,
                         ogs_balance_relative=None if not injected else abs(storage-injected)/injected))
        heads.append(head)
        thetas.append(theta)
    out = folder/'analysis'
    out.mkdir(exist_ok=True)
    save_csv(out/'comparison.csv', rows)
    np.savez_compressed(out/'ogs_fields.npz', time_s=custom['time_s'], head_m=heads, theta=thetas)
    metrics = dict(custom=physical_metrics(custom['theta'][-1],custom['theta'][0],grid),
                   ogs=physical_metrics(thetas[-1],thetas[0],grid))
    rv.write_json(out/'physical_metrics.json',metrics)
    summary = dict(n=grid.cells_xyz[0], cells_xyz=grid.cells_xyz, dt_s=contract['dt_s'],
                   final=rows[-1], metrics=metrics,
                   scope='Prescribed volumetric pure water source, not nozzle/slurry/tracer/reaction',
                   status='DIAGNOSTIC_RECORD_ONLY',
                   internal_distribution_goal=.02,
                   goal_met=rows[-1]['perturbation_L1_relative']<=.02)
    rv.write_json(out/'summary.json', summary)
    print(json.dumps(summary),flush=True)


def baseline_check(folder):
    saved_path=OLD/'runs/injection3d_N20_dt10/custom/fields.npz'
    if not saved_path.exists():saved_path=ROOT/'baseline_reference/direct_N20_dt10.npz'
    saved=np.load(saved_path)
    new=np.load(folder/'custom/fields.npz')
    idx=[int(np.argmin(abs(saved['time_s']-t))) for t in new['time_s']]
    checks=dict(max_head_abs_m=float(np.max(abs(new['head_m']-saved['head_m'][idx]))),
                max_theta_abs=float(np.max(abs(new['theta']-saved['theta'][idx]))))
    checks['pass']=checks['max_head_abs_m']<1e-10 and checks['max_theta_abs']<1e-11
    rv.write_json(folder/'custom/direct_vs_cg.json',checks)
    print('DIRECT_VS_CG',json.dumps(checks),flush=True)
    if not checks['pass']:
        raise RuntimeError('CG has not reproduced the saved original direct solve')


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--n',type=int,required=True)
    parser.add_argument('--dt',type=float,default=10.)
    parser.add_argument('--custom-only',action='store_true')
    parser.add_argument('--baseline-check',action='store_true')
    parser.add_argument('--ogs-exe',help='Recovered OGS 6.5.9 executable; omit for the Python package')
    parser.add_argument('--output-root',type=Path,default=ROOT/'runs',
                        help='Use a fresh directory for reruns; existing evidence is never overwritten')
    args=parser.parse_args()
    if args.n%4 or abs(50/args.dt-round(50/args.dt))>1e-10:
        raise ValueError('Source-aligned N divisible by 4; dt must divide 50 s')
    folder=args.output_root.resolve()/f'precision_N{args.n}_dt{args.dt:g}'
    if folder.exists():
        raise RuntimeError('Preserve previous evidence: choose a fresh run path')
    folder.mkdir(parents=True,exist_ok=True)
    grid,points,cells,src,contract=base.setup(args.n,args.dt,300.,folder)
    if abs(contract['expected_water_in_m3']-15e-6)>1e-16:
        raise RuntimeError('Physical injection volume changed')
    ogs_cg(folder)
    project=folder/'input/flow.prj'
    tree=ET.parse(project)
    tree.find('.//output/timesteps/pair/each_steps').text=str(round(50/args.dt))
    variables=tree.find('.//output/variables')
    for variable in list(variables):
        if variable.text!='pressure': variables.remove(variable)
    tree.write(project,encoding='utf-8',xml_declaration=True)
    contract.update(output_cadence_s=50., output_variables=['pressure'],
                    output_note='Output thinning only; all dt integration steps retained',
                    custom_linear_solver='Jacobi-CG rtol=1e-13; original source unchanged',
                    purpose='Accuracy first refinement; 2% is an internal goal, not certification')
    rv.write_json(folder/'contract.json',contract)
    richards.spsolve=checked_cg
    started=time.perf_counter()
    run_custom(grid,src,contract,folder)
    if args.baseline_check: baseline_check(folder)
    if not args.custom_only:
        rv.ogs_run(folder,args.ogs_exe)
        analyze(grid,cells,contract,folder)
    rv.write_json(folder/'total_execution.json',dict(wall_seconds=time.perf_counter()-started,
                  complete=True, custom_only=args.custom_only))


if __name__=='__main__':
    main()
