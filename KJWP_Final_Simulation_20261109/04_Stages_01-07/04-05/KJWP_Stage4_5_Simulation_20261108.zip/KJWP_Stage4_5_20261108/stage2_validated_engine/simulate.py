"""Run the graded OGS plus conservative tracer calculation in one command."""
import argparse
from pathlib import Path

from replay_ogs import run
from run_graded_ogs import setup
from run_validation import ogs_run


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--ogs-exe',help='Path to an installed OGS 6.5.9 executable')
    parser.add_argument('--pressure-case',type=Path,help='Reuse a completed run and its native snapshots')
    parser.add_argument('--split',type=int,choices=[1,2,4,8],default=4)
    parser.add_argument('--dt',type=float,choices=[5.,10.],default=10.)
    parser.add_argument('--storage-closure',choices=['uniform','source'],default='uniform')
    parser.add_argument('--max-transport-step',type=float)
    args = parser.parse_args()
    output = args.output.resolve()
    output.mkdir(parents=True)
    if args.pressure_case is None:
        setup(output,args.dt,args.split)
        executable = str(Path(args.ogs_exe).resolve()) if args.ogs_exe else None
        ogs_run(output,executable)
        pressure_case = output
    else:
        pressure_case = args.pressure_case.resolve()
    run(pressure_case,output,args.storage_closure,args.max_transport_step)


if __name__=='__main__':
    main()
