# KJWP Stage 2 시뮬레이션과 검증 묶음

2026-11-07 · 3D 주입수·추적물질 이동 모델

`KJWP_Stage2_Resolution_Report_20261107.html`을 열면 비교 결과, 그래프, 판정 범위와 인용 논문을 볼 수 있다. HTML에는 그래프가 포함되어 있다.

## 바로 실행

ZIP을 풀고 이 폴더에서 Python 3.12 환경을 사용한다. 기본 의존성은 다음 명령으로 설치한다.

```bash
python -m pip install -r requirements.txt
```

동봉한 31개 OGS 압력장으로 보존형 추적자 계산을 재현하려면 아래 명령을 실행한다. 계산 결과는 새 폴더에 저장된다.

```bash
python simulate.py --pressure-case runs/graded_s4_dt10 --output my_replay
```

OGS까지 새로 계산하려면 OGS 6.5.9 실행 파일을 지정하거나, 이 폴더의 `runtime/`에 해당 버전의 Python 패키지를 설치한다. 기존 Windows OGS 실행 환경을 쓸 때는 실행 파일의 실제 경로를 인자로 준다.

```bash
python -m pip install --no-deps --target runtime ogs==6.5.9
python simulate.py --output my_full_run --split 4 --dt 10
```

```text
python simulate.py --output my_full_run --ogs-exe "경로/ogs.exe" --split 4 --dt 10
```

검증 실행 환경은 Linux의 OGS 6.5.9 wheel이며, 이 ZIP의 실행 명령은 동봉된 입력을 사용한다. `--split`은 주입원 경계 주변의 세분화 배수다. `--dt`는 물 흐름 시간간격이다. 다른 토양, 포트 압력, 입자 조건의 기존 프로그램은 다음 경로에서 실행한다.

```bash
cd source/kjwp-simulator-3_1
python -m kjwp_stage1.stage2 configs/stage2_pressure_particles.json --out outputs/my_stage2
```

이 대표 압력·입자 사례를 실제 실행한 결과도 `demo_pressure_particles/`에 포함했다. 검증된 보존성 추적자 비교의 조건과 이 압력·입자 시연의 조건은 다르다.

## 파일 구성

| 파일 또는 폴더 | 내용 |
|---|---|
| `simulate.py` | 새 OGS 계산과 보존형 수송을 연결하는 실행 진입점 |
| `conservative_transport.py` | 유량 재구성, 국소 질량수지, 제한 수송 계산 |
| `runs/graded_s1_dt10`, `s2`, `s4` | 원본 OGS 입력과 실행 로그, 모든 시각의 절점 수두·농도 NPZ, 선택한 원본 VTU, 재구성 결과 |
| `runs/fv_N64_dt10`, `fv_N64_dt5`, `fv_N96_dt10` | 기존 자작 모델을 독립 실행한 배열과 질량수지 |
| `baseline_N32_fields.npz` | 이전 전체 영역 계산에서 추출한 1/4 영역의 비교용 원본 셀 평균 |
| `comparison.csv`, `comparison.json` | 각 시각의 공통 N32 및 공통 세분 격자 L1 차이 |
| `source_diagnostic/`, `sensitivity/` | 해석해 대조, 공급원 투영 음수 재현, 수송 제한기, 보정 위치·시간간격 검사 |
| `VALIDATION.json` | 수지·비음수성·동조건 비교와 원본 소스 및 실행 증거 검사 |
| `METHODS.md`, `REFERENCES.md` | 알고리즘, 검증 범위, 사용한 논문과 DOI |

OGS 절점 시계열은 `native_nodes.npz`에 float64로 저장했다. 압력을 ρg로 나눈 수두 단위를 사용한다. ParaView에서는 `ogs/selected.pvd`를 열면 동봉한 원본 0·50·300초 VTU를 볼 수 있다. 전체 31개 원본 VTU는 OGS를 재실행하면 생성된다. NPZ는 그대로 보존형 수송 재현에 사용할 수 있다.

공급원 해석해 검사와 보고서를 다시 만들려면 `python verify_source.py`, `python compare_results.py`, `python build_resolution_report.py`를 순서대로 실행한다.
