# 현재 배포본 — Stage 3 v0.4.1 환경조건 확장 (2026-11-07)

이번 독립 반응모델은 [STAGE3_README.md](STAGE3_README.md)에서 시작합니다.
결과는 [KJWP_Stage3_Report_20261107.html](KJWP_Stage3_Report_20261107.html)입니다.
아래는 보존된 이전 단계 안내입니다.

---

# KJWP 시뮬레이터 — 확장 명세 3.1 · 코드 v0.3.0

## 2026-11-02 Stage 2 최종 구현본 — 검토·실험은 별도

**먼저 [Stage 2 전용 HTML](STAGE2_RESULTS.html)을 브라우저에서 연다.**
이 파일은 계산 그림을 내장한 독립 보고서로 외부 서버 없이 열 수 있다.
기존 `RESULTS.html`은 과거 Stage 1 보고서로 보존했다.

압력 제어 출구, 국소 입자 농도에 따른 점도·밀도, 황/CaCO₃ 입자 이동·부착·걸러짐·침강,
모든 출구를 합한 총고체량 종료를 새 엔진에 연결했다.
국소 출구는 불포화 전도도를 수두 구간에 대해 적분하는 등가 구형 저항 모형이다.
이 구형은 계산 결과의 분포를 구형으로 강제하지 않는다.
현재 범위는 희석 연속체 모형이며 실측 보정·OGS 교차검증·실험 검증은 별도이다.
탈질 반응은 꺼져 있고 제거량은 0이다. Stage 3 이후 구현을 시작하지 않았다.

- 상세 식·가정·한계: [STAGE2_METHODS_v0_3_0.md](docs/STAGE2_METHODS_v0_3_0.md)
- 관 기준안·후속 단계·미정 입력: [DESIGN_CONSTRAINTS_20261102.md](docs/DESIGN_CONSTRAINTS_20261102.md)
- 대표 입력: `configs/stage2_pressure_particles.json` (연구 확정값이 아닌 수치 예시)
- 계산 원본: `outputs/stage2_final/<case>/{input.json,summary.json,history.csv,fields.npz}`
- 실행한 구현 검사: `outputs/stage2_final/implementation_checks.json`
- 기존/신규 전체 회귀시험: `outputs/stage2_final_tests.txt`
- 초기 출구 근사의 격자 문제 진단: `outputs/stage2_diagnostics_cellK` (기각된 결과; 최종값 아님)

### 새 Stage 2 재현

Python 3.10 이상. 이 README가 있는 폴더에서 실행한다.

```bash
python -m pip install .
python -m unittest discover -s tests -v
python -m kjwp_stage1.stage2 configs/stage2_pressure_particles.json --out outputs/my_stage2
python scripts/run_stage2_final.py
python scripts/build_stage2_report.py
```

첫 번째 실행 명령은 대표 사례 한 개, `run_stage2_final.py`는 전체 구현 검사 사례를 계산한다.
계산 시간은 장비에 따라 다르다. `build_stage2_report.py`는 저장된 배열로 HTML을 다시 만든다.
한 사례만 다시 계산할 때는 `--cases base` 등으로 지정할 수 있으며, 나머지는 저장 입력이 현재 명세와 같아야 한다.
추가 장치 설계나 최적 배치 탐색 명령은 이번 범위에 없다.

**아래는 이전 버전 기록이다.** 당시의 미구현 표시는 과거 상태이며 현재 상태는 위 문서를 따른다.

---

2026-11-01 Stage 2 추가 작업 1: **변경 가능한 슬러리 설정과 동일 건조 고체량 공급 관리**를 독립 모듈로 추가했다. [이번 작업 기록](docs/STAGE2_CHECKPOINT_1.md)을 먼저 읽는다. 아직 공간 유동·입자 수송 솔버에 연결하지 않았다. 아래 v0.2.0 결과는 당시의 물·용존 추적자 계산으로 보존한다. 이번 전체 자동검사는 46개이며 outputs/stage2_checkpoint_1_tests.txt에 기록했다.

2026-11-01: 환경 요인·지구화학·신뢰도를 [3.1 명세](docs/SPEC_3_1.md)로 검토하고, **Stage 1 수치모델 작업을 정리한 뒤 Stage 2 주입수·용존 추적물질 계산을 구현·실행했다.** 기존 7단계는 [확정 로드맵](docs/ROADMAP.md)의 문구와 순서를 유지한다.

연구용 프로토타입이다. 실환경 정확도 100%, OGS 교차검증 완료, 황 탈질 반응 구현 완료를 주장하지 않는다. 모든 예시는 가상 조건이며 실측 데이터가 아니다. 3.1은 명세 식별자이고 소프트웨어 버전은 0.2.0이다.

## 먼저 볼 자료

- [3.1 심층 검토: 변수·식·구현 상태·지구화학·신뢰도](docs/SPEC_3_1.md)
- [이번 검증 결과와 단계별 판정](docs/VALIDATION_20261101.md)
- outputs/spec_3_1/stage1_transient/slices.png: Richards 흐름 아래 질산염 침투
- outputs/spec_3_1/stage2_injection/slices.png: 계산 함수율·질산염·추적자 단면
- outputs/spec_3_1/stage2_checks/checks.json: 위치·유량·무주입 비교
- outputs/spec_3_1/extended_verification/verification.json: 신규 수렴시험 전체 수치
- outputs/spec_3_1/legacy_verification/validation.json: 기존 ADE 7개 검증 재실행
- outputs/spec_3_1/unit_tests.txt: 자동검사 39개 기록

## 구현한 기능

| 항목 | 내용 |
|---|---|
| 기존 고정 흐름 | 일정 θ,q의 3D ADE, MUSCL/SSPRK2. 이전 계산 재현 유지 |
| 새 비정상 흐름 | 3D 혼합형 Richards, VG–Mualem, 공유면 유한체적, 후진 Euler·수정 Picard |
| 토양 | 스칼라·3D 물성, 층상/불균질 조건, 축방향 대각 이방성 K |
| 물 경계 | 밀폐·수두·외향 플럭스·하부 자유배수. 수두/플럭스 시간표 |
| 용질 | θC 보존. 기본 MUSCL-MC/SSPRK2 내부 시간분할; 비교용 implicit_upwind |
| 주입수 | 좌표·유량·시간·용존 농도·구형 공급영역. 실제 물 흐름 변화 |
| 결과 | 3D NPZ, 수두/함수율/농도, 수지 CSV, 깊이 BTC, 하부 플럭스, 입력·코드 SHA256 |

새 흐름은 시간 1차다. 용질의 고차화가 비정상 결합계 전체의 시간 2차를 뜻하지 않는다. 분산은 상수 대각 성분이다. 화학·고체입자·관 내부 수리·최종 UI는 미구현이다. 용존 추적자 분포는 황·CaCO3 입자 분포가 아니다.

## 실행

Python 3.10 이상이 필요하다. README가 있는 폴더에서 실행한다.

```bash
python -m pip install .
python -m unittest discover -s tests -v
python -m kjwp_stage1 validate --out outputs/spec_3_1/legacy_verification
python -m scripts.verify_extended
python -m kjwp_stage1.transient_cli configs/stage1_transient.json --out outputs/spec_3_1/stage1_transient
python -m kjwp_stage1.transient_cli configs/stage2_injection.json --out outputs/spec_3_1/stage2_injection
python -m scripts.stage2_sensitivity
```

기존 명령도 유지한다.

```bash
python -m kjwp_stage1 run configs/column_pulse.json --out outputs/column_pulse --plots --gif
python -m kjwp_stage1 plot outputs/column_pulse --gif
```

## 새 JSON 입력과 출력

두 예시는 configs에 있다. 알 수 없는 키는 거절한다. 농도는 kg/m3 water, NO3 질량 기준을 명시한다. 40 mg NO3/L = 0.04 kg NO3/m³ water. 주입량은 m³/s이며 1 mL=10⁻⁶ m³다.

h는 m, α는 m⁻¹, K는 m/s, D는 m²/s. cells_xyz는 xyz 순서, 전체 물성·초기장 배열은 [z,y,x] 순서다. ks_m_s는 스칼라, Kx/Ky/Kz 3개 값, [z,y,x] 배열, [3,z,y,x] 배열을 받는다. θr,θs,α,n도 공간 배열을 받는다. 보수곡선 이력과 l<0은 지원하지 않는다.

물 flux는 외향 법선 방향이 양수이므로 상부 강우 공급은 음수다. schedule은 [time_s,value] 쌍 목록이며 첫 시각은 0, 이후 오름차순이다. 펄스 시작·종료와 조건 변화 시각에서 계산을 끊는다. 담수·지표 유출의 자동 전환은 미구현이다.

새 백엔드의 용질 inflow_flux는 유입 시 지정 농도, 유출 시 내부 농도를 쓰는 가역 개방 경계이며 경계 분산 플럭스는 0이다. 기존 백엔드의 유입 방향 검사와 구분한다. outflow가 역류하면 오류로 중단한다. 새 백엔드의 주기 경계는 미지원이다.

radius_m=0이면 해당 셀에 주입하며 격자 변경 시 공급영역도 바뀐다. 유한 반경이면 구 안에 중심이 있는 셀들에 균등 공급한다. 구 전체가 영역 안에 있어야 한다. 실제 관 구멍/필터/입자 전달을 해상한 것은 아니다. 비교 실험에서는 물리적 반경과 격자 크기 의존성을 확인한다.

fields.npz가 원 계산값이다. history.csv는 모든 수리 시간단계의 누적 수지와 하부 플럭스를 기록한다. 하부 플럭스는 해당 단계에 사용한 평균값이며 초기 행은 0이다. resident_btc.csv는 저장 시각별 각 깊이의 수분량 가중 평균 농도다. run.json에 단위·질량 기준·입력·코드 해시·패키지 버전·최종 수지가 있다.

질량수지를 숨겨진 보정이나 음수 자르기로 맞추지 않는다. 수리 수렴 실패는 dt를 줄여 재시도하며 한계 아래면 실패한다. 이 동작이 실제 현상의 타당성을 보증하지는 않는다. 완전 포화·밀폐 계속 주입에는 필요한 탄성저류/압축 기능이 없다.

기존 RESULTS.html, outputs/verification, docs/METHODS.md, docs/CONFIGURATION.md 및 [기존 README](docs/LEGACY_README_v0_1.md)는 v0.1 고정 흐름 자료다. 이번 범위는 본 문서와 3.1 명세를 따른다. 과거 추가 열 세분화 수치는 이번 검증값으로 재사용하지 않았다.
