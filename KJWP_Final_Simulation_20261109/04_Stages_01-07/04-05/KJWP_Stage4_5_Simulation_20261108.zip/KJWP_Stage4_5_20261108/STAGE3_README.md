# Stage 3 현재 버전 · v0.4.1 환경조건 확장

용존산소, 미생물 활성·유도기, 물–반응재 접촉 구간을 설정할 수 있습니다.
현재 보고서는 `KJWP_Stage3_Report_20261107.html`, 기존 기준 보고서는 `KJWP_Stage3_Base_Report_20261107.html`입니다.

```bash
python -m pip install -r requirements-stage3.txt
python -m pytest -q tests
python run_environment_validation.py
python build_environment_report.py
python -m kjwp_stage1.geochemistry --config configs/environment/contact_3h.json --output environment_results/custom
```

새 입력과 한계는 `docs/STAGE3_ENVIRONMENT.md`를 따릅니다. 산소 억제계수 KI=1·4 mg/L는 민감도 가정입니다.
현재 토양의 산소 변화, 미생물 성장, 수송에 따른 체류시간 분포는 후속 계산·실험 보정 대상입니다.
일반 물질 수지는 질산염 반응과 방해석 용해에 대해 계산하며 산소·호기성 황 산화 수지는 미구현입니다.
`environment_periods`를 생략하면 기본 무산소·연속 접촉 조건을 사용합니다.

아래는 기존 배치 모델의 사용법과 근거입니다.

---

# KJWP Stage 3 — 지구화학 반응모델

2026-11-07 · v0.4.0 · 독립 배치 반응모델

먼저 `KJWP_Stage3_Report_20261107.html`을 열면 계산 결과, 그래프, 검증과 한계를 볼 수 있습니다.
`stage3_results/`에는 계산 원본 JSON과 CSV가 있습니다. 보고서에는 외부 리소스 없이 그림이 포함됩니다.

## 실행

Python 3.12에서 다음 명령을 실행합니다. 검증한 운영체제는 Linux x86_64입니다.
Windows 실행용 `RUN_STAGE3.bat`도 포함했습니다. Windows 자체 실행 검증은 하지 않았습니다.
PhreeqPython의 Windows 네이티브 엔진은 Visual C++ 런타임이 필요할 수 있습니다.

```bash
python -m venv .venv
# Linux/macOS
source .venv/bin/activate
# Windows에서는 .venv\Scripts\activate
python -m pip install -r requirements-stage3.txt
python -m pytest -q tests
python run_stage3_validation.py
python build_stage3_report.py
```

사용자 조건 하나만 계산하려면 `configs/stage3_batch.json`을 편집합니다.

```bash
python -m kjwp_stage1.geochemistry --config configs/stage3_batch.json --output stage3_results/custom
```

사용자 조건 결과는 `custom/time_series.csv`, `custom/result.json`에 저장됩니다.
보고서 생성기는 검증용 기본 시나리오를 읽습니다. 사용자 조건을 보고서에 자동 포함하는 최종 UI는 Stage 7 범위입니다.

## 이번에 구현한 범위

- 무산소·완전혼합·폐쇄계, 물 1 kg 기준의 독립 반응셀
- 원소 황 기반 질산염 환원, 황산염·산 생성의 화학양론
- 고정 활성 생물량에 대한 Monod 속도식과 명시적 pH 억제 가정
- PHREEQC 수용액 종분화, 전하수지에서 계산하는 pH와 알칼리도
- 입경·유효 표면적·잔존량·포화도에 따른 방해석 용해
- 무반응, 무황, 무생물량, 고체 소진, 해석해, 시간 간격, 독립 적분 검증
- N/S/Ca/C 및 알칼리도·전하수지 출력, 희석 제거량 0의 별도 기록

`nitrate_mg_per_kgw`는 NO3 이온 질량입니다. NO3-N이 아닙니다.
모든 저장량은 kg 물 기준이며, Monod의 Ks는 문헌대로 mg-N/L입니다.
PHREEQC가 계산한 용액 부피로 농도를 변환합니다. `NO3_mg_L_solution`도 별도로 출력합니다.
`kinetic_volume_L_per_kgw=null`이 기본입니다. 1.0으로 고정하는 선택은 해석해 검증용입니다.

## 해석에 필요한 제한

이 모듈의 시험 통과는 수치 구현 검증입니다. 우리 토양의 제거율·소요시간을 실험으로 검증한 상태가 아닙니다.
활성 생물량 100 mg-VSS/kg 물, 초기 DIC·이온 조성, pH 5.5–6.5 선형 억제함수, 순수 방해석·구형 입자 등은 예시 가정입니다.
문헌 k와 Ks는 황–석회석 생물막 반응기 값으로, 토양으로 옮겨 쓰는 데 추가 보정이 필요합니다.
생물량 성장·사멸, 유도기, DO 수송·소모, 질소 중간체(NO2/N2O), 기체교환, 광물 침전은 미구현입니다.
생성 N2는 반응식의 이론적 누적 생성량을 장부에 기록하며, 용존 농도나 기체압력을 예측하지 않습니다.
온도는 25°C 예시 조건에 제한합니다. 25°C가 인용한 생물반응 논문의 확인된 배양온도라는 뜻은 아닙니다.
물의 반응 소모는 고정 용매 근사로 생략합니다. 기본 예시에서 최대 약 3.9 mg/kg 물입니다.
DO가 있는 불포화 토양 전체를 이 반응조건으로 해석하면 안 됩니다.

## 기존 단계와 다음 단계

Stage 1·2의 기존 Python 파일은 바꾸지 않고 회귀시험을 실행했습니다.
`stage2_validated_engine/`에는 최신 Stage 2 보정 엔진의 코드와 방법·검증 요약을 그대로 보존했습니다.
Stage 2의 대용량 3D 원본 배열은 기존 패키지에 있습니다. `PROVENANCE_STAGE3.json`에서 원본을 확인할 수 있습니다.

다음은 **4. 질산염 수송·주입수·반응 결합**입니다.
반응 0에서 기존 수송과 일치, 물 부피·θC·고체량 단위 변환, 이동 및 잔류 고체의 반응 가용성,
희석과 실제 반응량의 분리, 전역 원소수지를 먼저 통과해야 합니다.
이번에는 Stage 4의 3D 결합이나 Stage 7 UI 완료를 주장하지 않습니다.

인용 논문과 각 사용 범위는 `docs/STAGE3_REFERENCES.md`, 수식·가정은 `docs/STAGE3_METHODS.md`에 있습니다.
