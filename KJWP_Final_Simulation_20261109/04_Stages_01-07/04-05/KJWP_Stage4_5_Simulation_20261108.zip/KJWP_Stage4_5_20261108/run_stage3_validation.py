"""Reproduce Stage 3 cases, sensitivity, and independent integration checks."""
from dataclasses import replace, asdict
from pathlib import Path
import json
import csv
import platform
import importlib.metadata
import numpy as np
from scipy.optimize import brentq
from kjwp_stage1.geochemistry import (
    BatchConfig, simulate, save_result, Speciation, MW_CALCITE, MW_NO3, MW_N,
)

OUT = Path('stage3_results')


def native_calcite_reference(c):
    s = Speciation()
    initial = s.calculate(c, 0, 0, c.calcium_mol_per_kgw, c.dic_mol_per_kgw)
    m = c.calcite_g_per_kgw / MW_CALCITE
    area = 6 * (MW_CALCITE / 1000) / (c.calcite_density_kg_m3 * c.calcite_diameter_m) * 1e4
    text = f'''USE solution 1
KINETICS 1
 Calcite
 -m {m:.17g}
 -m0 {m:.17g}
 -parms {area:.17g} 0.6666666666666666
 -tol 1e-13
 -cvode true
 -steps {c.duration_days * 86400:.17g} in {c.output_count-1} steps
INCREMENTAL_REACTIONS true
END
'''
    s.engine.ip.run_string(text)
    a = s.engine.ip.get_selected_output_array()
    initial_text=f'''# Use phreeqpython 1.6.2 bundled phreeqc.dat (hash in VALIDATION.json)
SELECTED_OUTPUT 1
 -reset false
 -high_precision true
 -time true
 -pH true
 -totals Ca C(4)
SOLUTION 1
 units mol/kgw
 -water 1
 temp {c.temperature_C}
 pH {c.initial_pH}
 Ca {c.calcium_mol_per_kgw}
 C(4) {c.dic_mol_per_kgw}
 Cl {c.chloride_mol_per_kgw}
 Na {initial['Na']:.17g}
END
'''
    (OUT/'native_calcite_kinetics.pqi').write_text(initial_text + text)
    assert len(a)-1 == c.output_count-1, 'Native output grid must exclude initial solution'
    rows=[initial] + [dict(zip(a[0],row)) for row in a[1:]]
    with (OUT/'native_calcite_reference.csv').open('w', newline='') as f:
        w=csv.DictWriter(f,fieldnames=['day']+list(initial));w.writeheader()
        for day,row in zip(np.linspace(0,c.duration_days,c.output_count),rows):
            w.writerow({'day':day,**row})
    return rows


def main():
    OUT.mkdir(exist_ok=True)
    base = BatchConfig()
    cases = {
        'no_reaction': replace(base,reactions_enabled=False),
        'sulfur_only': replace(base,calcite_g_per_kgw=0),
        'calcite_only': replace(base,sulfur_g_per_kgw=0),
        'mixed': base,
        'no_biomass': replace(base,biomass_mg_VSS_per_kgw=0),
        'rate_half': replace(base,k_per_day=base.k_per_day/2),
        'rate_double': replace(base,k_per_day=base.k_per_day*2),
        'fine_calcite': replace(base,calcite_diameter_m=0.0001),
        'coarse_calcite': replace(base,calcite_diameter_m=0.001),
        'biomass_10': replace(base,biomass_mg_VSS_per_kgw=10),
        'alkalinity_high': replace(base,dic_mol_per_kgw=0.002),
    }
    results={}
    (Path('configs')/'stage3_batch.json').write_text(json.dumps(asdict(base),indent=2))
    for name,c in cases.items():
        results[name]=simulate(c)
        save_result(results[name],OUT/name)
        end=results[name]['records'][-1]
        print(name, 'NO3',round(end['NO3_mg_kgw'],6),'pH',round(end['pH'],6),flush=True)
    summary=[]
    for name,result in results.items():
        end=result['records'][-1]
        t90=next((r['day'] for r in result['records'] if r['NO3_mg_kgw']<=4),None)
        summary.append({'case':name,'NO3_final_mg_kgw':end['NO3_mg_kgw'],
                        'decrease_percent':100*(1-end['NO3_mg_kgw']/40),
                        'pH_final':end['pH'],'pH_min':min(x['pH'] for x in result['records']),
                        'SO4_final_mg_kgw':end['SO4_mg_kgw'], 'Ca_final_mg_kgw':end['Ca_mg_kgw'],
                        't90_days_first_hourly_output':t90})
    fine=simulate(replace(base,max_step_days=0.0125,rtol=1e-10,atol_mol=1e-14))
    convergence=[]
    for h in [0.1,0.05,0.025]:
        r=results['mixed'] if h==0.05 else simulate(replace(base,max_step_days=h))
        convergence.append({'max_step_days':h,
            'max_NO3_difference_mg_kgw':max(abs(a['NO3_mg_kgw']-b['NO3_mg_kgw']) for a,b in zip(r['records'],fine['records'])),
            'max_pH_difference':max(abs(a['pH']-b['pH']) for a,b in zip(r['records'],fine['records']))})
    radau=simulate(replace(base,method='Radau',rtol=1e-9,atol_mol=1e-14))
    methods={'max_NO3_difference_mg_kgw':max(abs(a['NO3_mg_kgw']-b['NO3_mg_kgw']) for a,b in zip(radau['records'],fine['records'])),
             'max_pH_difference':max(abs(a['pH']-b['pH']) for a,b in zip(radau['records'],fine['records']))}
    cc=replace(base,nitrate_mg_per_kgw=0,sulfate_mol_per_kgw=0,sulfur_g_per_kgw=0,
               rtol=1e-10,atol_mol=1e-14)
    custom=simulate(cc); native=native_calcite_reference(cc)
    save_result(custom, OUT/'calcite_reference_custom')
    native_metrics={'max_pH_difference':max(abs(a['pH']-b['pH']) for a,b in zip(custom['records'],native)),
       'max_Ca_mol_kgw_difference':max(abs(a['Ca_mg_kgw']/40078-b['Ca']) for a,b in zip(custom['records'],native)),
       'scope':'Same PHREEQC thermodynamics, independent native CVODE kinetic integration; carbonate-only, not biological validation.'}
    ac=replace(base,calcite_g_per_kgw=0,pH_inhibition=False,duration_days=0.4,
               rtol=1e-10,atol_mol=1e-14,output_count=41,kinetic_volume_L_per_kgw=1.0)
    analytic=simulate(ac); c0=40*MW_N/MW_NO3
    errors=[]
    for row in analytic['records']:
        target=c0+ac.ks_mg_N_L*np.log(c0)-ac.k_per_day*ac.biomass_mg_VSS_per_kgw*row['day']
        exact=brentq(lambda n:n+ac.ks_mg_N_L*np.log(n)-target,1e-30,c0)
        errors.append(abs(row['NO3_N_mg_kgw']-exact))
    validation={'cases':summary,'time_step_convergence':convergence,'BDF_vs_Radau':methods,
        'native_PHREEQC_calcite':native_metrics,'monod_analytic_max_error_mgN_kgw':max(errors),
        'maximum_balance_residual':max(max(r['validation'].values()) for r in results.values()),
        'database_sha256':results['mixed']['database_sha256'],
        'environment':{'python':platform.python_version(),**{k:importlib.metadata.version(k) for k in ['numpy','scipy','phreeqpython','matplotlib','pytest']}},
        'acceptance':{'balance_absolute_mol_or_eq_kgw':1e-10,'monod_error_mgN_kgw':2e-7,
                      'convergence_NO3_mg_kgw':0.002,'convergence_pH':0.0001,
                      'native_Ca_mol_kgw':1e-8,'native_pH':0.0001}}
    checks = [validation['maximum_balance_residual']<1e-10,max(errors)<2e-7,
              all(x['max_NO3_difference_mg_kgw']<0.002 and x['max_pH_difference']<0.0001 for x in convergence),
              methods['max_NO3_difference_mg_kgw']<0.002, methods['max_pH_difference']<0.0001,
              native_metrics['max_Ca_mol_kgw_difference']<1e-8,native_metrics['max_pH_difference']<0.0001]
    validation['all_numerical_acceptance_checks_passed']=bool(all(checks))
    (OUT/'VALIDATION.json').write_text(json.dumps(validation,indent=2))
    with (OUT/'summary.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=summary[0]);w.writeheader();w.writerows(summary)
    print(json.dumps({k:v for k,v in validation.items() if k!='cases'},indent=2),flush=True)
    if not all(checks):
        raise RuntimeError('Numerical acceptance check failed; inspect VALIDATION.json')


if __name__=='__main__':
    main()
