"""Build a self-contained Korean report directly from computed Stage 3 arrays."""
from pathlib import Path
import json, io, base64, html, re
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'stage3_results'
LABELS={'no_reaction':'무반응','sulfur_only':'황만','calcite_only':'석회질만',
        'mixed':'황 + 석회질','no_biomass':'활성 생물량 0',
        'rate_half':'기준 k × 0.5','rate_double':'기준 k × 2',
        'fine_calcite':'석회질 입경 0.1 mm','coarse_calcite':'석회질 입경 1 mm',
        'biomass_10':'활성 생물량 10 mg/kgw','alkalinity_high':'초기 DIC 2 mmol/kgw'}
ENG={'no_reaction':'No reaction','sulfur_only':'Sulfur only','calcite_only':'Calcite only','mixed':'Sulfur + calcite'}
COLORS={'no_reaction':'#94a3b8','sulfur_only':'#e9a43b','calcite_only':'#7a6bca','mixed':'#009b8e'}


def main():
    v=json.loads((OUT/'VALIDATION.json').read_text())
    if not v['all_numerical_acceptance_checks_passed']:
        raise RuntimeError('Refusing a passed report with failed validation')
    data={x['case']:json.loads((OUT/x['case']/'result.json').read_text()) for x in v['cases']}
    plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,
                         'axes.labelcolor':'#334155','text.color':'#15283f','figure.facecolor':'white'})
    fig,axes=plt.subplots(2,3,figsize=(15,8.4),layout='constrained')
    panels=[('NO3_mg_kgw','Nitrate [mg NO3 / kg water]'),('pH','pH'),
            ('SO4_mg_kgw','Sulfate [mg SO4 / kg water]'),
            ('Ca_mg_kgw','Calcium [mg Ca / kg water]'),
            ('alk_meq_kgw','Alkalinity [meq / kg water]'),
            ('CaCO3_g_kgw','Calcite remaining [g / kg water]')]
    for ax,(key,title) in zip(axes.ravel(),panels):
        for name in ENG:
            rows=data[name]['records']
            ax.plot([r['day'] for r in rows],[r[key] for r in rows],label=ENG[name],
                    color=COLORS[name],lw=2.2,ls='--' if name=='no_reaction' else '-')
        ax.set(xlabel='Time [days]',ylabel=title,xlim=(0,7))
        ax.grid(alpha=.16)
        if key=='pH': ax.axhline(5.5,color='#dc4c4c',lw=1,ls=':',label='Assumed inhibition floor')
    axes[0,0].legend(frameon=False,fontsize=9)
    fig.suptitle('Stage 3 | Closed anoxic batch — illustrative parameters, not field calibration',fontsize=15)
    fig.savefig(OUT/'stage3_timeseries.png',dpi=160)
    fig.savefig(OUT/'stage3_timeseries.svg')
    plt.close(fig)
    fig,ax=plt.subplots(figsize=(10,4.6),layout='constrained')
    names=['fine_calcite','mixed','coarse_calcite','biomass_10']
    labs=['0.1 mm calcite','0.5 mm calcite (base)','1.0 mm calcite','10% active biomass']
    for name,label in zip(names,labs):
        rows=data[name]['records']
        ax.plot([x['day'] for x in rows],[x['NO3_mg_kgw'] for x in rows],lw=2.2,label=label)
    ax.axhline(4,color='#64748b',ls=':',lw=1,label='90% decrease')
    ax.set(xlabel='Time [days]',ylabel='Nitrate [mg NO3 / kg water]',xlim=(0,7),ylim=(0,42))
    ax.legend(frameon=False);ax.grid(alpha=.15)
    ax.set_title('Sensitivity under assumed kinetics — not a confidence interval')
    fig.savefig(OUT/'stage3_sensitivity.png',dpi=160)
    plt.close(fig)
    def embed(name):return 'data:image/png;base64,'+base64.b64encode((OUT/name).read_bytes()).decode()
    def concentration(x):return '&lt;10<sup>−6</sup>' if x<1e-6 else f'{x:.3f}'
    def table(items):
        body=''
        for r in items:
            t='미도달' if r['t90_days_first_hourly_output'] is None else f"{r['t90_days_first_hourly_output']:.2f}일"
            body+=f"<tr><th>{LABELS[r['case']]}</th><td>{concentration(r['NO3_final_mg_kgw'])}</td><td>{r['pH_min']:.2f} → {r['pH_final']:.2f}</td><td>{r['SO4_final_mg_kgw']:.2f}</td><td>{r['Ca_final_mg_kgw']:.2f}</td><td>{t}</td></tr>"
        return '<div class="scroll"><table><thead><tr><th>조건</th><th>최종 NO₃</th><th>최저 → 최종 pH</th><th>최종 SO₄</th><th>최종 Ca</th><th>90% 감소 첫 출력</th></tr></thead><tbody>'+body+'</tbody></table></div>'
    test_log=(OUT/'all_tests.txt').read_text()
    passed=re.search(r'(\d+) passed',test_log)
    count=passed.group(1) if passed else '시험 로그 확인 필요'
    checks=[('원소·알칼리도·전하수지 최대 절대잔차',f"{v['maximum_balance_residual']:.2e}",'mol 또는 eq / kgw'),
       ('Monod 해석해 최대 차이',f"{v['monod_analytic_max_error_mgN_kgw']:.2e}",'mg-N/kgw'),
       ('시간 간격 변경 시 NO₃ 최대 차이',f"{max(x['max_NO3_difference_mg_kgw'] for x in v['time_step_convergence']):.2e}",'mg-NO₃/kgw'),
       ('BDF ↔ Radau NO₃ 최대 차이',f"{v['BDF_vs_Radau']['max_NO3_difference_mg_kgw']:.2e}",'mg-NO₃/kgw'),
       ('PHREEQC 네이티브 방해석 적분과 pH 차이',f"{v['native_PHREEQC_calcite']['max_pH_difference']:.2e}",'pH'),
       ('PHREEQC 네이티브 방해석 적분과 Ca 차이',f"{v['native_PHREEQC_calcite']['max_Ca_mol_kgw_difference']:.2e}",'mol/kgw')]
    checkrows=''.join(f'<tr><th>{a}</th><td>{b}</td><td>{c}</td><td class="ok">통과</td></tr>' for a,b,c in checks)
    references=[
      ('Carboni et al. (2021)','Enrichment of Autotrophic Denitrifiers From Anaerobic Sludge Using Sulfurous Electron Donors','10.3389/fmicb.2021.678323','무성장 반응 화학양론'),
      ('Zeng & Zhang (2005)','Evaluation of kinetic parameters of a sulfur–limestone autotrophic denitrification biofilm process','10.1016/j.watres.2005.09.034','Ks=0.398 mg-N/L, k=0.15 d⁻¹의 문헌 기준값'),
      ('Liu & Koenig (2002)','Use of limestone for pH control in autotrophic denitrification: batch experiments','10.1016/S0032-9592(01)00302-8','낮은 pH 억제와 석회질 완충의 근거'),
      ('Plummer, Wigley & Parkhurst (1978)','The kinetics of calcite dissolution in CO₂-water systems at 5° to 60°C and 0.0 to 1.0 atm CO₂','10.2475/ajs.278.2.179','PHREEQC 수정 PWP 방해석 용해식')]
    reflist=''.join(f'<li><b>{a}</b> · {b}<br><a href="https://doi.org/{d}">{d}</a> · 적용 범위 {scope}</li>' for a,b,d,scope in references)
    reflist+='<li><b>Parkhurst & Appelo (2013)</b> · Description of Input and Examples for PHREEQC Version 3 · USGS 6–A43.<br><a href="https://pubs.usgs.gov/tm/06/a43/">공식 문서</a> · 수용액 종분화, 전하수지 pH, 기준 적분.</li>'
    c=data['mixed']['config']
    report=f'''<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>KJWP Stage 3 · 지구화학 반응모델</title>
<style>*{{box-sizing:border-box}}body{{margin:0;background:#f2f5f8;color:#182b42;font-family:system-ui,-apple-system,"Noto Sans KR",sans-serif;line-height:1.75}}main{{max-width:1180px;margin:auto;padding:28px 24px 64px}}header{{background:#102d45;color:white;padding:44px;border-radius:20px}}.eyebrow{{font-size:13px;letter-spacing:.12em;color:#7fe0d4}}h1{{font-size:clamp(28px,5vw,43px);margin:8px 0}}header p{{color:#c9dce8;max-width:900px}}section{{background:white;margin-top:22px;padding:30px;border-radius:16px}}h2{{margin:0 0 18px;font-size:24px}}h3{{font-size:18px;margin:24px 0 8px}}p{{margin:10px 0}}.badges{{display:flex;gap:12px;flex-wrap:wrap}}.badge{{border:1px solid #456477;border-radius:24px;padding:5px 16px;font-size:14px}}.note{{background:#fff6df;border-left:4px solid #d7a031;padding:15px 20px;border-radius:8px}}.good{{background:#e6f6f3;border-left:4px solid #009b8e;padding:15px 20px;border-radius:8px}}.scroll{{overflow:auto}}table{{border-collapse:collapse;width:100%;font-size:14px;margin:15px 0}}td,th{{padding:12px 14px;border-bottom:1px solid #e3eaf0;text-align:left;white-space:nowrap}}thead{{background:#edf3f7}}tbody th{{font-weight:550}}.ok{{color:#008070;font-weight:bold}}img{{width:100%;height:auto;display:block}}.small{{font-size:13px;color:#5b6d80}}.formula{{background:#102d45;color:#c4f2ed;padding:20px 24px;border-radius:10px;font-size:19px;overflow:auto}}a{{color:#087c87;overflow-wrap:anywhere}}li{{margin-bottom:12px}}pre{{background:#eef3f6;padding:18px;overflow:auto;border-radius:10px}}.grid{{display:grid;grid-template-columns:1fr 1fr;gap:20px}}footer{{color:#52677b;margin:26px 6px}}@media(max-width:700px){{main{{padding:14px 10px 40px}}section,header{{padding:24px 18px}}.grid{{grid-template-columns:1fr}}h2{{font-size:21px}}}}@media print{{body{{background:white}}section,header{{break-inside:avoid}}main{{max-width:none}}}}</style></head><body><main>
<header><div class="eyebrow">KJWP 2026 · COMPUTATIONAL RESEARCH · 2026.11.07</div><h1>Stage 3 · 지구화학 반응모델</h1><p>황 기반 탈질과 석회질 완충을 독립 반응셀로 구현했다. 질산염의 감소뿐 아니라 황산염·칼슘·산 생성과 반응재 소모를 함께 계산한다.</p><div class="badges"><span class="badge">수치 기준 통과</span><span class="badge">자동시험 {count}개 통과</span><span class="badge">PHREEQC 실제 실행</span><span class="badge">실험 보정 전</span></div></header>
<section><h2>지금 무엇까지 되었나</h2><div class="good"><b>Stage 3의 독립 반응모듈과 수치검증을 구현했다.</b> 이전 단계의 57개 시험을 유지했고, 무반응·대조군·소진·해석해·수지·적분 비교를 추가했다. 3D 수송과 연결하는 작업은 Stage 4에 남아 있다.</div><p>이번 예시는 물 1 kg의 무산소·완전혼합 폐쇄계다. 초기 질산염은 <b>40 mg-NO₃/kg 물</b>이며 NO₃-N 기준 약 9.04 mg-N/kg 물이다. 황 0.300 g, 방해석 {c['calcite_g_per_kgw']:.5f} g을 사용해 진고체 체적비 3:1을 유지했다.</p><div class="note"><b>표의 감소율·시간은 예시 가정에 따른 계산 결과다.</b> 활성 생물량 100 mg-VSS/kg 물, pH 억제함수, 초기 수질과 유효 표면적을 우리 토양에서 보정하지 않았다. 현장 제거율이나 실험 결과로 인용하면 안 된다.</div></section>
<section><h2>네 조건의 7일 결과</h2>{table(v['cases'][:4])}<p class="small">NO₃·SO₄·Ca 단위는 모두 mg/kg 물이다. 실제 mg/L는 PHREEQC 용액 부피로 별도 환산해 CSV에 기록했다. 90% 감소 시간은 1시간 간격 출력에서 처음 관찰된 시점이며 정밀 사건시각이 아니다. &lt;10⁻⁶은 소진 허용치 이하를 뜻하며 완전한 0을 주장하지 않는다.</p><p><b>황만</b> 넣은 조건은 초기 완충능을 소모하면서 pH 5.5 부근에서 반응이 정지했다. <b>석회질만</b> 넣으면 질산염은 감소하지 않았다. <b>혼합</b> 조건은 석회질이 산을 완충해 반응이 이어졌지만, 초기에 pH가 약 5.78까지 낮아졌다가 회복됐다.</p><p>혼합 조건의 황산염은 약 9.61 → 61.25 mg/kg 물, 칼슘은 약 8.02 → 25.75 mg/kg 물로 증가했다. 질산염만 감소한다고 2차 수질 영향을 무시할 수는 없다.</p></section>
<section><h2>계산된 시간 변화</h2><img src="{embed('stage3_timeseries.png')}" alt="네 반응 조건의 질산염 pH 황산염 칼슘 알칼리도 방해석 시간 변화"><p class="small">모든 곡선은 저장된 계산 배열에서 생성했다. pH 5.5 정지는 선택한 억제함수의 결과이며, 실제 생물학적 임계값을 이 계산이 입증하는 것은 아니다. 무반응과 석회질만 조건의 질산염 곡선은 겹친다.</p></section>
<section><h2>입경과 활성 생물량에 얼마나 민감한가</h2><img src="{embed('stage3_sensitivity.png')}" alt="입경과 활성 생물량에 따른 질산염 감소 시간 민감도">{table([r for r in v['cases'] if r['case'] in ['fine_calcite','mixed','coarse_calcite','biomass_10']])}<p>같은 방해석 양에서도 입경 0.1·0.5·1 mm의 90% 감소 시점은 약 0.71·1.71·2.83일이었다. 활성 생물량을 10분의 1로 두면 약 6.04일이었다. <b>수치오차보다 미측정 생물량·반응 표면적의 불확실성이 훨씬 크다.</b></p><p class="small">선택한 네 조건의 민감도이며 확률적 신뢰구간이나 최적 입경의 증거가 아니다. 입경 변경이 주입 가능성·입자 이동·막힘에 미치는 영향은 이 배치 모델에서 계산하지 않았다.</p></section>
<section><h2>반응과 화학 계산의 구조</h2><div class="formula">5S⁰ + 6NO₃⁻ + 2H₂O → 3N₂ + 5SO₄²⁻ + 4H⁺</div><div class="grid"><div><h3>미생물 반응</h3><p>문헌 Monod 기준값 k=0.15 d⁻¹, Kₛ=0.398 mg-N/L와 고정 활성 생물량을 사용한다. 황의 표면적을 중복 곱하지 않는다. pH는 상태에 따라 계산하며, 낮은 pH에서 반응을 억제한다.</p></div><div><h3>석회질과 수용액</h3><p>PHREEQC가 이온 종분화·활동도·전하수지·pH를 계산한다. 방해석 용해는 수정 PWP 식으로 계산하며 입경, 남은 양과 포화도에 따른다. 과포화 상태의 침전은 제외했다.</p></div></div><p>질산염·황산염을 순간 산화환원 평형으로 섞지 않는다. 질소는 질산염과 이론적 N₂ 생성량의 합으로 보존한다. N₂는 누적 생성 장부이며 기체압력이나 용존 N₂ 농도 계산은 아니다.</p></section>
<section><h2>검증 결과와 그 의미</h2><div class="scroll"><table><thead><tr><th>검증 항목</th><th>실제 최대 차이</th><th>단위</th><th>상태</th></tr></thead><tbody>{checkrows}</tbody></table></div><p>무반응 보존, 무황·무생물량 대조, 황/방해석 소진, 비음수 저장량과 단위 입력 검사를 포함한 자동시험 <b>{count}개</b>가 통과했다. 시간 간격 상한 0.1·0.05·0.025일을 비교했고, 더 엄격한 기준해와 차이가 작았다.</p><div class="note">PHREEQC 비교는 <b>탄산계 방해석 용해의 독립 적분</b>이다. 동일 열역학 데이터베이스를 공유한다. 황 탈질 생물반응 전체를 독립 소프트웨어나 실험으로 검증했다는 뜻이 아니다.</div></section>
<section><h2>근거가 있는 값과 아직 가정인 값</h2><div class="scroll"><table><thead><tr><th>항목</th><th>현재 값·처리</th><th>근거 수준</th></tr></thead><tbody><tr><th>반응 화학양론</th><td>무성장 황–질산염 반응</td><td>R1 식 (3), 원소·전하수지 확인</td></tr><tr><th>Monod k·Kₛ</th><td>0.15 d⁻¹ · 0.398 mg-N/L</td><td>R2 생물막 반응기 기준값, 토양 미보정</td></tr><tr><th>활성 생물량</th><td>100 mg-VSS/kgw, 시간 고정</td><td>예시 가정</td></tr><tr><th>pH 억제</th><td>5.5–6.5 선형 증가</td><td>낮은 pH 억제는 R3, 함수 형태는 가정</td></tr><tr><th>방해석</th><td>순수 구형 0.5 mm · 면적 계수 1</td><td>속도식 R4/R5, 입자 조건은 가정</td></tr><tr><th>온도·수질</th><td>25°C, 초기 pH 7.2, DIC 0.15 mmol/kgw</td><td>예시 입력, 토양 실측값 아님</td></tr><tr><th>성장·DO·중간체</th><td>미구현</td><td>동적 생물량, NO₂/N₂O, DO 경쟁, 기체교환 후속 검토</td></tr></tbody></table></div><p>생물량 합성을 생략한 반응식은 성장 포함 문헌식과 알칼리도·황 소비량이 다르다. 서로 다른 화학양론의 수치를 혼합하지 않았다. 현재 모듈은 무산소 반응 구간을 전제로 한다.</p></section>
<section><h2>다음 단계 · 4. 질산염 수송·주입수·반응 결합</h2><ol><li><b>단위와 저장량 연결</b> — θC, 물 질량, 이동·부착·걸러짐 고체량을 반응셀의 mol/kgw로 변환한다. 추적자 농도를 반응재량으로 대체하지 않는다.</li><li><b>반응 0 회귀검증</b> — 반응을 끄면 기존 Stage 1·2의 수송 결과와 같아야 한다.</li><li><b>희석과 실제 반응량 분리</b> — 농도 감소, 유출, 잔존 질산염, 반응 생성물을 전역 수지로 따로 기록한다.</li><li><b>결합 시간 간격 검증</b> — 수송·반응 분할 오차와 소진·낮은 수분량의 경계 사례를 검사한다.</li></ol><p>실험 보정에는 NO₃와 함께 pH·알칼리도·SO₄·Ca 및 활성 생물량/유도기의 정보가 필요하다. 최종 배치 성능 비교 전에 이 불확실성을 줄여야 한다.</p></section>
<section><h2>인용 문헌 · 적용 범위 공개</h2><ol>{reflist}</ol><p>소프트웨어는 <a href="https://github.com/Vitens/phreeqpython">Vitens PhreeqPython 1.6.2</a>이며 배포 데이터베이스 phreeqc.dat를 실제 사용했다. 상세 출처·확인 범위는 패키지의 <code>docs/STAGE3_REFERENCES.md</code>에 있다. 공개 초록으로 확인한 계수를 논문의 전체 실험 재현으로 표현하지 않았다.</p></section>
<section><h2>파일과 재현</h2><p><code>STAGE3_README.md</code>에서 실행 방법을 확인한다. 기본 시나리오 11개, 원본 CSV/JSON, 수치검증 결과, Python 코드와 이전 단계 회귀시험을 포함했다.</p><pre>python -m pip install -r requirements-stage3.txt
python -m pytest -q tests
python run_stage3_validation.py
python build_stage3_report.py</pre><p class="small">검증 환경 Python {v['environment']['python']} · NumPy {v['environment']['numpy']} · SciPy {v['environment']['scipy']} · Linux x86_64. Windows 실행 스크립트는 포함했으나 Windows에서 실행 검증하지 않았다.<br>실제 사용한 데이터베이스 SHA-256<br><code>{v['database_sha256']}</code></p></section><footer>KJWP · Stage 3 독립 반응모듈 · 계산 구현 및 수치검증 보고서 · 실험 검증 전 · 최종 3D UI는 Stage 7</footer></main></body></html>'''
    (ROOT/'KJWP_Stage3_Base_Report_20261107.html').write_text(report,encoding='utf-8')
    print('Report written with',count,'passing tests')


if __name__=='__main__':main()
