"""Regression coverage for Stage 5 geometry and the common-dose contract."""
import copy
import json
from pathlib import Path

import numpy as np
import pytest

from kjwp_stage1.layout import compile_layout
from run_layout_batch import run_batch, summarize_run

CONFIGS = Path(__file__).resolve().parents[1]/'configs'/'stage5'


def read_config(name):
    return json.loads((CONFIGS/f'{name}.json').read_text())


def tilted_multi_pipe():
    return dict(schema_version=1, id='two_pipes', pipes=[
        dict(id='P1', body_top_m=[.03, .055, -.03], body_length_m=.18,
             outer_diameter_m=.073, inner_diameter_m=.060,
             tilt_from_vertical_deg=30, roll_deg=90, paired_port_offsets_m=[.12],
             control=dict(outlet_gauge_pressure_Pa=5000, equivalent_radius_m=.001, start_s=7),
             port_controls={'P1:1:A': dict(start_s=8, end_s=30)}),
        dict(id='P2', body_top_m=[.175, .145, .02], body_length_m=.18,
             outer_diameter_m=.073, inner_diameter_m=.060,
             roll_deg=90, paired_port_offsets_m=[.10],
             disabled_port_ids=['P2:1:B'],
             control=dict(outlet_gauge_pressure_Pa=5000, equivalent_radius_m=.001, start_s=7)),
    ])


def test_stage5_geometry_and_schedule():
    base = read_config('batch_test_base')
    layout = tilted_multi_pipe()
    compiled = compile_layout(base, layout)
    assert compiled['layout_metadata']['port_ids'] == ['P1:1:A', 'P1:1:B', 'P2:1:A']
    z = -.03 + .06*np.sqrt(3)
    np.testing.assert_allclose([p['position_m'] for p in compiled['ports']],
                               [[.09, .0915, z], [.09, .0185, z], [.175, .1815, .12]])
    assert compiled['ports'][0]['end_s'] == 30
    assert compiled['ports'][1]['start_s'] == 7
    layout['pipes'][0]['port_controls']['P1:1:A']['start_s'] = base['end_s']
    layout['pipes'][0]['port_controls']['P1:1:A']['end_s'] = None
    with pytest.raises(ValueError, match='start_s must precede'):
        compile_layout(base, layout)


def test_stage5_batch_with_control_and_incomplete_dose(tmp_path):
    base = read_config('batch_test_base')
    one = read_config('batch_test_layout')
    # A second distinct outlet in the same cell tests warnings and accounting.
    extra = copy.deepcopy(one['direct_ports'][0])
    extra.update(id='T2', position_m=[.08, .075, .225])
    one['direct_ports'].append(extra)
    control = dict(schema_version=1, id='baseline', kind='no_injection')
    layouts = {'one': one, 'two': tilted_multi_pipe(), 'baseline': control}

    def save(name, data):
        (tmp_path/f'{name}.json').write_text(json.dumps(data))

    save('base', base)
    save('batch', dict(schema_version=1, base='base.json',
                       jobs=[dict(id=key, layout=f'{key}.json') for key in layouts]))
    for name, layout in layouts.items():
        save(name, layout)
    manifest = tmp_path/'batch.json'
    out = tmp_path/'finished'
    rows = run_batch(manifest, out)
    report = json.loads((out/'batch_summary.json').read_text())
    assert report['all_requested_jobs_finished'] and report['comparison_ready']
    assert rows[0]['shared_cells'] == [{'cell_zyx': [4, 1, 1], 'port_ids': ['T1', 'T2']}]
    assert rows[0]['planned_dose'] == rows[1]['planned_dose']
    assert sum(amount > 0 for amount in rows[1]['port_carrier_water_m3'].values()) >= 2
    assert rows[2]['actual_dry_solid_kg'] == rows[2]['actual_carrier_water_m3'] == 0
    assert rows[2]['injection_completion_s'] is None
    assert rows[2]['NO3_reacted_kg'] == 0
    assert 0 < rows[2]['NO3_bottom_out_kg'] <= rows[2]['NO3_out_kg']
    assert all(abs(row['NO3_balance_residual_kg']) < 1e-15 for row in rows)

    for port in one['direct_ports']:
        port['control']['outlet_gauge_pressure_Pa'] = -1e6
    save('one', one)
    out = tmp_path/'shortfall'
    rows = run_batch(manifest, out)
    report = json.loads((out/'batch_summary.json').read_text())
    assert report['all_requested_jobs_finished'] and not report['comparison_ready']
    assert not rows[0]['dose_completed']
    assert not rows[0]['actual_dose_matches_plan']


def test_stage5_summary_checks_measured_water_and_zero_nitrate():
    meta = dict(planned_dose={'dry_solid_kg': 1, 'carrier_water_m3': 2}, port_ids=['P'])
    summary = dict(
        final={key: 0. for key in ('NO3_in_kg', 'NO3_reacted_kg', 'NO3_out_kg',
                                    'NO3_bottom_out_kg', 'NO3_stored_kg', 'NO3_residual_kg')},
        initial={'NO3_stored_kg': 0.}, port_water_m3=[1.],
        dose=dict(done=True, injected_dry_solid_kg=1), injection_completion_s=1.,
    )
    row = summarize_run(summary, meta)
    assert row['dose_completed'] and not row['actual_dose_matches_plan']
    assert row['NO3_reacted_fraction'] is None
