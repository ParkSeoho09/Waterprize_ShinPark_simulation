import unittest
import numpy as np
from kjwp_stage1.core.grid import Grid
from kjwp_stage1.flow.hydraulics import VanGenuchten
from kjwp_stage1.flow.richards import RichardsFlow,WaterBoundary,WaterStep,divergence,FlowConvergenceError
from kjwp_stage1.physics.boundary import FACES,Boundary
from kjwp_stage1.physics.injection import Injection,sources
from kjwp_stage1.numerics.transient import solve_transient


class LinearSoil:
    """Manufactured constitutive law, for numerical verification ONLY."""
    ks_m_s=1e-5
    def theta(self,h): return .4+.05*h
    def capacity(self,h): return np.full_like(h,.05)
    def relative_k(self,h): return np.ones_like(h)


def small_flow():
    grid=Grid((.2,.2,.4),(4,4,8))
    soil=VanGenuchten(.08,.43,3.6,1.56,1e-5)
    b={f:WaterBoundary() for f in FACES}
    return grid,soil,b


class TransientTests(unittest.TestCase):
    def test_retention_derivative_and_monotonicity(self):
        s=VanGenuchten(.08,.43,3.6,1.56,1e-5);h=-np.geomspace(.01,10,80)
        eps=1e-6
        np.testing.assert_allclose(s.capacity(h),(s.theta(h+eps)-s.theta(h-eps))/(2*eps),rtol=1e-6)
        self.assertTrue(np.all(np.diff(s.theta(h))<0))
        self.assertTrue(np.all(np.diff(s.relative_k(h))<0))
        self.assertAlmostEqual(float(s.theta(np.array(0.))),.43)

    def test_invalid_soil(self):
        for args in ((.4,.3,1.,2.,1e-5),(.1,.4,1.,1.,1e-5),(.1,.4,1.,2.,-1.)):
            with self.assertRaises(ValueError): VanGenuchten(*args)

    def test_hydrostatic_no_spurious_flow(self):
        g,s,b=small_flow();z,y,x=g.mesh_zyx();h=z-1.
        b['z-']=WaterBoundary('head',-1.);b['z+']=WaterBoundary('head',g.lengths_m[2]-1.)
        flow=RichardsFlow(g,s,b);r=flow.step(h,0,100.)
        np.testing.assert_allclose(r.head,h,atol=1e-13)
        self.assertLess(max(np.abs(q).max() for q in r.fluxes),1e-18)

    def test_unit_gradient_and_anisotropic_conductivity(self):
        g,_,b=small_flow();s=VanGenuchten(.08,.43,3.6,1.56,(1e-6,2e-6,4e-6))
        b['z-']=WaterBoundary('head',-.5);b['z+']=WaterBoundary('head',-.5)
        f=RichardsFlow(g,s,b);h=np.full(g.shape,-.5);r=f.step(h,0,100.)
        np.testing.assert_allclose(r.head,h,atol=1e-13)
        np.testing.assert_allclose(r.fluxes[2],4e-6*s.relative_k(np.array(-.5)),rtol=1e-12)

    def test_true_3d_discrete_eigenmode(self):
        g=Grid((.3,.4,.5),(7,8,9));z,y,x=g.mesh_zyx()
        mode=np.prod([np.cos(np.pi*a/L) for a,L in zip((x,y,z),g.lengths_m)],axis=0)
        h=z-2.+.01*mode;f=RichardsFlow(g,LinearSoil(),{q:WaterBoundary() for q in FACES})
        dt=.4;lam=sum(4*np.sin(np.pi/(2*n))**2/dx**2 for n,dx in zip(g.cells_xyz,g.spacing_xyz))
        expected=z-2.+.01*mode/(1+dt*LinearSoil.ks_m_s*lam/.05)
        np.testing.assert_allclose(f.step(h,0,dt).head,expected,atol=2e-13)

    def test_layered_theta_and_ks_shared_faces(self):
        g,_,b=small_flow();ks=np.full(g.shape,1e-5);ks[g.shape[0]//2:]*=.1
        s=VanGenuchten(.08,np.linspace(.4,.45,g.shape[0])[:,None,None],3.6,1.56,ks)
        b['z-']=WaterBoundary('head',-.2);b['z+']=WaterBoundary('free_drainage')
        f=RichardsFlow(g,s,b);r=f.step(np.full(g.shape,-.5),0,10.)
        self.assertLess(r.cell_balance_max,1e-10)
        self.assertLess(abs(r.net_balance_m3),1e-11)

    def test_clean_water_dilution_not_destruction(self):
        g,s,b=small_flow();z,_,_=g.mesh_zyx();f=RichardsFlow(g,s,b)
        inj=Injection((.1,.1,.2),1e-8,0,30.,{})
        r=solve_transient(f,z-1.,{'NO3':np.full(g.shape,.04)},end_s=60.,max_dt_s=10.,
                          save_times_s=[30.,60.],injections=[inj])
        initial=r.history[0]['NO3']['stored_kg'];end=r.history[-1]['NO3']
        self.assertAlmostEqual(end['stored_kg'],initial,places=15)
        self.assertLess(end['min_kg_m3'],.04)
        self.assertAlmostEqual(r.history[-1]['water_in_m3'],3e-7,places=16)

    def test_injected_tracer_exact_pulse_budget(self):
        g,s,b=small_flow();z,_,_=g.mesh_zyx();f=RichardsFlow(g,s,b)
        inj=Injection((.1,.1,.2),1e-8,7.,23.,{'tracer':.04})
        r=solve_transient(f,z-1.,{'tracer':np.zeros(g.shape)},end_s=40.,max_dt_s=13.,
                          save_times_s=[40.],injections=[inj])
        end=r.history[-1]['tracer'];expected=1e-8*16*.04
        self.assertAlmostEqual(end['in_kg']/expected,1.,places=13)
        self.assertAlmostEqual(end['stored_kg']/expected,1.,places=12)
        self.assertGreater(np.max(np.abs(r.head_m[-1]-r.head_m[0])),0.)

    def test_uniform_concentration_preserved_under_transient_flow(self):
        g,s,b=small_flow();b['z-']=WaterBoundary('head',-.1);b['z+']=WaterBoundary('free_drainage')
        f=RichardsFlow(g,s,b,theta_tolerance=1e-12)
        cb={q:Boundary('closed' if v.kind=='closed' else 'inflow_flux',.04) for q,v in b.items()}
        r=solve_transient(f,np.full(g.shape,-.5),{'test':np.full(g.shape,.04)},end_s=60.,max_dt_s=10.,
                          save_times_s=[60.],solute_boundaries={'test':cb},dispersion_m2_s=(1e-8,)*3)
        np.testing.assert_allclose(r.concentration['test'],.04,atol=1e-11)

    def test_boundary_solute_event_alignment(self):
        g,s,b=small_flow();b['z-']=WaterBoundary('head',-.5);b['z+']=WaterBoundary('head',-.5)
        f=RichardsFlow(g,s,b)
        cb={q:Boundary('closed' if v.kind=='closed' else 'inflow_flux',0.) for q,v in b.items()}
        cb['z-']=Boundary('inflow_flux',.04,7.,23.)
        r=solve_transient(f,np.full(g.shape,-.5),{'test':np.zeros(g.shape)},end_s=40.,max_dt_s=13.,
                          save_times_s=[40.],solute_boundaries={'test':cb})
        q=1e-5*float(s.relative_k(np.array(-.5)))
        expected=q*g.lengths_m[0]*g.lengths_m[1]*16*.04
        self.assertAlmostEqual(r.history[-1]['test']['in_kg']/expected,1.,places=12)

    def test_unsupported_and_invalid_inputs_rejected(self):
        g,s,b=small_flow();b['x-']=WaterBoundary('free_drainage')
        with self.assertRaises(ValueError): RichardsFlow(g,s,b)
        with self.assertRaises(ValueError): Injection((.1,.1,.2),-1.,0,1.)
        with self.assertRaises(ValueError): Injection((.19,.1,.2),1.,0,1.,radius_m=.05).weights(g)
        with self.assertRaises(ValueError): Injection((1.,.1,.2),1.,0,1.).weights(g)

    def test_failed_nonlinear_step_does_not_fake_success(self):
        g,s,b=small_flow();b['z-']=WaterBoundary('head',-.01)
        f=RichardsFlow(g,s,b,max_iterations=1)
        with self.assertRaises(FlowConvergenceError): f.step(np.full(g.shape,-2.),0,1000.)

    def test_transient_muscl_3d_oblique_gaussian(self):
        from kjwp_stage1.numerics.transient_muscl import transport_muscl
        from kjwp_stage1.validation.analytical import gaussian_cell_average
        g=Grid((1.,1.,1.),(24,24,24));theta=np.full(g.shape,.3)
        u=(.04,-.03,.02);d=(.001,.0007,.0004);q=[];b={}
        for a,v in enumerate(u):
            shape=list(g.shape);shape[2-a]+=1;q.append(np.full(shape,.3*v))
            for side,sign in ((0,-1),(1,1)):
                b[FACES[2*a+side]]=Boundary('inflow_flux' if sign*v<0 else 'outflow',0.)
        w=WaterStep(np.zeros(g.shape),theta,theta,tuple(q),np.zeros(g.shape),0,0.,0.)
        args=((.43,.53,.46),(.055,.06,.05),u,d,.1)
        c=gaussian_cell_average(g,0.,*args);m0=c.sum()*.3*g.volume;net=0.
        for k in range(40):
            c,bt=transport_muscl(g,w,c,.01,d,b,(k+1)*.01,np.zeros(g.shape))
            net+=bt['in_kg']-bt['out_kg']
        exact=gaussian_cell_average(g,.4,*args)
        self.assertLess(np.abs(c-exact).sum()/exact.sum(),.05)
        self.assertLess(abs(c.sum()*.3*g.volume-m0-net)/m0,1e-12)

    def test_implicit_alternative_preserves_clean_water_source_budget(self):
        g,s,b=small_flow();z,_,_=g.mesh_zyx();f=RichardsFlow(g,s,b)
        inj=Injection((.1,.1,.2),1e-8,7.,23.,{'tracer':.04})
        r=solve_transient(f,z-1.,{'NO3':np.full(g.shape,.04),'tracer':np.zeros(g.shape)},
            end_s=40.,max_dt_s=13.,save_times_s=[40.],injections=[inj],transport_scheme='implicit_upwind')
        self.assertAlmostEqual(r.history[-1]['tracer']['stored_kg']/(1e-8*16*.04),1.,places=12)
        self.assertAlmostEqual(r.history[-1]['NO3']['stored_kg']/r.history[0]['NO3']['stored_kg'],1.,places=12)


if __name__=='__main__': unittest.main()
