import unittest
import math
from kjwp_stage1.physics.slurry import Slurry,DoseBudget


class SlurryTests(unittest.TestCase):
    def test_three_to_one_is_volume_not_mass_ratio(self):
        s=Slurry();c=s.component_kg_per_m3_slurry
        self.assertAlmostEqual((c['sulfur']/2070)/(c['caco3']/2700),3.)
        self.assertAlmostEqual(c['sulfur']*.001,.03105)
        self.assertAlmostEqual(c['caco3']*.001,.0135)
        self.assertAlmostEqual(s.density_kg_m3,1022.786)
        self.assertNotAlmostEqual(c['sulfur']/c['caco3'],3.)

    def test_changed_ratio_recomputes_mass_and_density(self):
        a=Slurry();b=Slurry(sulfur_volume_parts=1.)
        self.assertNotEqual(a.solid_kg_per_m3_slurry,b.solid_kg_per_m3_slurry)
        self.assertNotEqual(a.density_kg_m3,b.density_kg_m3)
        # Einstein model depends on total phi, not identity of these ideal spheres.
        self.assertEqual(a.viscosity_Pa_s,b.viscosity_Pa_s)

    def test_equal_solid_dose_different_concentrations(self):
        target=.005346
        a=Slurry();b=Slurry(solid_volume_fraction=.01)
        va=a.volume_for_solid_mass(target);vb=b.volume_for_solid_mass(target)
        self.assertAlmostEqual(vb/va,2.)
        for s,v in ((a,va),(b,vb)):
            self.assertAlmostEqual(v*s.solid_kg_per_m3_slurry,target)

    def test_piecewise_rate_exact_dose_end_event(self):
        b=DoseBudget(Slurry(),.005346);t=0.;steps=0
        # Finite-volume accepted flux analog: varying piecewise-constant rates.
        while not b.done:
            q=1e-7 if steps%2 else 3e-7
            dt=b.dt_for_constant_rate(q,17.)
            b.accept(q*dt);t+=dt;steps+=1
        self.assertAlmostEqual(b.injected_volume_m3,120e-6,places=16)
        self.assertAlmostEqual(b.summary()['injected_dry_solid_kg'],.005346,places=15)
        self.assertGreater(t,0)

    def test_same_mass_twice_rate_half_time(self):
        a=DoseBudget(Slurry(),.005346);b=DoseBudget(Slurry(),.005346)
        ta=a.dt_for_constant_rate(2e-7,10000);tb=b.dt_for_constant_rate(4e-7,10000)
        a.accept(ta*2e-7);b.accept(tb*4e-7)
        self.assertAlmostEqual(ta,600.)
        self.assertAlmostEqual(tb,300.)
        self.assertAlmostEqual(a.summary()['injected_dry_solid_kg'],b.summary()['injected_dry_solid_kg'])

    def test_overshoot_rejected_without_modifying_budget(self):
        b=DoseBudget(Slurry(),.005346)
        with self.assertRaises(ValueError): b.accept(121e-6)
        self.assertEqual(b.injected_volume_m3,0.)

    def test_invalid_and_dilute_scope(self):
        for args in ({'solid_volume_fraction':0},{'solid_volume_fraction':.1},
                     {'sulfur_volume_parts':-1},{'sulfur_diameter_m':math.nan},
                     {'viscosity_model':'measured_constant'}):
            with self.assertRaises(ValueError): Slurry(**args)
        s=Slurry(solid_volume_fraction=.1,viscosity_model='measured_constant',measured_viscosity_Pa_s=.005)
        self.assertEqual(s.viscosity_Pa_s,.005)
        with self.assertRaises(ValueError): DoseBudget(Slurry(),0.)


if __name__=='__main__': unittest.main()
