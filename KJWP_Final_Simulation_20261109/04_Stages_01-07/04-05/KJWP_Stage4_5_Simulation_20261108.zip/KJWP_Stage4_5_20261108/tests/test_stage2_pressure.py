import copy
import json
from pathlib import Path
import unittest
import tempfile
import numpy as np
from scipy.linalg import expm
from scipy.integrate import quad
from kjwp_stage1.core.grid import Grid
from kjwp_stage1.flow.hydraulics import VanGenuchten
from kjwp_stage1.flow.richards import RichardsFlow, WaterBoundary, WaterStep
from kjwp_stage1.flow.pressure import PressureFlow, PressurePort
from kjwp_stage1.physics.boundary import FACES, Boundary
from kjwp_stage1.physics.slurry import Slurry
from kjwp_stage1.physics.particles import (Retention, mixture_properties, settling_velocity,
                                         particle_fluxes, G)
from kjwp_stage1.numerics.transient_muscl import transport_muscl
from kjwp_stage1.stage2 import solve


class LinearSoil:
    ks_m_s=1e-5
    def theta(self,h): return .4+.05*h
    def capacity(self,h): return np.full_like(h,.05)
    def relative_k(self,h): return np.ones_like(h)


class PressureParticleTests(unittest.TestCase):
    def test_nonlinear_outlet_integrates_wet_to_dry_conductivity(self):
        g=Grid((.2,.2,.4),(4,4,8))
        soil=VanGenuchten(.08,.43,3.6,1.56,1e-5)
        f=PressureFlow(g,soil,{v:WaterBoundary() for v in FACES})
        idx=(4,1,1)
        for low,high in ((-.8,.5),(-.4,-.1),(.1,.8)):
            exact=quad(lambda v:float(soil.relative_k(np.array(v))),low,min(high,0.))[0] if low<0 else 0.
            exact+=max(high,0.)-max(low,0.)
            value=f._relative_k_integral(low,high,idx)
            self.assertLess(abs(value-exact)/exact,1e-5)
        self.assertEqual(f._relative_k_integral(.5,.1,idx),0.)

    def test_dilute_properties_at_zero_and_inlet(self):
        s=Slurry()
        p=mixture_properties(s,dict(sulfur=np.array([0.,31.05/.98]),caco3=np.array([0.,13.5/.98])))
        np.testing.assert_allclose(p['phi'],[0.,.02],atol=1e-16)
        np.testing.assert_allclose(p['density_kg_m3'],[s.carrier_density_kg_m3,s.density_kg_m3])
        np.testing.assert_allclose(p['viscosity_Pa_s'],[s.carrier_viscosity_Pa_s,s.viscosity_Pa_s])
        self.assertLess(p['carrier_mobility_ratio'][1],1.)
        with self.assertRaises(ValueError): mixture_properties(s,dict(sulfur=100.,caco3=100.))

    def test_new_flow_reduces_to_existing_water_solver(self):
        g=Grid((.2,.2,.4),(4,4,8)); z,y,x=g.mesh_zyx()
        b={f:WaterBoundary() for f in FACES}; b['z+']=WaterBoundary('free_drainage')
        b['z-']=WaterBoundary('flux',-1e-7)
        soil=VanGenuchten(.08,.43,3.6,1.56,1e-5)
        old=RichardsFlow(g,soil,b); new=PressureFlow(g,soil,b)
        h=z-.8+.01*np.sin(10*x)*np.cos(8*y)
        q0,L0=old.faces_and_matrix(h,0); q1,L1=new.faces_and_matrix(h,0)
        for a,c in zip(q0,q1): np.testing.assert_array_equal(a,c)
        np.testing.assert_array_equal(L0.toarray(),L1.toarray())
        w0=old.step(h,0,10); w1,_=new.step_pressure(h,0,10,[],Slurry())
        np.testing.assert_allclose(w0.head,w1.head,atol=1e-13)

    def test_pressure_outlet_linear_limit_and_check_valve(self):
        g=Grid((.2,.2,.4),(4,4,8)); h=np.full(g.shape,-.5); s=Slurry()
        f=PressureFlow(g,LinearSoil(),{v:WaterBoundary() for v in FACES})
        p=PressurePort((.075,.075,.225),1000.,.001)
        src,diag,r=f.port_sources(h,1,[p],s)
        re=(3*g.volume/(4*np.pi))**(1/3)
        conduct=4*np.pi*1e-5*.98/1.05/(1000-1/re)
        expected=conduct*(1000/(s.carrier_density_kg_m3*G)+.5)
        self.assertAlmostEqual(r[0]/expected,1.,places=12)
        p2=PressurePort(p.position_m,2000.,.001)
        r2=f.port_sources(h,1,[p2],s)[2][0]
        self.assertGreater(r2,r[0])
        closed=PressurePort(p.position_m,-1e6,.001)
        self.assertEqual(f.port_sources(h,1,[closed],s)[2][0],0.)
        self.assertAlmostEqual(src.sum()*g.volume,r[0],places=18)

    def test_pressure_source_in_implicit_storage_budget(self):
        g=Grid((.2,.2,.4),(4,4,8)); z,_,_=g.mesh_zyx(); h=z-.8
        f=PressureFlow(g,LinearSoil(),{v:WaterBoundary() for v in FACES},theta_tolerance=1e-13)
        s=Slurry(); p=PressurePort((.075,.075,.225),1000.,.001)
        w,r=f.step_pressure(h,0,3.,[p],s)
        self.assertLess(abs((w.theta-w.theta_old).sum()*g.volume-r.sum()*3),1e-15)
        self.assertGreater(np.max(np.abs(w.head-h)),0.)

    def test_variable_density_hydrostatic_face_balance(self):
        g=Grid((.2,.2,.4),(4,4,8)); z,_,_=g.mesh_zyx()
        f=PressureFlow(g,LinearSoil(),{v:WaterBoundary() for v in FACES})
        f.set_fluid(dict(carrier_mobility_ratio=.8,gravity_ratio=1.03))
        q,_=f.faces_and_matrix(1.03*z-1.,0)
        self.assertLess(max(np.abs(a).max() for a in q),1e-18)

    def test_retention_conservation_positivity_and_analytic_exchange(self):
        rate=Retention(.002,.0003,0.)
        m,a,s=rate.step(np.array([1.,2.]),np.array([.3,.2]),np.array([.5,0.]),100.)
        exact=expm(np.array([[-.002,.0003],[.002,-.0003]])*100.)
        np.testing.assert_allclose(np.array([m,a]),exact@np.array([[1.,2.],[.3,.2]]),rtol=1e-14)
        np.testing.assert_allclose(m+a+s,[1.8,2.2],rtol=1e-15)
        for v in (m,a,s): self.assertGreaterEqual(v.min(),0.)

    def test_retention_split_converges_to_full_matrix(self):
        r=Retention(.002,.0003,.001)
        matrix=np.array([[-.003,.0003,0.],[.002,-.0003,0.],[.001,0.,0.]])
        exact=expm(matrix*1000)@np.array([1.,0.,0.]); errors=[]
        for n in (10,20,40):
            v=(1.,0.,0.)
            for _ in range(n): v=r.step(*v,1000/n)
            errors.append(np.linalg.norm(np.array(v)-exact))
        self.assertTrue(errors[0]/errors[1]>3.9 and errors[1]/errors[2]>3.9)

    def test_settling_only_open_bottom_mass_balance(self):
        g=Grid((.2,.2,.4),(4,4,8)); th=np.full(g.shape,.3)
        fs=tuple(np.zeros(tuple(n+(i==2-a) for i,n in enumerate(g.shape))) for a in range(3))
        w=WaterStep(np.zeros(g.shape),th,th,fs,np.zeros(g.shape),0,0,0)
        s=Slurry(); props=mixture_properties(s,dict(sulfur=0.,caco3=0.))
        v=settling_velocity(s,'sulfur',props,1.)
        drift=particle_fluxes(w,v,True)
        self.assertGreater(drift[2][-1].min(),0)
        w=WaterStep(w.head,th,th,drift,w.source,0,0,0)
        b={f:Boundary('inflow_flux' if f=='z+' else 'closed') for f in FACES}
        c,bt=transport_muscl(g,w,np.ones(g.shape),20.,(0.,)*3,b,20.,np.zeros(g.shape))
        lost=float((th*(1-c)).sum()*g.volume)
        self.assertAlmostEqual(lost/bt['out_kg'],1.,places=12)
        self.assertLess(bt['cell_residual_max_kg'],1e-18)

    def test_coupled_event_dose_and_all_species_budgets(self):
        cfg=json.loads((Path(__file__).parents[1]/'configs/stage2_pressure_particles.json').read_text())
        cfg['grid']['cells_xyz']=[4,4,8]
        cfg['ports'][0].update(position_m=[.075,.075,.225],start_s=7.)
        cfg.update(end_s=80.,max_dt_s=13.,save_times_s=[0.,7.,80.],target_dry_solid_kg=1e-7)
        cfg['theta_tolerance']=1e-13
        with tempfile.TemporaryDirectory() as out:
            r=solve(cfg,out)
            stored=json.loads((Path(out)/'summary.json').read_text())
            self.assertTrue(stored['dose']['done'])
            self.assertIn('sulfur_attached_kg_m3_soil',np.load(Path(out)/'fields.npz'))
        final=r['summary']['final']; d=r['summary']['dose']
        self.assertTrue(d['done'])
        self.assertLess(abs(d['solid_dose_residual_kg'])/1e-7,1e-12)
        self.assertGreater(r['summary']['injection_completion_s'],7.)
        for s in ('NO3','tracer','sulfur','caco3'):
            scale=final[s+'_in_kg']+r['summary']['initial'][s+'_stored_kg']
            self.assertLess(abs(final[s+'_residual_kg'])/scale,1e-11)
        self.assertLess(abs(final['water_residual_m3'])/final['water_in_m3'],1e-7)
        self.assertEqual(r['summary']['denitrification_removed_kg'],0.)
        no3boundary=2e-9*.2*.2*80.
        self.assertAlmostEqual(final['NO3_boundary_in_kg']/no3boundary,1.,places=12)
        self.assertTrue(any(row['time_s']==7. for row in r['history']))
        self.assertGreater(final['sulfur_attached_kg']+final['sulfur_strained_kg'],0.)

    def test_unreached_dose_is_not_forced_and_invalid_geometry_fails(self):
        cfg=json.loads((Path(__file__).parents[1]/'configs/stage2_pressure_particles.json').read_text())
        cfg['ports'][0]['outlet_gauge_pressure_Pa']=-1e6
        cfg.update(end_s=1.,max_dt_s=1.,save_times_s=[0.,1.])
        r=solve(cfg)
        self.assertIsNone(r['summary']['injection_completion_s'])
        self.assertFalse(r['summary']['dose']['done'])
        self.assertEqual(r['summary']['dose']['injected_dry_solid_kg'],0.)
        with self.assertRaises(ValueError): PressurePort((.1,.1,.2),1000.,.001).cell(
            Grid((.2,.2,.4),(4,4,8)))


if __name__=='__main__': unittest.main()
