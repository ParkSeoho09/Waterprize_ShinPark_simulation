import json
from pathlib import Path
import numpy as np
import pytest
from kjwp_stage1.geochemistry import BatchConfig,simulate,MW_NO3,MW_S,MW_CALCITE,MW_SO4
from kjwp_stage1.reactive_transport import CellReaction,solve
from kjwp_stage1.stage2 import solve as stage2_solve
from kjwp_stage1.layout import compile_layout
from kjwp_stage1.reaction_environment import ExposureSchedule
ROOT=Path(__file__).parents[1]
def small():
    c=json.loads((ROOT/'configs/stage4/coupled_small.json').read_text());c.update(end_s=90.,max_dt_s=17.,save_times_s=[0,90],target_dry_solid_kg=1e-7)
    c['ports'][0]['start_s']=7.;c['theta_tolerance']=1e-13;return c

def test_reaction_off_matches_stage2_fields_and_ledgers():
    cfg=small();cfg['chemistry']['batch']['reactions_enabled']=False;a=stage2_solve(cfg);b=solve(cfg)
    for fa,fb in zip(a['fields'],b['fields']):
        for k in fa:np.testing.assert_array_equal(fa[k],fb[k])
    for ra,rb in zip(a['history'],b['history']):
        for k in ra:assert ra[k]==rb[k],k
    assert b['summary']['denitrification_removed_kg']==0

@pytest.mark.parametrize('area',['shrinking_sphere','fixed_specific_area'])
def test_closed_cell_reproduces_stage3(area):
    c=BatchConfig(duration_days=.5,output_count=7,calcite_area_model=area,rtol=1e-9,atol_mol=1e-14)
    ref=simulate(c)['records'][-1];cell=CellReaction(c);n=c.nitrate_mg_per_kgw/(MW_NO3*1000)
    sp=cell.speciation.calculate(c,n,c.sulfate_mol_per_kgw,c.calcium_mol_per_kgw,c.dic_mol_per_kgw)
    xi,eta=cell.advance((n,c.sulfate_mol_per_kgw,c.calcium_mol_per_kgw,c.dic_mol_per_kgw,sp['Na'],c.chloride_mol_per_kgw),c.sulfur_g_per_kgw/MW_S,c.calcite_g_per_kgw/MW_CALCITE,43200,ExposureSchedule([],12,None,0).state(0),100)
    assert abs((n-xi)*MW_NO3*1000-ref['NO3_mg_kgw'])<1e-7
    assert abs((c.calcite_g_per_kgw/MW_CALCITE-eta)*MW_CALCITE-ref['CaCO3_g_kgw'])<1e-9

def test_all_components_and_passive_shadow_balance():
    cfg=small();cfg.update(end_s=600.,max_dt_s=100.,save_times_s=[0,600]);cfg['initial_attached_kg_m3_soil']={'sulfur':.03,'caco3':.01}
    r=solve(cfg);a,b=r['history'][0],r['history'][-1]
    for s in ('NO3','tracer','sulfur','caco3','SO4','Ca','DIC','Na','Cl','NO3_passive'):
        scale=a[s+'_stored_kg']+b[s+'_in_kg']+abs(b[s+'_reaction_net_kg'])
        assert abs(b[s+'_residual_kg'])<max(1e-15,1e-10*scale),s
    reacted=b['NO3_reacted_kg'];assert reacted>0
    assert abs(b['NO3_passive_stored_kg']-b['NO3_stored_kg']+b['NO3_passive_out_kg']-b['NO3_out_kg']-reacted)<1e-14
    assert abs(b['SO4_reaction_net_kg']/reacted-5/6*MW_SO4/MW_NO3)<1e-12
    for f in r['fields']:
        for s in ('sulfur','caco3'):
            for key in (s+'_kg_m3_carrier',s+'_attached_kg_m3_soil',s+'_strained_kg_m3_soil'):assert np.min(f[key])>=0
    assert abs(b['age_moment_residual_kg_s'])<1e-12
    assert abs(b['exposure_moment_residual_kg_s'])<1e-12
    assert abs(sum(r['summary']['port_water_m3'])-b['slurry_in_m3']*.98)<1e-15

def test_contact_off_and_environment_event():
    cfg=small();cfg['chemistry']['batch']['environment_periods']=[{'start_hour':0,'in_contact':False},{'start_hour':.01,'in_contact':False}]
    cfg['initial_attached_kg_m3_soil']={'sulfur':.03,'caco3':.01};r=solve(cfg)
    assert r['summary']['denitrification_removed_kg']==0;assert any(abs(v['time_s']-36)<1e-10 for v in r['history'])
    assert r['summary']['final']['CaCO3_dissolved_kg']==0

def test_biomass_not_created_by_wetting():
    from kjwp_stage1.reactive_transport import ReactiveCoupling
    cfg=small();coupling=ReactiveCoupling(cfg);r=stage2_solve(cfg,coupling=coupling)
    a,b=r['fields'][0]['theta'],r['fields'][-1]['theta'];np.testing.assert_allclose(coupling.biomass_bulk,a*997*100)
    assert np.any(np.abs(coupling.biomass_bulk/(997*b)-100)>1e-6)

def test_layout_and_total_dose_invariant_under_rotation():
    base=json.loads((ROOT/'configs/stage5/base_sample.json').read_text());layout=json.loads((ROOT/'configs/stage5/layout_sample.json').read_text())
    a=compile_layout(base,layout);assert len(a['ports'])==6
    np.testing.assert_allclose([p['position_m'][2] for p in a['ports']],[.35,.35,.65,.65,.95,.95])
    layout['pipes'][0]['roll_deg']=27;b=compile_layout(base,layout)
    assert a['ports']!=b['ports'];assert a['layout_metadata']['planned_dose']==b['layout_metadata']['planned_dose']
    for i in (0,2,4):assert abs(np.linalg.norm(np.array(b['ports'][i]['position_m'])-b['ports'][i+1]['position_m'])-.073)<1e-14

def test_invalid_layout_rejected():
    base=json.loads((ROOT/'configs/stage5/base_sample.json').read_text());layout=json.loads((ROOT/'configs/stage5/layout_sample.json').read_text())
    layout['pipes'][0]['body_top_m'][2]=1
    with pytest.raises(ValueError):compile_layout(base,layout)
    layout['pipes'][0]['body_top_m'][2]=.05;layout['pipes'][0]['disabled_port_ids']=['wrong']
    with pytest.raises(ValueError):compile_layout(base,layout)

def test_inconsistent_properties_rejected():
    cfg=small();cfg['slurry']['temperature_C']=20
    with pytest.raises(ValueError,match='temperature'):solve(cfg)
    cfg=small();cfg['chemistry']['batch']['calcite_diameter_m']=.0005
    with pytest.raises(ValueError,match='diameter'):solve(cfg)
