"""Numerical, conservation, depletion and reference-integration checks."""
from dataclasses import replace
import numpy as np
import pytest
from scipy.optimize import brentq

from kjwp_stage1.geochemistry import (
    BatchConfig, Speciation, simulate, MW_N, MW_NO3, MW_S,
    MW_CALCITE, calcite_rate_mol_day,
)


@pytest.fixture(scope='module')
def mixed():
    return simulate(BatchConfig(output_count=85))


def test_no_reaction_keeps_all_inventories():
    r = simulate(BatchConfig(reactions_enabled=False, duration_days=1, output_count=7))
    for key in ('NO3_mg_kgw', 'SO4_mg_kgw', 'Ca_mg_kgw', 'DIC_mmol_kgw',
                'alk_meq_kgw', 'pH', 'S0_g_kgw', 'CaCO3_g_kgw'):
        assert np.ptp([x[key] for x in r['records']]) < 1e-12


def test_no_sulfur_cannot_reduce_nitrate():
    r = simulate(BatchConfig(sulfur_g_per_kgw=0, duration_days=1, output_count=5))
    assert r['records'][-1]['NO3_mg_kgw'] == 40
    assert r['records'][-1]['CaCO3_g_kgw'] < r['records'][0]['CaCO3_g_kgw']


def test_no_active_biomass_cannot_reduce_nitrate():
    r = simulate(BatchConfig(biomass_mg_VSS_per_kgw=0, duration_days=1, output_count=5))
    assert r['records'][-1]['NO3_mg_kgw'] == 40


def test_monod_matches_implicit_analytic_solution():
    c = BatchConfig(calcite_g_per_kgw=0, pH_inhibition=False, duration_days=0.4,
                    max_step_days=0.02, output_count=21, rtol=1e-10, atol_mol=1e-14,
                    kinetic_volume_L_per_kgw=1.0)
    result = simulate(c)
    c0 = c.nitrate_mg_per_kgw * MW_N / MW_NO3
    v = c.k_per_day * c.biomass_mg_VSS_per_kgw
    for row in result['records']:
        target = c0 + c.ks_mg_N_L * np.log(c0) - v * row['day']
        exact = brentq(lambda x: x + c.ks_mg_N_L * np.log(x) - target, 1e-30, c0)
        assert abs(row['NO3_N_mg_kgw'] - exact) < 2e-7


def test_element_charge_and_alkalinity_balances(mixed):
    assert max(mixed['validation'].values()) < 1e-10


def test_nonnegative_inventories(mixed):
    for row in mixed['records']:
        for key in ('NO3_mg_kgw','S0_g_kgw','CaCO3_g_kgw','SO4_mg_kgw','Ca_mg_kgw'):
            assert row[key] >= -1e-12
        assert row['dilution_removed_NO3_mg_kgw'] == 0


def test_sulfur_depletion_caps_removal():
    c = BatchConfig(sulfur_g_per_kgw=0.001, calcite_g_per_kgw=0,
                    pH_inhibition=False, duration_days=1, output_count=11)
    r = simulate(c)
    expected = c.sulfur_g_per_kgw / MW_S * 6 / 5 * MW_NO3 * 1000
    assert abs(r['records'][-1]['reacted_NO3_mg_kgw'] - expected) < 1e-7
    assert abs(r['records'][-1]['S0_g_kgw']) <= 2*c.depletion_tolerance_mol*MW_S


def test_calcite_depletion_caps_calcium():
    c = BatchConfig(sulfur_g_per_kgw=0, calcite_g_per_kgw=1e-5, calcite_diameter_m=1e-6,
                    duration_days=1, output_count=11)
    r = simulate(c)
    assert min(x['CaCO3_g_kgw'] for x in r['records']) >= -1e-12
    assert r['records'][-1]['CaCO3_g_kgw'] < 1e-8
    assert max(r['validation'].values()) < 1e-10


def test_low_pH_inhibits_biology():
    r = simulate(BatchConfig(initial_pH=5.0, calcite_g_per_kgw=0,
                              duration_days=1, output_count=5))
    assert r['records'][-1]['NO3_mg_kgw'] == 40


def test_sulfate_production_stoichiometry(mixed):
    a, b = mixed['records'][0], mixed['records'][-1]
    from kjwp_stage1.geochemistry import MW_SO4
    assert abs((b['SO4_mg_kgw']-a['SO4_mg_kgw']) / b['reacted_NO3_mg_kgw'] - 5/6*MW_SO4/MW_NO3) < 1e-10


def test_temperature_extrapolation_rejected():
    with pytest.raises(ValueError):
        BatchConfig(temperature_C=15).validate()


@pytest.mark.parametrize('field,value', [('nitrate_mg_per_kgw',-1),
    ('calcite_diameter_m',0), ('ks_mg_N_L',0), ('k_per_day',float('nan'))])
def test_invalid_inputs_rejected(field,value):
    with pytest.raises(ValueError):
        replace(BatchConfig(), **{field:value}).validate()


def test_calcite_saturation_stops_dissolution():
    assert calcite_rate_mol_day(BatchConfig(), 0.001, 0.001, {'si_calcite':0.1}) == 0


def test_density_and_nitrate_units_are_explicit(mixed):
    row = mixed['records'][0]
    assert abs(row['NO3_N_mg_kgw']/row['NO3_mg_kgw'] - MW_N/MW_NO3) < 1e-14
    assert abs(row['NO3_mg_L_solution'] * row['solution_volume_L_per_kgw'] - 40) < 1e-12


def test_tight_tolerance_near_nitrate_exhaustion():
    c=BatchConfig(rtol=1e-10,atol_mol=1e-14,output_count=9,max_step_days=0.0125)
    r=simulate(c)
    assert 0 < r['records'][-1]['NO3_mg_kgw'] < 1e-6
    assert max(r['validation'].values()) < 1e-10
    assert r['events']
