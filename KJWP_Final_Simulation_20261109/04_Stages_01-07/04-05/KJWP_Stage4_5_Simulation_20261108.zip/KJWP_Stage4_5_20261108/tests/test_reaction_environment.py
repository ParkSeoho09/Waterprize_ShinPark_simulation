from dataclasses import replace, asdict
from pathlib import Path
import json
import numpy as np
import pytest
from scipy.optimize import brentq

from kjwp_stage1.geochemistry import BatchConfig, simulate, MW_N, MW_NO3
from kjwp_stage1.reaction_environment import EnvironmentPeriod, ExposureSchedule


def test_legacy_configuration_reproduces_saved_baseline():
    path = Path(__file__).resolve().parents[1] / 'stage3_results/mixed/result.json'
    baseline = json.loads(path.read_text())
    result = simulate(BatchConfig(**baseline['config']))
    assert len(result['records']) == len(baseline['records'])
    for old, new in zip(baseline['records'], result['records']):
        for key, value in old.items():
            assert new[key] == pytest.approx(value, abs=1e-11, rel=1e-10)


def test_piecewise_exposure_matches_monod_analytic_solution():
    config = BatchConfig(
        duration_days=1, output_count=25, calcite_g_per_kgw=0,
        pH_inhibition=False, kinetic_volume_L_per_kgw=1,
        oxygen_half_inhibition_mg_L=1, microbial_lag_hours=3,
        rtol=1e-10, atol_mol=1e-14,
        environment_periods=(
            EnvironmentPeriod(dissolved_oxygen_mg_L=1),
            EnvironmentPeriod(start_hour=6, active_fraction=0.25),
            EnvironmentPeriod(start_hour=9, in_contact=False),
        ),
    )
    result = simulate(config)
    initial_n = config.nitrate_mg_per_kgw * MW_N / MW_NO3
    for row in result['records']:
        exposure_days = row['activity_oxygen_weighted_contact_hours'] / 24
        target = initial_n + config.ks_mg_N_L * np.log(initial_n)
        target -= config.k_per_day * config.biomass_mg_VSS_per_kgw * exposure_days
        exact = brentq(lambda n: n + config.ks_mg_N_L * np.log(n) - target,
                       1e-30, initial_n)
        assert row['NO3_N_mg_kgw'] == pytest.approx(exact, abs=2e-7)
    assert result['records'][-1]['prescribed_contact_hours'] == 9
    assert result['records'][-1]['activity_oxygen_weighted_contact_hours'] == 2.25
    assert max(result['validation'].values()) < 1e-10


def test_short_contact_is_resolved_even_with_large_max_step():
    config = BatchConfig(duration_days=1, output_count=3, max_step_days=1,
        environment_periods=(EnvironmentPeriod(), EnvironmentPeriod(start_hour=5/60, in_contact=False)))
    result = simulate(config)
    boundary = next(row for row in result['records'] if row['day'] == 5/1440)
    final = result['records'][-1]
    assert 0 < final['reacted_NO3_mg_kgw'] < 0.231
    for key in ('NO3_mg_kgw', 'S0_g_kgw', 'CaCO3_g_kgw', 'pH'):
        assert final[key] == boundary[key]
    assert final['prescribed_contact_hours'] == pytest.approx(5/60)


def test_no_contact_preserves_both_solids_and_water_chemistry():
    result = simulate(BatchConfig(duration_days=1, output_count=5,
        environment_periods=(EnvironmentPeriod(in_contact=False),)))
    first, last = result['records'][0], result['records'][-1]
    for key in ('NO3_mg_kgw', 'S0_g_kgw', 'CaCO3_g_kgw', 'pH', 'SO4_mg_kgw'):
        assert last[key] == first[key]
    assert last['prescribed_contact_hours'] == 0


def test_lag_suppresses_biology_while_calcite_can_dissolve():
    result = simulate(BatchConfig(duration_days=1, output_count=5, microbial_lag_hours=24))
    first, last = result['records'][0], result['records'][-1]
    assert last['NO3_mg_kgw'] == first['NO3_mg_kgw']
    assert last['CaCO3_g_kgw'] < first['CaCO3_g_kgw']


def test_contact_pause_and_resume_carries_inventory():
    config = BatchConfig(duration_days=1, output_count=25, environment_periods=(
        EnvironmentPeriod(), EnvironmentPeriod(start_hour=3, in_contact=False),
        EnvironmentPeriod(start_hour=12)))
    rows = simulate(config)['records']
    assert rows[3]['NO3_mg_kgw'] == rows[12]['NO3_mg_kgw']
    assert rows[24]['NO3_mg_kgw'] < rows[12]['NO3_mg_kgw']
    assert rows[24]['prescribed_contact_hours'] == 15


def test_positive_oxygen_requires_explicit_coefficient():
    with pytest.raises(ValueError, match='Positive DO'):
        BatchConfig(environment_periods=(EnvironmentPeriod(dissolved_oxygen_mg_L=2),)).validate()


@pytest.mark.parametrize('periods', [
    ({'start_hour':1},),
    ({'start_hour':0},{'start_hour':0}),
    ({'dissolved_oxygen_mg_L':-1},),
    ({'active_fraction':1.1},),
    ({'in_contact':'false'},),
    ({'start_hour':0},{'start_hour':200}),
    ({'active_fraction':float('nan')},),
])
def test_invalid_schedule_rejected(periods):
    with pytest.raises(ValueError):
        BatchConfig(environment_periods=periods).validate()


def test_json_roundtrip_preserves_environment_inputs():
    config = BatchConfig(duration_days=0.05, output_count=3,
        environment_periods=(EnvironmentPeriod(active_fraction=0.2),))
    reloaded = BatchConfig(**json.loads(json.dumps(asdict(config))))
    assert simulate(config)['records'] == simulate(reloaded)['records']
