# Stage 3 인용 논문과 사용 범위

확인일 2026-11-07. 직접 사용한 문헌 5편과 소프트웨어를 구분한다.
논문 전체 원문을 확보하지 못한 경우 공개 초록·공개 본문에서 확인한 범위만 사용했다.
타 논문의 실험값을 우리 실험값으로 표시하지 않는다.

## R1 — 반응 화학양론

Carboni, M. F., Florentino, A. P., Costa, R. B., Zhan, X., & Lens, P. N. L. (2021).
*Enrichment of Autotrophic Denitrifiers From Anaerobic Sludge Using Sulfurous Electron Donors.*
Frontiers in Microbiology, 12, 678323.
DOI https://doi.org/10.3389/fmicb.2021.678323

공개 원문의 식 (3)에서 생물량 합성을 생략한 원소 황–질산염 전자수지를 확인했다.
이 연구의 슬러지 접종 조건·제거율·속도를 우리 토양으로 전용하지 않았다.

## R2 — Monod 계수의 문헌 기준값

Zeng, H., & Zhang, T. C. (2005).
*Evaluation of kinetic parameters of a sulfur–limestone autotrophic denitrification biofilm process.*
Water Research, 39(20), 4941–4952.
DOI https://doi.org/10.1016/j.watres.2005.09.034
공개 초록 https://pubmed.ncbi.nlm.nih.gov/16289671/

공개 초록에서 Ks=0.398 mg-N/L, 최대 비기질 이용속도 k=0.15 d^-1을 확인해 기준값으로 사용했다.
고정 활성 생물량을 곱하는 축약 Monod 모델에 적용했다. 이 실험의 시계열을 재현했다는 뜻은 아니다.
원 연구의 생물막·황 과잉 조건을 우리 토양과 동일시하지 않는다. 공개 본문에는 mm급 황 입자와 2:1 혼합 조건이 제시된다.
초록의 성장수율·사멸계수는 이번 생물량 고정 모델에 적용하지 않았다.

## R3 — 낮은 pH의 억제와 석회질 완충 근거

Liu, L. H., & Koenig, A. (2002).
*Use of limestone for pH control in autotrophic denitrification: batch experiments.*
Process Biochemistry, 37(8), 885–893.
DOI https://doi.org/10.1016/S0032-9592(01)00302-8
저자 소속기관 기록 https://hub.hku.hk/handle/10722/71580

공개 초록에서 낮은 pH에서의 억제와 초기 알칼리도에 따른 완충 역할을 확인했다.
pH 5.5에서 0, 6.5 이상에서 1인 선형함수는 본 구현의 검증 전 가정이다.
논문이 해당 선형함수나 6.5 기준값을 실증했다는 주장을 하지 않는다.
논문의 생물성장을 포함한 알칼리도 소모량을 무성장 반응식에 섞지 않았다.

## R4 — 방해석 용해속도

Plummer, L. N., Wigley, T. M. L., & Parkhurst, D. L. (1978).
*The kinetics of calcite dissolution in CO2-water systems at 5° to 60°C and 0.0 to 1.0 atm CO2.*
American Journal of Science, 278(2), 179–216.
DOI https://doi.org/10.2475/ajs.278.2.179

PHREEQC 배포 데이터베이스의 수정 PWP Calcite 속도식을 따라 활동도, 온도와 포화도 의존성을 구현했다.
구형 입자의 유효 표면적과 잔존량의 2/3승 감소는 명시적 모델 선택이다.
원 논문의 모든 조건이나 실제 석회석 불순물·생물막 피복을 재현하는 모델은 아니다.

## R5 — 수용액 화학 계산과 기준 적분

Parkhurst, D. L., & Appelo, C. A. J. (2013).
*Description of Input and Examples for PHREEQC Version 3—A Computer Program for Speciation,
Batch-Reaction, One-Dimensional Transport, and Inverse Geochemical Calculations.*
U.S. Geological Survey Techniques and Methods, 6–A43.
https://pubs.usgs.gov/tm/06/a43/

SOLUTION 종분화·전하균형 pH와 KINETICS/CVODE 기준 계산의 근거다.
질산염·황산염은 N(5), S(6)로 지정하고 각 RHS에서 초기 종분화만 수행한다.
미생물 탈질을 수용액 산화환원 평형으로 자동 처리하지 않는다.
https://water.usgs.gov/water-resources/software/PHREEQC/documentation/phreeqc3-html/phreeqc3-48.htm
https://water.usgs.gov/water-resources/software/PHREEQC/documentation/phreeqc3-html/phreeqc3-24.htm

## 소프트웨어와 열역학 자료

Vitens, PhreeqPython 1.6.2. https://github.com/Vitens/phreeqpython
계산에는 설치된 1.6.2의 `phreeqc.dat`를 사용했다. 최신 GitHub 데이터베이스와 동일하다고 가정하지 않는다.
실제 데이터베이스 SHA-256은 `stage3_results/VALIDATION.json`에 고정했다.
비교한 공개 공식 데이터베이스 https://github.com/usgs-coupled-subtrees/phreeqc3-database/blob/master/phreeqc.dat

이전 단계 문헌은 기존 문서에 보존했다. 이번 신규 생물반응 상수의 출처로 인용하지 않았다.
