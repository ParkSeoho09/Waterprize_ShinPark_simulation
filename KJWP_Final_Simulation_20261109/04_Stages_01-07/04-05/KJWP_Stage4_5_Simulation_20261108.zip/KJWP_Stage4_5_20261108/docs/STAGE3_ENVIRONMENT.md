# Stage 3 환경조건 확장 · v0.4.1 · 2026-11-07

현재 버전은 시간에 따른 용존산소, 유효 미생물 활성과 물–고체 접촉 구간을 입력받는다.
기본 무산소·활성 비율 1·연속 접촉 조건은 v0.4.0의 169개 시점과 기존 모든 출력 항목에서 동일하다.

## 계산 방식

질산염 반응속도에 다음 인자를 적용한다.

```
r_NO3(t) = r_Monod_pH(t) * active_fraction(t) * KI/(KI+DO(t)) * contact(t)
effective_X(t) = reference_X * active_fraction(t)
```

`microbial_lag_hours` 이전에는 유효 활성 비율을 0으로 둔다.
방해석 용해는 접촉 여부를 적용하며, 미생물 활성이나 산소 억제 인자를 곱하지 않는다.
접촉이 끊어진 구간은 해당 물 덩어리와 반응재를 분리한 배치 조건으로 처리한다.
용존 성분과 고체 저장량을 보존하고 재접촉하면 이전 상태에서 계산을 이어간다.

산소는 지정된 시간 이력을 사용하는 외부 입력이다. 산소 농도의 발생·소모를 자체 계산하려면
Stage 4에서 산소 수송, 기체–물 교환, 호기성 반응에 대한 원소수지를 추가해야 한다.
현재 황산염과 산 생성량은 질산염을 전자수용체로 사용하는 경로에 대해서 계산한다.
산소에 의한 황 산화가 유의한 조건에서는 총 황산염·산도 예측에 그 반응 경로를 추가해야 한다.
`prescribed_DO_mg_L`은 용존산소 입력이다. 토양기체 산소 농도나 함수율을 대입할 수 없다.

## 근거와 가정

Kou et al. (2024)에서 낮은 DO와 중간 DO 조건의 질산염 제거속도 차이가 유의하지 않은 사례,
높은 DO 조건에서 억제된 사례를 확인했다. 따라서 어떤 토양에도 적용되는 단일 DO 임계값은 채택하지 않았다.
역수형 억제함수와 KI=1, 4 mg/L는 계산 민감도를 보여 주는 공학적 가정이다.
해당 논문의 보정계수를 가져왔거나 논문의 결과를 재현했다고 해석하면 안 된다.
미생물·생물막·입경·유동 조건이 달라지면 유효 KI가 달라질 수 있어 재보정이 필요하다.

양의 DO를 넣을 때 `oxygen_half_inhibition_mg_L`을 명시해야 한다. 계수가 없으면 오류로 중단한다.
미생물 활성 비율은 0–1, 기준 생물량은 mg-VSS/kg 물로 받는다. 기준 생물량과 활성 비율의 곱이
유효 생물량이다. 배양액 VSS 전체를 자동으로 탈질 활성 생물량으로 해석하지 않는다.
현재 활성 이력과 유도기는 외부 입력이다. 생물량 성장·사멸을 예측하려면 탄소·질소 동화 및
미생물량 수지를 추가해 화학양론을 함께 바꿔야 한다.

## JSON 입력 예

```json
{
  "duration_days": 7,
  "biomass_mg_VSS_per_kgw": 100,
  "oxygen_half_inhibition_mg_L": 1,
  "microbial_lag_hours": 12,
  "environment_source": "scenario",
  "environment_periods": [
    {"start_hour": 0, "dissolved_oxygen_mg_L": 6, "active_fraction": 0.5, "in_contact": true},
    {"start_hour": 24, "dissolved_oxygen_mg_L": 0.2, "active_fraction": 0.5, "in_contact": true},
    {"start_hour": 48, "dissolved_oxygen_mg_L": 0.2, "active_fraction": 0.5, "in_contact": false}
  ]
}
```

생략한 기존 항목에는 기본값이 적용된다.
각 항목의 단위는 `start_hour`와 유도기가 시간, DO와 KI가 mg-O2/L이다.
시간은 0부터 엄격한 오름차순이어야 한다. 각 구간의 값은 다음 시작시각 직전까지 유지된다.
경계 시점의 출력은 새 구간 값을 표시하며 반응 저장량은 연속이다.
데이터 출처는 `scenario` 또는 `user_supplied_measurements`로 기록한다.
후자는 사용자가 측정 이력을 넣었음을 표시하며 파일 자체의 검증이나 모든 계수의 보정을 뜻하지 않는다.

## 접촉시간 장부와 Stage 4 연결

- `prescribed_contact_hours`는 입력된 접촉 구간의 누적 길이다.
- `activity_oxygen_weighted_contact_hours`는 접촉시간에 활성 비율과 산소 억제 인자를 곱해 적분한 값이다.
- 가중 시간에는 기질 농도, pH, 표면적, 황 잔존량이 포함되지 않는다. 반응량은 반응식을 적분해 별도로 계산한다.
- Stage 3은 단일 물 덩어리의 지정된 접촉 이력을 계산한다. 토양의 체류시간 분포는 Stage 4 수송 해석에서 구해야 한다.

Stage 4에서는 각 셀의 물 질량, 질산염·DIC·Ca·SO4·Na·Cl 총량과 반응재 저장량을 다음 단계로 전달해야 한다.
물의 유입·유출 후에는 농도를 실제 물 부피로 환산한다. 미생물량을 토양 부피 기준으로 관리하면 물 질량에 따라
유효 X의 단위를 다시 변환한다. 각 시간 단계에서 Na를 새로 맞추면 산 생성 이력이 바뀌므로 초기 설정 이후에는
양이온 저장량을 보존해야 한다. 실제 산소·체류시간 이력과 위 입력의 연결은 Stage 4의 구현·검증 범위다.

## 검증과 결과

전체 자동시험 90개를 통과했다. 시간별 DO·활성·접촉에 따른 Monod 적분은 가중 노출시간을 사용하는
독립 해석해와 비교했다. 접촉 중단/재개, 유도기, 입력 검사, 5분 접촉의 경계 처리와 기존 결과 재현을 확인했다.
세 민감 사례에서 더 엄격한 시간 적분과 비교했으며 실제 수치는 `environment_results/VALIDATION.json`에 있다.
수치검증 통과는 산소 억제계수나 토양 미생물 활성의 실험 검증을 대신하지 않는다.

## 새로 확인한 문헌

R6. Kou, Z., Huo, P., Qi, X., Gu, Y., Huang, X., & Liang, P. (2024).
*Effect of dissolved oxygen on sulfur autotrophic denitrification and how to address it: An experimental and modelling work.*
Water Research, 267, 122415. https://doi.org/10.1016/j.watres.2024.122415
공개 초록에서 DO 영향의 조건 의존성을 확인했다. 이번 KI 값은 연구진이 보고한 보정값이 아니다.

R7. Qambrani, N. A., & Oh, S.-E. (2013).
*Effect of dissolved oxygen tension and agitation rates on sulfur-utilizing autotrophic denitrification: batch tests.*
Applied Biochemistry and Biotechnology, 169(1), 181–191. https://doi.org/10.1007/s12010-012-9955-6
산소와 교반 조건을 배치 실험에서 함께 검토한 문헌이다. 공개 서지·초록을 확인했으며 수치 계수는 채택하지 않았다.

R8. Zhou, W., Sun, Y., Wu, B., Zhang, Y., Huang, M., Miyanaga, T., & Zhang, Z. (2011).
*Autotrophic denitrification for nitrate and nitrite removal using sulfur-limestone.*
Journal of Environmental Sciences, 23(11), 1761–1769. https://doi.org/10.1016/S1001-0742(10)60635-3
공개 초록에서 HRT·온도·농도에 따른 반응기 성능 변화를 확인했다. 논문의 HRT를 우리 토양의 접촉시간으로 대입하지 않았다.

기존 R1–R5는 `STAGE3_REFERENCES.md`를 따른다. 인용문헌은 구현식, 선택한 가정과 적용 범위를 구분해 제시했다.
