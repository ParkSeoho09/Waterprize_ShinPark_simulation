# 사용한 문헌과 적용 범위

기존 `STAGE3_REFERENCES.md`, `STAGE3_ENVIRONMENT.md`, `stage2_validated_engine/REFERENCES.md`의 출처와 적용 한계를 유지한다. 논문 실험값을 우리 토양 실측값으로 취급하지 않는다.

| 문헌 | 실제 사용 |
|---|---|
| Carboni et al. (2021), *Enrichment of Autotrophic Denitrifiers From Anaerobic Sludge Using Sulfurous Electron Donors*, Front. Microbiol. 12, 678323. https://doi.org/10.3389/fmicb.2021.678323 | 무성장 황–질산염 반응 화학양론 |
| Zeng & Zhang (2005), *Evaluation of kinetic parameters of a sulfur–limestone autotrophic denitrification biofilm process*, Water Research 39, 4941–4952. https://doi.org/10.1016/j.watres.2005.09.034 | Monod 기준 k=0.15 d⁻¹, Ks=0.398 mg-N/L. 토양 보정값 아님 |
| Liu & Koenig (2002), *Use of limestone for pH control in autotrophic denitrification: batch experiments*, Process Biochemistry 37, 885–893. https://doi.org/10.1016/S0032-9592(01)00302-8 | pH 억제와 석회질 완충의 정성 근거. 구현의 선형 억제함수는 가정 |
| Plummer, Wigley & Parkhurst (1978), *The kinetics of calcite dissolution in CO2-water systems at 5° to 60°C and 0.0 to 1.0 atm CO2*, Am. J. Sci. 278, 179–216. https://doi.org/10.2475/ajs.278.2.179 | PHREEQC의 수정 PWP 용해식 |
| Parkhurst & Appelo (2013), *Description of Input and Examples for PHREEQC Version 3*, USGS TM 6–A43. https://pubs.usgs.gov/tm/06/a43/ | SOLUTION 종분화·활동도·전하균형. https://water.usgs.gov/water-resources/software/PHREEQC/documentation/phreeqc3-html/phreeqc3-39.htm |
| Parkhurst & Wissmeier (2015), *PhreeqcRM: A reaction module for transport simulators based on the geochemical model PHREEQC*, Advances in Water Resources 83, 176–189. https://doi.org/10.1016/j.advwatres.2015.06.001 | 성분 농도를 수송한 뒤 셀 반응을 수행하는 연산자 분리 구조의 근거. 본 코드는 PhreeqPython과 자체 BDF를 사용하며 PhreeqcRM 라이브러리를 직접 연결한 것은 아님 |

새 연결 구조는 USGS 공식 설명과 공개 논문에서 확인했다. 공개 PDF https://water.usgs.gov/water-resources/software/VS2DRTI/ParkhurstWissmeier2015.pdf

DO 입력 기능의 배경 검토 문헌은 Kou et al. (2024), https://doi.org/10.1016/j.watres.2024.122415 ; Qambrani & Oh (2013), https://doi.org/10.1007/s12010-012-9955-6 ; Zhou et al. (2011), https://doi.org/10.1016/S1001-0742(10)60635-3 이다. 상세 적용 한계는 Stage 3 환경 문서에 있다. KI나 이번 무산소 샘플 결과를 이 논문으로 실증했다고 주장하지 않는다.

Strang (1968)은 분리법 검토 시 확인했지만 이번 구현은 대칭 Strang 분리가 아닌 1차 순차 분리다. https://doi.org/10.1137/0705041

5 μm 입경, 고정 유효 비표면적, 100 mg-VSS/kg 물의 초기 생물량, 입자 보유량의 동일 반응 접근성, 샘플 토양·압력·투입량은 모델 선택이다. 위 논문이 이 조합을 검증한 것은 아니다.
