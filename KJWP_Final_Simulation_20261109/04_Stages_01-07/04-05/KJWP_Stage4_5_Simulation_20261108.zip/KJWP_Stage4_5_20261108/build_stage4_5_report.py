"""Build a self-contained Korean report from actual saved simulation fields."""
from pathlib import Path
import base64,csv,html,io,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties
from PIL import Image
ROOT=Path(__file__).parent
FONT='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'
if Path(FONT).exists():plt.rcParams['font.family']=[FontProperties(fname=FONT).get_name(),'DejaVu Sans']
plt.rcParams.update({'axes.unicode_minus':False,'font.size':11,'axes.spines.top':False,'axes.spines.right':False,'savefig.dpi':160})


def main():
    sample=ROOT/'stage5_results/sample';s=json.loads((sample/'summary.json').read_text());cfg=json.loads((sample/'input.json').read_text())
    h=list(csv.DictReader((sample/'history.csv').open()));h=[{k:float(v) for k,v in r.items()} for r in h]
    z=np.load(sample/'fields.npz');valid=json.loads((ROOT/'stage4_results/VALIDATION.json').read_text())
    figs=ROOT/'stage45_figures';figs.mkdir(exist_ok=True)
    def figsave(fig,name):
        p=figs/name;fig.savefig(p,bbox_inches='tight');plt.close(fig);return p
    def embed(p):return 'data:image/png;base64,'+base64.b64encode(p.read_bytes()).decode()
    t=np.array([r['time_s']/3600 for r in h]);f=h[-1];initial=h[0]['NO3_stored_kg'];available=initial+f['NO3_in_kg']
    reacted=f['NO3_reacted_kg'];frac=100*reacted/available
    no3=lambda k:np.array([r[k] for r in h])*1e6
    fig,ax=plt.subplots(1,2,figsize=(12,4.8),layout='constrained')
    ax[0].plot(t,no3('NO3_stored_kg'),label='토양 내 잔류',color='#17658a')
    ax[0].plot(t,no3('NO3_out_kg'),label='누적 유출',color='#ce9b40')
    ax[0].plot(t,no3('NO3_reacted_kg'),label='누적 반응',color='#198778')
    ax[0].plot(t,initial*1e6+no3('NO3_in_kg'),'--',label='초기량 + 누적 유입',color='#555')
    ax[0].set(xlabel='시간 (h)',ylabel='NO₃⁻ 이온 질량 (mg)',title='질산염 질량의 행방');ax[0].legend(fontsize=9);ax[0].grid(alpha=.2)
    water=np.array([r['water_stored_m3'] for r in h]);ax[1].plot(t,no3('NO3_stored_kg')/(water*1000),label='수송 + 반응',color='#198778')
    ax[1].plot(t,no3('NO3_passive_stored_kg')/(water*1000),'--',label='동일 유동장의 무반응 성분',color='#636c7b')
    ax[1].set(xlabel='시간 (h)',ylabel='물 부피 가중 평균 (mg/L)',title='희석·유출과 반응을 구분');ax[1].legend(fontsize=9);ax[1].grid(alpha=.2)
    pbudget=figsave(fig,'budget.png')
    ports=np.array([p['position_m'] for p in cfg['ports']]);yindex=int(np.argmin(abs(z['y_m']-.27)))
    fig=plt.figure(figsize=(12,5),layout='constrained');a=fig.add_subplot(121,projection='3d')
    zz,yy,xx=np.meshgrid(z['z_m'],z['y_m'],z['x_m'],indexing='ij');reaction=z['NO3_reacted_kg_cell'][-1]*1e6
    mask=reaction>max(float(reaction.max())*.015,1e-10)
    sc=a.scatter(xx[mask],yy[mask],zz[mask],c=reaction[mask],s=25,cmap='YlGnBu',alpha=.7)
    for pipe in cfg['layout_metadata']['pipes']:
        line=np.array([pipe['body_top_m'],pipe['body_end_m']]);a.plot(line[:,0],line[:,1],line[:,2],color='#555',lw=6,alpha=.75)
    a.scatter(ports[:,0],ports[:,1],ports[:,2],c='#d95e35',s=45,label='실제 입력 출구')
    a.set(xlim=(0,.6),ylim=(0,.6),zlim=(1.2,0),xlabel='x (m)',ylabel='y (m)',zlabel='깊이 z (m)',title='서비스관과 누적 반응량 분포')
    a.set_box_aspect((1,1,2));fig.colorbar(sc,ax=a,shrink=.65,label='셀별 누적 NO₃ 반응 (mg)')
    a=fig.add_subplot(122);amount=np.array(s['port_water_m3'])*1e6/(1-cfg['slurry']['solid_volume_fraction'])
    labels=cfg['layout_metadata']['port_ids'];a.barh(labels,amount,color='#198778');a.set(xlabel='출구별 실제 슬러리 공급 (mL)',title='동일 압력이어도 유량은 같지 않음');a.grid(axis='x',alpha=.2)
    pgeometry=figsave(fig,'geometry_ports.png')
    def slices(index):
        fig,axs=plt.subplots(1,3,figsize=(12,5),layout='constrained')
        data=[z['NO3_kg_m3_carrier'][index,:,yindex,:]*1000,z['pH'][index,:,yindex,:],z['SO4_kg_m3_carrier'][index,:,yindex,:]*1000]
        titles=['질산염 (mg-NO₃/L)','pH','황산염 (mg-SO₄/L)'];cmaps=['viridis','RdYlBu','magma']
        bounds=[(0,max(40,float(z['NO3_kg_m3_carrier'].max()*1000))),(min(5.4,float(z['pH'].min())),max(7.3,float(z['pH'].max()))),(float(z['SO4_kg_m3_carrier'].min()*1000),float(z['SO4_kg_m3_carrier'].max()*1000))]
        for ax,arr,title,cmap,(lo,hi) in zip(axs,data,titles,cmaps,bounds):
            im=ax.imshow(arr,extent=(0,.6,1.2,0),origin='upper',cmap=cmap,vmin=lo,vmax=hi,aspect='equal',interpolation='nearest')
            ax.scatter(ports[:,0],ports[:,2],s=14,c='#fc7356',edgecolor='white',linewidth=.4)
            ax.set(xlabel='x (m)',ylabel='깊이 (m)',title=title);fig.colorbar(im,ax=ax,shrink=.75)
        fig.suptitle(f"계산된 절단면 · y={z['y_m'][yindex]:.2f} m · {z['time_s'][index]/3600:g} h",fontsize=14)
        return fig
    frames=[]
    for i in range(len(z['time_s'])):frames.append(figsave(slices(i),f'slice_{i:02d}.png'))
    gif=figs/'evolution.gif';imgs=[Image.open(p).convert('RGB') for p in frames];imgs[0].save(gif,save_all=True,append_images=imgs[1:],duration=900,loop=0)
    vals={}
    for species in ('NO3','tracer','sulfur','caco3','SO4','Ca','DIC','Na','Cl','NO3_passive'):
        scale=h[0][species+'_stored_kg']+f[species+'_in_kg']+abs(f[species+'_reaction_net_kg'])
        vals[species]=abs(f[species+'_residual_kg'])/max(scale,1e-30)
    shadow=f['NO3_passive_stored_kg']-f['NO3_stored_kg']+f['NO3_passive_out_kg']-f['NO3_out_kg']-reacted
    assert max(vals.values())<1e-9
    assert abs(shadow)<1e-12
    assert s['dose']['done']
    metrics=dict(initial_NO3_mg=initial*1e6,incoming_NO3_mg=f['NO3_in_kg']*1e6,available_NO3_mg=available*1e6,
      reacted_NO3_mg=reacted*1e6,reacted_percent_of_initial_plus_input=frac,remaining_NO3_mg=f['NO3_stored_kg']*1e6,outgoing_NO3_mg=f['NO3_out_kg']*1e6,
      injection_completion_s=s['injection_completion_s'],injection_duration_s=s['injection_completion_s']-300,actual_solid_g=s['dose']['injected_dry_solid_kg']*1000,
      actual_slurry_mL=s['dose']['injected_slurry_volume_m3']*1e6,SO4_generated_mg=f['SO4_reaction_net_kg']*1e6,Ca_generated_mg=f['Ca_reaction_net_kg']*1e6,
      final_pH_min=float(z['pH'][-1].min()),final_pH_max=float(z['pH'][-1].max()),max_relative_component_residual=max(vals.values()),component_residuals=vals,
      no3_balance_residual_mg=f['NO3_residual_kg']*1e6,shadow_identity_residual_mg=shadow*1e6,elapsed_s=s['elapsed_s'],grid_cells=432,
      status='sample PASS; not spatially converged or experimentally calibrated')
    (sample/'REPORT_METRICS.json').write_text(json.dumps(metrics,indent=2)+'\n')
    table=lambda rows:'<div class="scroll"><table><tbody>'+''.join('<tr>'+''.join('<td>'+str(c)+'</td>' for c in r)+'</tr>' for r in rows)+'</tbody></table></div>'
    summary_rows=[['항목','48시간 결과'],['질산염 초기량',f'{initial*1e6:.3f} mg'],['질산염 추가 유입',f"{f['NO3_in_kg']*1e6:.3f} mg"],['실제 반응량',f'{reacted*1e6:.3f} mg · {frac:.3f}%'],['잔류량',f"{f['NO3_stored_kg']*1e6:.3f} mg"],['유출량',f"{f['NO3_out_kg']*1e6:.3f} mg"],['생성 황산염 / 칼슘',f"{metrics['SO4_generated_mg']:.3f} / {metrics['Ca_generated_mg']:.3f} mg"],['최종 pH 범위',f"{metrics['final_pH_min']:.3f}–{metrics['final_pH_max']:.3f}"],['실제 고체량 / 슬러리',f"{metrics['actual_solid_g']:.6f} g / {metrics['actual_slurry_mL']:.3f} mL"],['주입 소요 시간',f"{metrics['injection_duration_s']/60:.3f} min"],['질산염 수지 잔차',f"{metrics['no3_balance_residual_mg']:.3e} mg"]]
    checkrows=[['검사','결과'],['전체 회귀시험','102개 통과'],['반응 OFF ↔ Stage 2','기존 필드 최대 차이 0'],['단일 셀 ↔ Stage 3',f"최대 {max(v['no3_error_mg_kgw'] for v in valid['closed_cell_comparison']):.3e} mg/kg 물"],['시간 간격 1200→600초',f"농도장 상대 차이 {valid['time_refinement'][0]['water_weighted_L1_relative']*100:.5f}%"],['시간 간격 600→300초',f"농도장 상대 차이 {valid['time_refinement'][1]['water_weighted_L1_relative']*100:.5f}%"],['검증 케이스 성분수지',f"최대 상대 잔차 {max(max(v['relative_residuals'].values()) for v in valid['mass_balances']):.3e}"],['샘플 성분수지',f"최대 상대 잔차 {max(vals.values()):.3e}"],['배치 자동 실행','90초 두 배치와 무주입 대조군 실행 · 미달 사례 차단']]
    refs=[('Carboni et al. 2021 · 황–질산염 화학양론','https://doi.org/10.3389/fmicb.2021.678323'),('Zeng & Zhang 2005 · Monod 기준값','https://doi.org/10.1016/j.watres.2005.09.034'),('Liu & Koenig 2002 · pH 억제와 완충','https://doi.org/10.1016/S0032-9592(01)00302-8'),('Plummer et al. 1978 · 방해석 용해식','https://doi.org/10.2475/ajs.278.2.179'),('Parkhurst & Appelo 2013 · PHREEQC 종분화','https://pubs.usgs.gov/tm/06/a43/'),('Parkhurst & Wissmeier 2015 · 성분 수송–반응 분리','https://doi.org/10.1016/j.advwatres.2015.06.001')]
    sources=''.join(f'<li><a href="{url}">{html.escape(title)}</a></li>' for title,url in refs)
    times=[float(v/3600) for v in z['time_s']];images=[embed(p) for p in frames]
    doc=f'''<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>KJWP Stage 4·5 결과</title><style>
*{{box-sizing:border-box}}body{{margin:0;background:#edf3f6;color:#193249;font:16px/1.8 system-ui,sans-serif}}main{{max-width:1160px;margin:auto;padding:24px}}header{{background:#12364a;color:white;padding:38px;border-radius:18px}}header p{{color:#d4ecec}}h1{{font-size:32px;margin:8px 0}}h2{{font-size:23px;margin-top:0}}section{{background:white;padding:28px;margin-top:20px;border-radius:14px}}.tag{{color:#91dacc;font-size:14px}}.note{{background:#fff3d9;border-left:4px solid #c69428;padding:16px}}.good{{background:#e1f2ec;padding:16px;border-left:4px solid #168b76}}table{{border-collapse:collapse;width:100%;font-size:14px}}td{{padding:10px;border-bottom:1px solid #dce5ea}}tr:first-child{{font-weight:700;background:#edf4f6}}td:first-child{{width:43%}}.scroll{{overflow:auto}}img{{width:100%;height:auto}}a{{color:#087986}}input[type=range]{{width:100%}}.small{{color:#567080;font-size:13px}}pre{{background:#eef3f5;padding:16px;overflow:auto;font-size:13px}}li{{margin-bottom:6px}}@media(max-width:700px){{main{{padding:10px}}header,section{{padding:20px}}h1{{font-size:26px}}}}
</style></head><body><main><header><div class="tag">KJWP 2026 · 신박 · v0.5.1 · 2026.11.08</div><h1>수송·반응 결합과 6개 출구 샘플</h1><p>4. 질산염 수송·주입수·반응 결합<br>5. 3D 서비스관 및 배치조건 구성 — 48시간 샘플 및 배치 실행 검증</p></header>
<section><h2>이번에 확인한 것</h2><div class="good">반응을 끄면 기존 Stage 2와 같은 결과가 나오고, 반응을 켜면 질산염 반응량과 고체 소모량이 성분 수지에 기록된다. 102개 시험과 작은 결합 케이스의 시간 간격 검사를 통과했다.</div><p>관 위치·각도·회전·출구를 JSON으로 입력하면 실제 계산 좌표로 변환한다. 최종 배치 변수는 다른 채팅에서 정한 후 반복 실행 입력으로 전달할 수 있다.</p><div class="note">아래 수치는 가정한 토양·수질·무산소·활성 조건의 샘플 계산이다. 432셀의 공간 수렴, 실제 토양의 제거 성능, 최적 배치는 입증하지 않았다. 최종 UI도 아직 아니다.</div></section>
<section><h2>48시간 샘플 결과</h2>{table(summary_rows)}<p>반응률의 분모는 <b>초기 질산염 + 48시간 누적 유입 질산염</b>이다. 잔류·유출은 제거로 세지 않았다. 황산염과 칼슘은 반응으로 새로 생성된 누적량이며 유출·잔류와 별도다.</p><img src="{embed(pbudget)}" alt="질산염 질량수지와 무반응 비교"></section>
<section><h2>주입이 끝난 뒤에도 계산한다</h2><p>공급은 시작 후 {metrics['injection_duration_s']/60:.3f}분에 목표 고체 10g을 채워 종료했다. 이후에도 이동·유출·접촉·반응을 48시간까지 계산했다. 주입시간과 물–반응재의 접촉시간은 같은 값이 아니다.</p><img src="{embed(pgeometry)}" alt="3차원 샘플 관과 출구별 실제 투입량"><p class="small">관은 위치·제어를 정하는 기하 입력이다. 관벽의 토양 배제 부피와 관 내부 압력손실을 해석하지 않았다. 점은 계산 셀별 누적 반응량이며 노즐 유동을 해상한 영상이 아니다.</p></section>
<section><h2>시간별 실제 계산 농도장</h2><p>슬라이더로 저장된 시점만 확인한다. 붉은 점은 출구의 x–z 투영이다. 색 범위는 모든 시점에 고정했다.</p><label id="time">48 h</label><input aria-label="저장 시점" id="slider" type="range" min="0" max="{len(frames)-1}" value="{len(frames)-1}" step="1"><img id="slice" src="{images[-1]}" alt="질산염 pH 황산염 절단면"></section>
<section><h2>수치 검증</h2>{table(checkrows)}<p>시간 간격 검사는 별도의 4×4×8셀·3시간 결합 케이스다. 전체 48시간 샘플의 정확도 보증으로 확대 해석하지 않는다. 수지 오차가 작다는 것은 질량 회계가 맞는다는 뜻이며 물리모형이나 실험 예측 정확도를 뜻하지 않는다.</p></section>
<section><h2>연결하면서 명확히 정한 가정</h2><ul><li>NO₃·SO₄·Ca·DIC·Na·Cl를 수송한 뒤 PHREEQC에서 pH를 다시 계산한다.</li><li>생물량은 토양 부피당 고정해 물이 들어올 때 생물량이 생기지 않도록 했다.</li><li>기존 배치의 500μm 수축구와 구분하여 샘플은 5μm 고정 유효 비표면적을 사용했다. 입경·면적법은 변경 가능한 가정이다.</li><li>DO=0, 활성비율=1, 유도기=0이다. 산소 수송·소모와 생물량 성장·사멸은 계산하지 않는다.</li><li>황의 표면 전달 저항, NO₂/N₂O, 침전·막힘·공극 변화는 미구현이다.</li><li>추적자 연령·접촉 모멘트는 혼합된 평균 진단값이며 실제 공극 체류시간 분포가 아니다.</li></ul></section>
<section><h2>다음 배치를 넘기는 방법</h2><p>공통 토양·수질·투입량은 <b>base JSON</b>, 관/출구 구조는 <b>layout JSON</b>, 실행할 후보 목록은 <b>batch JSON</b>으로 나눈다. CAD에서 얻은 출구 좌표도 직접 입력할 수 있다. CAD 자동 메싱은 포함하지 않는다.</p><pre>python run_layout_batch.py configs/stage5/batch_sample.json --out new_inputs --compile-only
python run_layout_batch.py configs/stage5/batch_sample.json --out new_runs</pre><p>같은 토양과 질산염 부하에서 두 주입 배치와 무주입 대조군을 90초간 검증했다. 경사·회전·지상 노출과 출구별 제어를 적용했고, 실제 고체량·운반수량이 목표에 맞는지 확인했다. 목표 미달 사례는 비교 준비 완료에서 제외했다. 전체 질산염 유출량과 바닥 유출량은 따로 기록한다. 여러 출구가 한 격자 셀을 공유하면 해당 셀에 공급원이 합산된다는 점을 요약에 표시한다. 자세한 전달 양식은 ZIP의 docs/STAGE5_HANDOFF.md에 있다.</p></section>
<section><h2>인용한 문헌</h2><ul>{sources}</ul><p class="small">산소 영향 배경 문헌 Kou et al. (2024), Qambrani & Oh (2013), Zhou et al. (2011)의 DOI와 적용 범위는 ZIP의 STAGE4_REFERENCES.md와 기존 Stage 3 환경 문서에 명시했다. 논문의 반응계수를 토양 실측값으로 간주하지 않는다. PhreeqcRM의 결합 구조를 참고했으며 실행은 PhreeqPython 1.6.2와 자체 BDF다.</p></section>
<section><h2>파일과 재현</h2><p>ZIP에 실행 코드, 모든 입력, history.csv, fields.npz, 시험 로그, 수치 검증 JSON, 논문과 가정 문서가 들어 있다. 저장된 보고서는 재계산 없이 열 수 있다. 재계산은 CPU에 따라 수분 이상 걸리며 Windows에서는 실행을 검증하지 않았다.</p><p class="small">이번 샘플 실제 계산 시간 {s['elapsed_s']:.1f}초. 90초 시험과 48시간 샘플의 목적은 계산 흐름 검증이다.</p></section></main>
<script>const frames={json.dumps(images)},times={json.dumps(times)};document.getElementById('slider').oninput=function(){{document.getElementById('slice').src=frames[this.value];document.getElementById('time').textContent=times[this.value]+' h';}};</script></body></html>'''
    path=ROOT/'KJWP_Stage4_5_Report_20261108.html';path.write_text(doc,encoding='utf-8');print(json.dumps(metrics,indent=2));print(path)
if __name__=='__main__':main()
