@echo off
cd /d "%~dp0"
py -3.12 -m venv .venv
if errorlevel 1 goto failed
call .venv\Scripts\activate.bat
python -m pip install -r requirements-stage3.txt
if errorlevel 1 goto failed
python -m pytest -q tests
if errorlevel 1 goto failed
python run_environment_validation.py
if errorlevel 1 goto failed
python build_environment_report.py
if errorlevel 1 goto failed
start "" "KJWP_Stage3_Report_20261107.html"
pause
exit /b 0
:failed
echo Stage 3 stopped. Read the error above. Python 3.12 is required.
pause
exit /b 1
