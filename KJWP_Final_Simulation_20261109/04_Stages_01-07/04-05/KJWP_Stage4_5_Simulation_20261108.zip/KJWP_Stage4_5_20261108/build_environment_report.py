"""Generate the Stage 3 environmental extension report from saved calculations."""
from pathlib import Path
import base64
import json
import re
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'environment_results'
LABELS = {
    'reference':'기준 무산소·활성 100%', 'no_contact':'접촉 없음',
    'oxygen_0.5':'DO 0.5 mg/L · KI 1', 'oxygen_3':'DO 3 mg/L · KI 1',
    'oxygen_6':'DO 6 mg/L · KI 1', 'oxygen_6_KI4':'DO 6 mg/L · KI 4',
    'activity_10_percent':'활성 비율 10%', 'lag_24_hours':'유도기 24시간',
    'contact_5min':'접촉 5분', 'contact_3h':'접촉 3시간',
    'contact_12h':'접촉 12시간', 'contact_24h':'접촉 24시간',
    'contact_48h':'접촉 48시간', 'oxygen_drop_after_24h':'24시간에 DO 6 → 0.2',
}


def main():
    validation = json.loads((OUT/'VALIDATION.json').read_text())
    if not validation['all_passed']:
        raise RuntimeError('Validation must pass before building report')
    rows = validation['cases']
    data = {item['case']:json.loads((OUT/item['case']/'result.json').read_text()) for item in rows}
    plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False})
    figure, axes = plt.subplots(2,2,figsize=(12,8),layout='constrained')
    panels = [
        (axes[0,0], [('reference','DO 0'),('oxygen_0.5','DO 0.5, KI 1'),
          ('oxygen_3','DO 3, KI 1'),('oxygen_6','DO 6, KI 1'),('oxygen_6_KI4','DO 6, KI 4')],
          'Oxygen-response sensitivity (KI is assumed)'),
        (axes[0,1], [('reference','Active fraction 1'),('activity_10_percent','Active fraction 0.1'),
          ('lag_24_hours','24-hour lag')], 'Activity and activation delay'),
        (axes[1,0], [('reference','Continuous contact'),('contact_3h','3-hour contact'),
          ('contact_12h','12-hour contact'),('contact_24h','24-hour contact')], 'Prescribed material contact'),
        (axes[1,1], [('reference','DO 0'),('oxygen_6','DO 6'),
          ('oxygen_drop_after_24h','DO 6 to 0.2 after 24 h')], 'Changing oxygen input (KI = 1)'),
    ]
    for axis, cases, title in panels:
        for name, label in cases:
            values=data[name]['records']
            axis.plot([row['day']*24 for row in values], [row['NO3_mg_kgw'] for row in values],
                      label=label,linewidth=2)
        axis.set(xlabel='Time [hours]',ylabel='NO3 [mg / kg water]',title=title,xlim=(0,168),ylim=(0,42))
        axis.legend(frameon=False,fontsize=8)
        axis.grid(alpha=0.15)
    figure.suptitle('Stage 3 environmental scenarios | illustrative inputs, pending experimental calibration',fontsize=13)
    figure.savefig(OUT/'environment_comparison.png',dpi=160)
    figure.savefig(OUT/'environment_comparison.svg')
    plt.close(figure)
    image=base64.b64encode((OUT/'environment_comparison.png').read_bytes()).decode()
    body=''
    for row in rows:
        t90='7일 내 미도달' if row['t90_first_output_hours'] is None else f"{row['t90_first_output_hours']:.0f}시간"
        body+=f"<tr><th>{LABELS[row['case']]}</th><td>{row['reaction_at_24h_percent']:.2f}%</td><td>{row['reaction_final_percent']:.2f}%</td><td>{t90}</td><td>{row['contact_hours']:.3g}시간</td></tr>"
    test_log=(ROOT/'stage3_results/environment_all_tests.txt').read_text()
    test_count=re.search(r'(\d+) passed',test_log).group(1)
    maximum_difference=max(row['max_NO3_difference_mg_kgw'] for row in validation['time_step_comparisons'])
    report=f'''<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>KJWP Stage 3 환경조건 확장</title>
<style>*{{box-sizing:border-box}}body{{margin:0;background:#eff4f7;color:#193148;font:16px/1.75 system-ui,-apple-system,"Noto Sans KR",sans-serif}}main{{max-width:1160px;margin:auto;padding:24px}}header{{padding:36px;background:#12334b;color:white;border-radius:18px}}h1{{margin:8px 0;font-size:34px}}h2{{font-size:23px;margin:0 0 16px}}section{{background:white;padding:28px;border-radius:14px;margin-top:20px}}.tag{{color:#94e1d3;font-size:14px}}.note{{padding:18px;background:#fff4d9;border-left:4px solid #d09b21;border-radius:7px}}.good{{padding:18px;background:#e4f4f0;border-left:4px solid #118979;border-radius:7px}}img{{width:100%;height:auto}}.scroll{{overflow:auto}}table{{width:100%;border-collapse:collapse;font-size:14px}}td,th{{text-align:left;border-bottom:1px solid #e1e7ed;padding:10px 12px;white-space:nowrap}}thead{{background:#edf4f7}}.small{{font-size:13px;color:#556e80}}a{{color:#087c87;overflow-wrap:anywhere}}pre{{padding:18px;background:#eef4f7;overflow:auto;border-radius:8px}}li{{margin-bottom:12px}}@media(max-width:700px){{main{{padding:10px}}header,section{{padding:20px}}h1{{font-size:27px}}}}</style></head><body><main>
<header><div class="tag">KJWP 2026 · STAGE 3 · v0.4.1 · 2026.11.07</div><h1>산소·미생물 활성·접촉시간을 반영한 반응모델</h1><p>시간별 환경조건을 입력하고 질산염 반응과 반응재 소모를 계산한다. 기존 기준 결과 재현과 전체 {test_count}개 자동시험을 통과했다.</p></header>
<section><h2>이번에 추가한 계산</h2><div class="scroll"><table><thead><tr><th>항목</th><th>입력과 처리</th><th>계산에 미치는 영향</th></tr></thead><tbody><tr><th>용존산소</th><td>시간별 DO와 명시한 KI</td><td>탈질 속도에 KI/(KI+DO) 적용</td></tr><tr><th>미생물 활성</th><td>기준 생물량 × 시간별 활성 비율, 유도기</td><td>유도기에는 탈질 0, 이후 유효 생물량 적용</td></tr><tr><th>접촉시간</th><td>시간별 물–고체 접촉 여부</td><td>접촉 종료 시 탈질·방해석 용해 정지, 재접촉 시 이전 저장량에서 재개</td></tr></tbody></table></div><p>산소·활성·접촉 조건이 바뀌는 시점에서 적분을 나눴다. 출력에도 경계 시점을 포함해 5분처럼 짧은 접촉 구간을 계산한다. 미생물 유도기에도 물과 접촉한 방해석은 용해할 수 있다.</p><div class="note"><b>모든 비교 조건은 민감도 시나리오다.</b> DO와 활성의 시간 이력, 유도기, 접촉시간은 외부 입력이며 토양 내 변화를 자체 예측하는 단계는 아직 구현 중이다. KI=1·4 mg/L는 선택한 가정이며 실험 보정값이 아니다.</div></section>
<section><h2>14개 시나리오의 실제 계산 결과</h2><p>초기 NO₃ 40 mg/kg 물, 황 0.300 g/kg 물, 방해석 0.13092 g/kg 물, 기준 생물량 100 mg-VSS/kg 물을 사용했다. 아래 감소율은 질산염 이온의 반응 질량을 기준으로 계산했다.</p><div class="scroll"><table><thead><tr><th>조건</th><th>24시간 반응률</th><th>7일 반응률</th><th>90% 감소 첫 출력</th><th>누적 접촉</th></tr></thead><tbody>{body}</tbody></table></div><p class="small">90% 시점은 정규 1시간 출력과 환경 경계 출력 중 첫 도달 시점이다. 반응률 100.00%는 반올림 표시이며 미량의 질산염이 소진 허용치만큼 남는다. 접촉시간은 해당 물 덩어리에 지정한 시간이다.</p><p><b>5분 접촉 조건은 약 0.55%만 반응했다.</b> 3시간은 약 18.56%, 24시간은 약 62.65%였다. 주입이 끝난 뒤에도 물과 반응재가 접촉하는 기간을 Stage 4에서 추적해야 한다.</p></section>
<section><h2>환경조건에 따른 반응 곡선</h2><img src="data:image/png;base64,{image}" alt="용존산소, 활성 비율, 유도기, 접촉 구간에 따른 질산염 반응 비교"><p class="small">모든 선은 저장된 계산값이다. 산소 농도와 속도 관계의 모양은 선택한 억제함수에 의해 결정된다. 문헌의 실험 곡선이나 토양 관측 결과를 맞춘 그래프는 아니다.</p></section>
<section><h2>산소계수의 불확실성을 결과에 드러냈다</h2><p>같은 DO 6 mg/L에서도 KI를 1에서 4 mg/L로 바꾸면, 90% 감소 첫 출력이 <b>102시간에서 58시간</b>으로 달라졌다. 활성 비율을 10%로 설정하면 약 145시간이었다. 실제 예측에는 DO 측정과 유효 미생물 활성의 보정이 필요하다.</p><p>Kou et al. (2024)의 공개 초록에서는 중간 DO에서 제거속도의 유의한 저하가 없는 조건도 확인된다. 따라서 이번 역수형 함수와 두 KI 값으로 해당 논문의 반응기를 재현했다고 해석할 수 없다. 연구 대상 토양에 대한 반응 시험으로 계수와 함수 형태를 검토해야 한다.</p></section>
<section><h2>검증</h2><div class="good">전체 자동시험 <b>{test_count}개 통과</b> · 기존 기준해 모든 출력 항목의 최대 차이 <b>{validation['legacy_max_absolute_field_difference']:.1f}</b> · 원소·전하·알칼리도 수지 최대 잔차 <b>{validation['max_balance_residual_mol_or_eq_kgw']:.2e} mol 또는 eq/kg 물</b></div><p>시간별 DO·활성·접촉을 적용한 Monod 결과를 독립 해석해와 비교했다. 접촉 중단/재개, 미생물 유도기, 잘못된 입력, 5분 접촉을 검사했다. 세 환경 사례에서 시간 간격을 줄이고 허용오차를 강화했을 때 NO₃ 최대 차이는 {maximum_difference:.2e} mg/kg 물이었다.</p><p>PHREEQC가 pH와 수용액 종분화를 계산하며, 질산염 반응의 N/S/Ca/C 수지를 출력한다. 이 수지에는 외부 입력인 산소의 발생·소모와 호기성 황 산화가 포함되지 않는다.</p></section>
<section><h2>Stage 4에서 연결할 항목</h2><ol><li>각 격자의 물·질산염·용존 성분·반응재 저장량을 보존하면서 반응 입력 단위로 환산한다.</li><li>DO 수송과 기체–물 교환, 산소 소비에 필요한 반응 경로를 선택하고 수지를 검증한다. 현재 DO 시간표는 그 결과를 연결하기 위한 입력 형식이다.</li><li>주입 종료 이후의 물 이동과 반응재 분포를 이용해 물–반응재 접촉 이력과 체류시간 분포를 구한다.</li><li>희석·유출·반응 질량을 분리하고, 반응을 껐을 때 Stage 1·2와 일치하는지 확인한다.</li></ol><p>동적 생물량 성장·사멸, 영양분 제한, NO₂/N₂O와 호기성 황 산화는 추가 근거와 검증이 필요한 범위다. 현재 산소가 높은 사례의 황산염·산도는 질산염 반응 경로의 기여량으로 해석해야 한다.</p></section>
<section><h2>새로 확인한 문헌과 적용 범위</h2><ol start="6"><li><b>Kou et al. (2024)</b>, Effect of dissolved oxygen on sulfur autotrophic denitrification and how to address it: An experimental and modelling work. Water Research 267, 122415.<br>DO 영향의 조건 의존성 확인. KI 값은 이번 시나리오에서 선택.<br><a href="https://doi.org/10.1016/j.watres.2024.122415">10.1016/j.watres.2024.122415</a></li><li><b>Qambrani & Oh (2013)</b>, Effect of dissolved oxygen tension and agitation rates on sulfur-utilizing autotrophic denitrification: batch tests. Applied Biochemistry and Biotechnology 169, 181–191.<br>산소·교반 조건의 실험 검토를 확인. 수치 계수는 채택하지 않음.<br><a href="https://doi.org/10.1007/s12010-012-9955-6">10.1007/s12010-012-9955-6</a></li><li><b>Zhou et al. (2011)</b>, Autotrophic denitrification for nitrate and nitrite removal using sulfur-limestone. Journal of Environmental Sciences 23, 1761–1769.<br>체류시간·온도·농도에 따른 반응기 성능 변화의 근거.<br><a href="https://doi.org/10.1016/S1001-0742(10)60635-3">10.1016/S1001-0742(10)60635-3</a></li></ol><p>기존 반응계에 사용한 문헌 5편은 Carboni et al. (2021, <a href="https://doi.org/10.3389/fmicb.2021.678323">반응식</a>), Zeng & Zhang (2005, <a href="https://doi.org/10.1016/j.watres.2005.09.034">Monod 기준값</a>), Liu & Koenig (2002, <a href="https://doi.org/10.1016/S0032-9592(01)00302-8">pH 완충</a>), Plummer et al. (1978, <a href="https://doi.org/10.2475/ajs.278.2.179">방해석 용해</a>), Parkhurst & Appelo (2013, <a href="https://pubs.usgs.gov/tm/06/a43/">PHREEQC</a>)이다. 전체 서지와 사용 범위는 패키지의 두 방법·문헌 문서에 기록했다.</p></section>
<section><h2>실행과 입력</h2><pre>python -m pip install -r requirements-stage3.txt
python -m pytest -q tests
python run_environment_validation.py
python build_environment_report.py

python -m kjwp_stage1.geochemistry --config configs/environment/contact_3h.json --output environment_results/custom</pre><p>14개 JSON 입력, 각 조건의 전체 CSV·JSON, 검증 결과와 코드를 포함했다. 시작 안내는 STAGE3_README.md, 상세 설정은 docs/STAGE3_ENVIRONMENT.md에서 확인한다.</p><p class="small">Linux Python 3.12 실행 검증. Windows용 실행 스크립트는 포함하며 Windows에서의 실행 검증은 후속 확인이 필요하다.</p></section></main></body></html>'''
    (ROOT/'KJWP_Stage3_Report_20261107.html').write_text(report,encoding='utf-8')
    print('Environment report generated')


if __name__ == '__main__':
    main()
