@echo off
cd /d "%~dp0"
python -m pip install -e ".[geochemistry,test]"
if errorlevel 1 exit /b 1
python -m pytest -q
if errorlevel 1 exit /b 1
python run_stage4_validation.py
if errorlevel 1 exit /b 1
python -m kjwp_stage1.layout configs/stage5/base_sample.json configs/stage5/layout_sample.json --out stage5_results/sample --run
if errorlevel 1 exit /b 1
python build_stage4_5_report.py
pause
