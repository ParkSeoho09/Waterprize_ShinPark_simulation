"""Pressure-controlled subgrid spherical outlet with dilute carrier-water flow.

NOT a resolved pipe/nozzle model. Nozzle radius is an equivalent hydraulic
radius. Uniform isotropic local soil conductivity is required at each outlet.
Constitutive properties from particles are lagged one hydraulic step.
"""
from dataclasses import dataclass
import warnings
import numpy as np
from scipy.sparse import coo_matrix, diags
from scipy.sparse.linalg import spsolve, MatrixRankWarning
from .richards import RichardsFlow, WaterStep, FlowConvergenceError, divergence
from .hydraulics import VanGenuchten
from ..physics.boundary import FACES
from ..physics.particles import G

_GAUSS_X, _GAUSS_W = np.polynomial.legendre.leggauss(64)


@dataclass(frozen=True)
class PressurePort:
    position_m: tuple
    outlet_gauge_pressure_Pa: float
    equivalent_radius_m: float
    start_s: float = 0.
    end_s: float | None = None

    def __post_init__(self):
        if (len(self.position_m) != 3 or not np.all(np.isfinite(self.position_m))
                or not np.isfinite(self.outlet_gauge_pressure_Pa)
                or not np.isfinite(self.equivalent_radius_m) or self.equivalent_radius_m <= 0
                or not np.isfinite(self.start_s) or self.start_s < 0
                or (self.end_s is not None and
                    (not np.isfinite(self.end_s) or self.end_s <= self.start_s))):
            raise ValueError('invalid pressure outlet')

    def cell(self, grid):
        p = np.asarray(self.position_m)
        if np.any(p <= 0) or np.any(p >= grid.lengths_m):
            raise ValueError('pressure outlet must be strictly inside domain')
        # Whole equivalent sphere must fit inside the containing cell.
        ijk = np.floor(p/np.asarray(grid.spacing_xyz)).astype(int)
        local = p-ijk*np.asarray(grid.spacing_xyz)
        clearance = np.min(np.minimum(local, np.asarray(grid.spacing_xyz)-local))
        if self.equivalent_radius_m >= clearance:
            raise ValueError('equivalent outlet must fit inside its containing cell')
        return tuple(reversed(ijk))


class PressureFlow(RichardsFlow):
    def _relative_k_integral(self, lo, hi, idx):
        """Kirchhoff integral of kr between cell and outlet pressure heads.

        For radial, gravity-free steady flow with variable K(h), integrating
        kr(h) dh avoids treating the whole near-outlet shell as dry as its cell.
        This does not resolve transient near-outlet storage or anisotropy.
        """
        law=self.soil
        if isinstance(law,VanGenuchten):
            def local(v): return float(np.broadcast_to(v,self.grid.shape)[idx])
            law=VanGenuchten(local(law.theta_r),local(law.theta_s),
                             local(law.alpha_m_inv),local(law.n),1.,law.connectivity)
        if hi<=lo: return 0.
        negative_hi=min(hi,0.); negative_lo=min(lo,0.)
        half=.5*(negative_hi-negative_lo)
        samples=.5*(negative_hi+negative_lo)+half*_GAUSS_X
        negative=half*float(np.sum(_GAUSS_W*law.relative_k(samples))) if half>0 else 0.
        return negative+max(hi,0.)-max(lo,0.)

    def set_fluid(self, properties):
        self.mobility = np.broadcast_to(properties['carrier_mobility_ratio'], self.grid.shape)
        self.gravity = np.broadcast_to(properties['gravity_ratio'], self.grid.shape)
        if (np.any(self.mobility <= 0) or np.any(self.gravity <= 0)
                or not np.all(np.isfinite(self.mobility)) or not np.all(np.isfinite(self.gravity))):
            raise ValueError('invalid fluid properties')

    def faces_and_matrix(self, h, t):
        if not hasattr(self, 'mobility'):
            self.set_fluid(dict(carrier_mobility_ratio=1., gravity_ratio=1.))
        g = self.grid
        ids = np.arange(h.size).reshape(g.shape)
        diag = np.zeros(h.size); rows=[]; cols=[]; data=[]; allq=[]
        kr = np.broadcast_to(self.soil.relative_k(h), g.shape)
        for a, dx in enumerate(g.spacing_xyz):
            ax=2-a; v=np.moveaxis(h, ax, -1); ii=np.moveaxis(ids, ax, -1)
            k=np.moveaxis(self.ks[a]*kr*self.mobility, ax, -1)
            gr=np.moveaxis(self.gravity, ax, -1) if a==2 else np.zeros_like(v)
            kl, kh=k[...,:-1], k[...,1:]
            if self.face_mean=='harmonic':
                kf=np.divide(2*kl*kh, kl+kh, out=np.zeros_like(kl), where=(kl+kh)>0)
            else:
                kf=.5*(kl+kh)
            l=ii[...,:-1].ravel(); r=ii[...,1:].ravel(); c=(kf/dx**2).ravel()
            np.add.at(diag,l,c); np.add.at(diag,r,c)
            rows.extend((l,r)); cols.extend((r,l)); data.extend((-c,-c))
            q=np.zeros(v.shape[:-1]+(v.shape[-1]+1,))
            q[...,1:-1]=-kf*(np.diff(v,axis=-1)/dx-.5*(gr[...,:-1]+gr[...,1:]))
            for side, face, sign in ((0,FACES[2*a],-1),(-1,FACES[2*a+1],1)):
                b=self.boundaries[face]; kv=k[...,side]
                if b.kind=='head':
                    hb=b.at(t,v.shape[:-1]); he=v[...,side]
                    gradient=(he-hb)/(dx/2) if side==0 else (hb-he)/(dx/2)
                    q[...,side]=-kv*(gradient-gr[...,side])
                    np.add.at(diag,ii[...,side].ravel(),(2*kv/dx**2).ravel())
                elif b.kind=='flux': q[...,side]=sign*b.at(t,v.shape[:-1])
                elif b.kind=='free_drainage': q[...,side]=kv*gr[...,side]
            allq.append(np.moveaxis(q,-1,ax))
        rows.append(np.arange(h.size)); cols.append(np.arange(h.size)); data.append(diag)
        matrix=coo_matrix((np.concatenate(data),(np.concatenate(rows),np.concatenate(cols))),
                         shape=(h.size,h.size)).tocsr()
        return tuple(allq), matrix

    def port_sources(self, h, t, ports, slurry):
        """Carrier Q and frozen-Picard source derivative, injection-only valve."""
        g=self.grid; source=np.zeros(g.shape); diagonal=np.zeros(g.shape); rates=[]
        kr=np.broadcast_to(self.soil.relative_k(h),g.shape)
        inlet_mobility=(1-slurry.solid_volume_fraction)*slurry.carrier_viscosity_Pa_s/slurry.viscosity_Pa_s
        density_ratio=slurry.density_kg_m3/slurry.carrier_density_kg_m3
        re=(3*g.volume/(4*np.pi))**(1/3)
        for p in ports:
            idx=p.cell(g)
            if t < p.start_s or (p.end_s is not None and t >= p.end_s):
                rates.append(0.); continue
            ks=np.asarray([k[idx] for k in self.ks])
            if not np.allclose(ks,ks[0],rtol=1e-12,atol=0):
                raise ValueError('spherical outlet requires locally isotropic soil K')
            if p.equivalent_radius_m >= re:
                raise ValueError('outlet radius must be less than equivalent cell radius')
            zc=g.centers_xyz[2][idx[0]]
            outlet_head=p.outlet_gauge_pressure_Pa/(slurry.carrier_density_kg_m3*G)+density_ratio*(zc-p.position_m[2])
            drive=outlet_head-h[idx]
            geometric=4*np.pi*ks[0]*inlet_mobility/(1/p.equivalent_radius_m-1/re)
            conduct=geometric*kr[idx]
            q=geometric*self._relative_k_integral(float(h[idx]),outlet_head,idx)
            source[idx]+=q/g.volume
            if drive>0: diagonal[idx]+=conduct/g.volume
            rates.append(float(q))
        return source, diagonal, np.asarray(rates)

    def step_pressure(self, head, t, dt, ports, slurry):
        if not np.isfinite(dt) or dt<=0: raise ValueError('positive finite dt required')
        old=np.asarray(head,dtype=float)
        if old.shape!=self.grid.shape or not np.all(np.isfinite(old)):
            raise ValueError('invalid initial head')
        th0=self.theta(old); h=old.copy(); endpoint=np.nextafter(t+dt,t)

        def residual(trial):
            q,L=self.faces_and_matrix(trial,endpoint)
            src,diag,rates=self.port_sources(trial,endpoint,ports,slurry)
            r=self.theta(trial)-th0+dt*(divergence(q,self.grid)-src)
            return q,L,src,diag,rates,r

        for iteration in range(self.max_iterations+1):
            q,L,source,well_diag,rates,r=residual(h)
            error=float(np.max(np.abs(r)))
            if error<=self.theta_tolerance:
                water=WaterStep(h,th0,self.theta(h),q,source,iteration,error,
                                float(r.sum()*self.grid.volume))
                return water,rates
            if iteration==self.max_iterations: break
            cap=np.broadcast_to(self.soil.capacity(h),self.grid.shape)
            A=diags((cap+dt*well_diag).ravel())+dt*L
            with warnings.catch_warnings():
                warnings.simplefilter('error',MatrixRankWarning)
                try: delta=spsolve(A,-r.ravel()).reshape(h.shape)
                except (MatrixRankWarning,RuntimeError) as e:
                    raise FlowConvergenceError('singular pressure-flow iteration') from e
            if not np.all(np.isfinite(delta)): raise FlowConvergenceError('nonfinite correction')
            factor=min(1.,.5/max(float(np.max(np.abs(delta))),1e-30))
            accepted=False
            for _ in range(16):
                trial=h+factor*delta
                tr=residual(trial)[-1]
                if np.max(np.abs(tr))<error:
                    h=trial; accepted=True; break
                factor*=.5
            if not accepted: break
        raise FlowConvergenceError(f'pressure flow failed t={t:g}, dt={dt:g}, residual={error:g}')
