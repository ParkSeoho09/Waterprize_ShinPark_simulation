"""Mixed-form backward-Euler finite volumes, modified Picard, shared water faces.

z is positive down; q=-K (grad(h)-e_z). Rigid, isothermal, single water phase;
incompressible saturated limit, diagonal K aligned with the Cartesian grid.
Failure to converge is explicit; no water clipping or balance correction.
"""
from dataclasses import dataclass
import warnings
import numpy as np
from scipy.sparse import coo_matrix, diags
from scipy.sparse.linalg import spsolve, MatrixRankWarning
from ..physics.boundary import FACES


@dataclass(frozen=True)
class WaterBoundary:
    kind: str = 'closed'
    value: object = 0.  # head m OR outward water flux m/s; callable(t)->field allowed
    events: tuple = ()

    def __post_init__(self):
        if self.kind not in ('closed','head','flux','free_drainage'):
            raise ValueError('unsupported water boundary')

    def at(self,t,shape):
        v=self.value(t) if callable(self.value) else self.value
        a=np.broadcast_to(np.asarray(v,dtype=float),shape)
        if not np.all(np.isfinite(a)): raise ValueError('nonfinite water boundary')
        return a


def divergence(faces,grid):
    return sum(np.diff(f,axis=2-a)/grid.spacing_xyz[a] for a,f in enumerate(faces))


def boundary_water_rates(faces,grid):
    incoming=outgoing=0.
    for a,f in enumerate(faces):
        for side,sign in ((0,-1),(-1,1)):
            outward=sign*np.take(f,side,axis=2-a)*grid.face_area(a)
            incoming-=float(np.minimum(outward,0).sum())
            outgoing+=float(np.maximum(outward,0).sum())
    return incoming,outgoing


@dataclass
class WaterStep:
    head: np.ndarray
    theta_old: np.ndarray
    theta: np.ndarray
    fluxes: tuple
    source: np.ndarray
    iterations: int
    cell_balance_max: float  # dimensionless volume/soil volume per step
    net_balance_m3: float


class FlowConvergenceError(RuntimeError): pass


class RichardsFlow:
    def __init__(self,grid,soil,boundaries,*,face_mean='harmonic',theta_tolerance=1e-10,
                 max_iterations=100):
        if set(boundaries) != set(FACES): raise ValueError('all six water boundaries required')
        if any(b.kind=='free_drainage' and f!='z+' for f,b in boundaries.items()):
            raise ValueError('free drainage only supported on z+')
        if face_mean not in ('harmonic','arithmetic'): raise ValueError('invalid face mean')
        if not np.isfinite(theta_tolerance) or theta_tolerance<=0 or max_iterations<1:
            raise ValueError('invalid nonlinear controls')
        self.grid=grid;self.soil=soil;self.boundaries=boundaries;self.face_mean=face_mean
        self.theta_tolerance=theta_tolerance;self.max_iterations=max_iterations
        k=np.asarray(soil.ks_m_s,dtype=float)
        if k.shape==(3,):
            self.ks=tuple(np.full(grid.shape,v) for v in k)
        elif k.shape==(3,)+grid.shape:
            self.ks=tuple(k)
        else: self.ks=tuple(np.broadcast_to(k,grid.shape) for _ in range(3))
        if any(np.any(v<=0) or not np.all(np.isfinite(v)) for v in self.ks):
            raise ValueError('positive finite hydraulic conductivities required')

    def theta(self,h): return np.broadcast_to(self.soil.theta(h),self.grid.shape).copy()

    def faces_and_matrix(self,h,t):
        g=self.grid;ids=np.arange(h.size).reshape(g.shape)
        diag=np.zeros(h.size);rows=[];cols=[];data=[];allq=[]
        kr=np.broadcast_to(self.soil.relative_k(h),g.shape)
        for a,dx in enumerate(g.spacing_xyz):
            ax=2-a;v=np.moveaxis(h,ax,-1);ii=np.moveaxis(ids,ax,-1)
            k=np.moveaxis(self.ks[a]*kr,ax,-1)
            kl,kh=k[...,:-1],k[...,1:]
            if self.face_mean=='harmonic':
                kf=np.divide(2*kl*kh,kl+kh,out=np.zeros_like(kl),where=(kl+kh)>0)
            else: kf=.5*(kl+kh)
            conduct=kf/dx**2;l=ii[...,:-1].ravel();r=ii[...,1:].ravel();c=conduct.ravel()
            np.add.at(diag,l,c);np.add.at(diag,r,c)
            rows.extend((l,r));cols.extend((r,l));data.extend((-c,-c))
            gravity=float(a==2)
            q=np.zeros(v.shape[:-1]+(v.shape[-1]+1,))
            q[...,1:-1]=-kf*(np.diff(v,axis=-1)/dx-gravity)
            for side,face,sign in ((0,FACES[2*a],-1),(-1,FACES[2*a+1],1)):
                b=self.boundaries[face];kv=k[...,side]
                if b.kind=='head':
                    hb=b.at(t,v.shape[:-1]);he=v[...,side]
                    gradient=(he-hb)/(dx/2) if side==0 else (hb-he)/(dx/2)
                    q[...,side]=-kv*(gradient-gravity)
                    np.add.at(diag,ii[...,side].ravel(),(2*kv/dx**2).ravel())
                elif b.kind=='flux': q[...,side]=sign*b.at(t,v.shape[:-1])
                elif b.kind=='free_drainage': q[...,side]=kv
            allq.append(np.moveaxis(q,-1,ax))
        rows.append(np.arange(h.size));cols.append(np.arange(h.size));data.append(diag)
        matrix=coo_matrix((np.concatenate(data),(np.concatenate(rows),np.concatenate(cols))),
                          shape=(h.size,h.size)).tocsr()
        return tuple(allq),matrix

    def step(self,head,t,dt,source=None):
        if not np.isfinite(dt) or dt<=0: raise ValueError('positive finite dt required')
        old=np.asarray(head,dtype=float)
        if old.shape!=self.grid.shape or not np.all(np.isfinite(old)):
            raise ValueError('invalid initial pressure head')
        source=np.broadcast_to(0. if source is None else source,self.grid.shape).copy()
        if not np.all(np.isfinite(source)): raise ValueError('invalid water source')
        th0=self.theta(old);h=old.copy();endpoint=np.nextafter(t+dt,t)
        for iteration in range(self.max_iterations+1):
            q,L=self.faces_and_matrix(h,endpoint)
            r=self.theta(h)-th0+dt*(divergence(q,self.grid)-source)
            error=float(np.max(np.abs(r)))
            if error<=self.theta_tolerance:
                return WaterStep(h,th0,self.theta(h),q,source,iteration,error,
                                 float(r.sum()*self.grid.volume))
            if iteration==self.max_iterations: break
            cap=np.broadcast_to(self.soil.capacity(h),self.grid.shape)
            A=diags(cap.ravel())+dt*L
            with warnings.catch_warnings():
                warnings.simplefilter('error',MatrixRankWarning)
                try: delta=spsolve(A,-r.ravel()).reshape(h.shape)
                except (MatrixRankWarning,RuntimeError) as e:
                    raise FlowConvergenceError('singular mixed-form iteration') from e
            if not np.all(np.isfinite(delta)): raise FlowConvergenceError('nonfinite head correction')
            factor=min(1.,.5/max(float(np.max(np.abs(delta))),1e-30))
            accepted=False
            for _ in range(12):
                trial=h+factor*delta
                tq,_=self.faces_and_matrix(trial,endpoint)
                tr=self.theta(trial)-th0+dt*(divergence(tq,self.grid)-source)
                if np.max(np.abs(tr))<error:
                    h=trial;accepted=True;break
                factor*=.5
            if not accepted: break
        raise FlowConvergenceError(f'Richards iteration failed at t={t:g}, dt={dt:g}, residual={error:g}')
