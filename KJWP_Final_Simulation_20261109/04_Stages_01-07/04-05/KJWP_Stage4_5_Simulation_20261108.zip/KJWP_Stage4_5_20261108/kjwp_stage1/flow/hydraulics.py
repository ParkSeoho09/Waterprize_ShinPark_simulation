"""SI soil constitutive laws. Arrays are broadcast onto [z,y,x] by RichardsFlow.

These are parameterized hypotheses, not site-calibrated soil properties.
VG-Mualem: van Genuchten (1980); Haverkamp law only for Celia benchmark.
"""
from dataclasses import dataclass
import numpy as np


@dataclass(frozen=True)
class VanGenuchten:
    theta_r: object
    theta_s: object
    alpha_m_inv: object
    n: object
    ks_m_s: object
    connectivity: float = .5

    def __post_init__(self):
        r,s,a,n=np.broadcast_arrays(self.theta_r,self.theta_s,self.alpha_m_inv,self.n)
        if (not all(np.all(np.isfinite(v)) for v in (r,s,a,n,np.asarray(self.ks_m_s)))
                or np.any(r < 0) or np.any(s <= r) or np.any(s > 1)
                or np.any(a <= 0) or np.any(n <= 1) or np.any(np.asarray(self.ks_m_s) <= 0)
                or not np.isfinite(self.connectivity) or self.connectivity < 0):
            raise ValueError('invalid VG-Mualem parameters (connectivity >= 0 supported)')

    def theta(self,h):
        m=1-1/np.asarray(self.n)
        se=(1+(np.asarray(self.alpha_m_inv)*np.maximum(-h,0))**self.n)**(-m)
        return np.asarray(self.theta_r)+(np.asarray(self.theta_s)-self.theta_r)*se

    def capacity(self,h):
        a=np.asarray(self.alpha_m_inv); n=np.asarray(self.n); m=1-1/n
        x=a*np.maximum(-h,0)
        return np.where(h < 0,(np.asarray(self.theta_s)-self.theta_r)*m*n*a*x**(n-1)
                        *(1+x**n)**(-m-1),0.)

    def relative_k(self,h):
        n=np.asarray(self.n); m=1-1/n
        se=(1+(np.asarray(self.alpha_m_inv)*np.maximum(-h,0))**n)**(-m)
        return se**self.connectivity*(1-(1-se**(1/m))**m)**2


@dataclass(frozen=True)
class CeliaHaverkamp:
    """Celia et al. 1990 / Ireson et al. 2023 test parameters, converted to SI.

    Empirical powers in the published law use pressure head in cm.
    """
    theta_r: float = .075
    theta_s: float = .287
    ks_m_s: float = .00944/100
    alpha: float = 1.611e6
    beta: float = 3.96
    a_k: float = 1.175e6
    gamma: float = 4.74

    def theta(self,h):
        x=100*np.maximum(-h,0)
        return self.theta_r+(self.theta_s-self.theta_r)*self.alpha/(self.alpha+x**self.beta)

    def capacity(self,h):
        x=100*np.maximum(-h,0)
        return np.where(h < 0,100*(self.theta_s-self.theta_r)*self.alpha*self.beta
                        *x**(self.beta-1)/(self.alpha+x**self.beta)**2,0.)

    def relative_k(self,h):
        return self.a_k/(self.a_k+(100*np.maximum(-h,0))**self.gamma)

    def head_from_theta(self,theta):
        y=(theta-self.theta_r)/(self.theta_s-self.theta_r)
        if np.any(y <= 0) or np.any(y >= 1):
            raise ValueError('benchmark inverse requires theta strictly inside retention range')
        return -(self.alpha*(1/y-1))**(1/self.beta)/100
