"""Prescribed environmental exposure for a single Stage 3 water parcel.

The schedule is right-continuous. Oxygen values are external forcing, with an
explicitly supplied, uncalibrated inhibition coefficient. Contact history and
effective activity can later be supplied by transport or measured data.
"""
from dataclasses import dataclass
from bisect import bisect_right
import math


@dataclass(frozen=True)
class EnvironmentPeriod:
    start_hour: float = 0.0
    dissolved_oxygen_mg_L: float = 0.0
    active_fraction: float = 1.0
    in_contact: bool = True

    def validate(self):
        for name in ('start_hour', 'dissolved_oxygen_mg_L', 'active_fraction'):
            value = getattr(self, name)
            if isinstance(value, bool) or not isinstance(value, (int, float)):
                raise ValueError(f'{name} must be a number')
            if not math.isfinite(value) or value < 0:
                raise ValueError(f'{name} must be finite and nonnegative')
        if self.active_fraction > 1:
            raise ValueError('active_fraction must lie between 0 and 1')
        if type(self.in_contact) is not bool:
            raise ValueError('in_contact must be a JSON boolean')


def oxygen_factor(dissolved_oxygen_mg_L, half_inhibition_mg_L):
    """Screening law KI/(KI+DO). KI is a scenario/calibration input."""
    if dissolved_oxygen_mg_L == 0:
        return 1.0
    if half_inhibition_mg_L is None:
        raise ValueError('Positive DO requires oxygen_half_inhibition_mg_L')
    return half_inhibition_mg_L / (half_inhibition_mg_L + dissolved_oxygen_mg_L)


class ExposureSchedule:
    def __init__(self, periods, duration_hours, half_inhibition_mg_L, lag_hours):
        self.periods = tuple(
            item if isinstance(item, EnvironmentPeriod) else EnvironmentPeriod(**item)
            for item in periods
        ) or (EnvironmentPeriod(),)
        self.half_inhibition_mg_L = half_inhibition_mg_L
        self.lag_hours = lag_hours
        for name, value in [('microbial_lag_hours', lag_hours),
                            ('oxygen_half_inhibition_mg_L', half_inhibition_mg_L)]:
            if value is not None and (isinstance(value, bool) or
                    not isinstance(value, (float, int)) or not math.isfinite(value) or value < 0):
                raise ValueError(f'{name} must be finite and nonnegative')
        if half_inhibition_mg_L == 0:
            raise ValueError('oxygen_half_inhibition_mg_L must be positive')
        if lag_hours is None:
            raise ValueError('microbial_lag_hours must be a nonnegative number')
        for period in self.periods:
            period.validate()
            oxygen_factor(period.dissolved_oxygen_mg_L, half_inhibition_mg_L)
        self.starts = [period.start_hour for period in self.periods]
        if self.starts[0] != 0:
            raise ValueError('Environment schedule must begin at hour 0')
        if any(b <= a for a, b in zip(self.starts, self.starts[1:])):
            raise ValueError('Environment start_hour values must strictly increase')
        if self.starts[-1] >= duration_hours:
            raise ValueError('Every environment start_hour must precede simulation end')
        self.boundaries = sorted(set(self.starts + [duration_hours] +
                                     ([lag_hours] if 0 < lag_hours < duration_hours else [])))

    def state(self, hour):
        period = self.periods[bisect_right(self.starts, hour) - 1]
        activity = period.active_fraction if hour >= self.lag_hours else 0.0
        factor = oxygen_factor(period.dissolved_oxygen_mg_L, self.half_inhibition_mg_L)
        return {
            'dissolved_oxygen_mg_L': period.dissolved_oxygen_mg_L,
            'active_fraction': activity,
            'in_contact': period.in_contact,
            'oxygen_factor': factor,
        }

    def cumulative_hours(self, hour):
        contact = 0.0
        weighted = 0.0
        for start, stop in zip(self.boundaries, self.boundaries[1:]):
            duration = max(0.0, min(hour, stop) - start)
            environment = self.state((start + stop) / 2)
            if environment['in_contact']:
                contact += duration
                weighted += duration * environment['active_fraction'] * environment['oxygen_factor']
        return contact, weighted
