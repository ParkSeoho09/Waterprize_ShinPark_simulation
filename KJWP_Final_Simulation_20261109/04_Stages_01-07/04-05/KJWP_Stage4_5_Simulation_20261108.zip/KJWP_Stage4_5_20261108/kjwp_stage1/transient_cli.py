"""JSON entry point for spec 3.1 transient flow and dissolved tracers.

All physical inputs are SI. NO3 concentration means kg NO3/m3 water.
Examples are synthetic and are not site calibration or denitrification.
"""
import argparse
import csv
import hashlib
import json
import platform
from pathlib import Path
import numpy as np
import scipy
from . import __version__
from .core.grid import Grid
from .flow.hydraulics import VanGenuchten
from .flow.richards import RichardsFlow,WaterBoundary
from .physics.boundary import Boundary,FACES
from .physics.injection import Injection
from .numerics.transient import solve_transient


def keys(d,allowed,required=()):
    if not isinstance(d,dict) or set(d)-set(allowed) or set(required)-set(d):
        raise ValueError(f'configuration keys mismatch: allowed={allowed}, required={required}')


def water_boundary(d):
    keys(d,('kind','value','schedule'),('kind',))
    if 'schedule' not in d: return WaterBoundary(d['kind'],d.get('value',0.))
    if 'value' in d or d['kind'] not in ('head','flux'): raise ValueError('schedule requires head/flux and no value')
    a=np.array(d['schedule'],dtype=float)
    if a.ndim!=2 or a.shape[1]!=2 or len(a)<1 or not np.all(np.isfinite(a)) or a[0,0]!=0 or np.any(np.diff(a[:,0])<=0):
        raise ValueError('schedule needs increasing [time_s,value] pairs, starting at 0')
    def at(t): return float(a[np.searchsorted(a[:,0],t,side='right')-1,1])
    return WaterBoundary(d['kind'],at,tuple(a[1:,0]))


def build(config):
    keys(config,('schema_version','nitrate_basis','concentration_unit','grid','soil','initial_head_m',
         'water_boundaries','initial_kg_m3','solute_boundaries','injections','time','dispersion_m2_s','note','transport_scheme'),
         ('schema_version','nitrate_basis','concentration_unit','grid','soil','initial_head_m','water_boundaries',
          'initial_kg_m3','time'))
    if config['schema_version']!='transient-3.1' or config['nitrate_basis']!='NO3' or config['concentration_unit']!='kg/m3 water':
        raise ValueError('schema transient-3.1, nitrate_basis NO3, concentration_unit kg/m3 water required')
    keys(config['grid'],('lengths_m','cells_xyz'),('lengths_m','cells_xyz'))
    g=Grid(tuple(config['grid']['lengths_m']),tuple(config['grid']['cells_xyz']))
    soil_args=dict(config['soil'])
    keys(soil_args,('theta_r','theta_s','alpha_m_inv','n','ks_m_s','connectivity'),('theta_r','theta_s','alpha_m_inv','n','ks_m_s'))
    # Full [z,y,x] fields are accepted for retention and K; 3-vector K is axis aligned.
    for k in ('theta_r','theta_s','alpha_m_inv','n','ks_m_s'): soil_args[k]=np.asarray(soil_args[k],dtype=float)
    soil=VanGenuchten(**soil_args)
    keys(config['water_boundaries'],FACES,FACES)
    wb={f:water_boundary(config['water_boundaries'][f]) for f in FACES}
    flow=RichardsFlow(g,soil,wb)
    init=config['initial_head_m']
    if isinstance(init,dict):
        keys(init,('hydrostatic_surface_head_m',),('hydrostatic_surface_head_m',))
        z,_,_=g.mesh_zyx();h=z+float(init['hydrostatic_surface_head_m'])
    else: h=np.broadcast_to(np.asarray(init,dtype=float),g.shape).copy()
    initial={s:np.broadcast_to(np.asarray(v,dtype=float),g.shape).copy() for s,v in config['initial_kg_m3'].items()}
    if not initial or any(not s.isidentifier() for s in initial): raise ValueError('species must be valid identifiers')
    sb=None
    if 'solute_boundaries' in config:
        keys(config['solute_boundaries'],tuple(initial),tuple(initial));sb={}
        for s,bs in config['solute_boundaries'].items():
            keys(bs,FACES,FACES);sb[s]={}
            for f,b in bs.items():
                keys(b,('kind','concentration_kg_m3','pulse_start_s','pulse_end_s','patch_m'),('kind',))
                sb[s][f]=Boundary(**b)
    injections=[]
    for d in config.get('injections',[]):
        keys(d,('position_m','rate_m3_s','start_s','end_s','concentrations_kg_m3','radius_m'),
             ('position_m','rate_m3_s','start_s','end_s'))
        injections.append(Injection(**d))
    tc=config['time'];keys(tc,('end_s','max_dt_s','save_times_s'),('end_s','max_dt_s','save_times_s'))
    return flow,h,initial,dict(**tc,dispersion_m2_s=config.get('dispersion_m2_s',(0.,0.,0.)),
                              solute_boundaries=sb,injections=injections,transport_scheme=config.get('transport_scheme','muscl_mc'))


def flatten(row):
    out={}
    for k,v in row.items():
        if isinstance(v,dict): out.update({k+'_'+kk:vv for kk,vv in v.items()})
        else: out[k]=v
    return out


def write_outputs(result,grid,config,out):
    out.mkdir(parents=True,exist_ok=True)
    np.savez_compressed(out/'fields.npz',time_s=result.times_s,head_m=result.head_m,theta=result.theta,
                        **{'C_'+s:v for s,v in result.concentration.items()},
                        **{a+'_m':v for a,v in zip('xyz',grid.centers_xyz)})
    rows=[flatten(x) for x in result.history]
    with (out/'history.csv').open('w',newline='',encoding='utf-8') as fp:
        w=csv.DictWriter(fp,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
    with (out/'resident_btc.csv').open('w',newline='',encoding='utf-8') as fp:
        w=csv.writer(fp);w.writerow(['time_s','depth_m','species','resident_kg_m3_water'])
        for k,t in enumerate(result.times_s):
            th=result.theta[k]
            for s,c in result.concentration.items():
                btc=(th*c[k]).sum(axis=(1,2))/th.sum(axis=(1,2))
                for z,v in zip(grid.centers_xyz[2],btc): w.writerow([t,z,s,v])
    package=Path(__file__).parent
    hashes={str(p.relative_to(package)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(package.rglob('*.py'))}
    metadata=dict(result.metadata,version=__version__,python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__,
        input=config,code_sha256=hashes,final_budget=result.history[-1],
        warning='Synthetic numerical example. No reaction, sulfur particles, field calibration, OGS validation, or final UI.',
        bottom_flux_time_semantics='history bottom flux is backward-Euler accepted-step average, zero at initial row')
    (out/'run.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2),encoding='utf-8')
    plot(result,grid,out)


def plot(r,g,out):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    variables=[('Water content',r.theta,1.)]+[(s+' (mg/L)',v,1000.) for s,v in r.concentration.items()]
    picks=sorted(set((0,len(r.times_s)//2,len(r.times_s)-1)))
    fig,axes=plt.subplots(len(variables),len(picks),figsize=(4.3*len(picks),3.4*len(variables)),squeeze=False,constrained_layout=True)
    fig.suptitle(f'Synthetic calculation; x-z slice at y={g.centers_xyz[1][g.shape[1]//2]:g} m; no reaction',fontsize=12)
    for i,(label,arr,factor) in enumerate(variables):
        vals=arr*factor;lo=float(vals.min());hi=float(vals.max())
        if hi==lo: hi=lo+1e-12
        for j,k in enumerate(picks):
            ax=axes[i,j];im=ax.imshow(vals[k,:,g.shape[1]//2,:],extent=(0,g.lengths_m[0],g.lengths_m[2],0),
                origin='upper',aspect='auto',vmin=lo,vmax=hi,cmap='viridis')
            ax.set(title=f'{label}, t={r.times_s[k]:g} s',xlabel='x (m)',ylabel='depth z (m)')
            fig.colorbar(im,ax=ax,shrink=.8)
    fig.savefig(out/'slices.png',dpi=140);plt.close(fig)


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('config');p.add_argument('--out',required=True)
    a=p.parse_args();config=json.loads(Path(a.config).read_text(encoding='utf-8'))
    f,h,c,args=build(config);r=solve_transient(f,h,c,**args);write_outputs(r,f.grid,config,Path(a.out))
    print(json.dumps(dict(steps=r.metadata['steps'],rejected_steps=r.metadata['rejected_water_steps'],
        final_budget=r.history[-1]),ensure_ascii=False,indent=2))


if __name__=='__main__': main()
