"""Stage 4 conservative component transport + PHREEQC kinetics.
First-order transport/reaction splitting. Fixed-water dilute reactions.
"""
from dataclasses import replace
from functools import lru_cache
import argparse,json,time
from pathlib import Path
import numpy as np
from scipy.integrate import solve_ivp
from . import stage2
from .geochemistry import (BatchConfig,Speciation,MW_NO3,MW_N,MW_S,MW_SO4,MW_CA,MW_CALCITE,monod_rate_mg_N_day,calcite_rate_mol_day)
from .reaction_environment import ExposureSchedule
from .physics.boundary import Boundary,FACES
from .numerics.transient_muscl import transport_muscl
MW={'NO3':MW_NO3,'SO4':MW_SO4,'Ca':MW_CA,'DIC':12.0107,'Na':22.98976928,'Cl':35.453,'sulfur':MW_S,'caco3':MW_CALCITE}
EXTRA=('SO4','Ca','DIC','Na','Cl','NO3_passive')

class CellReaction:
    """Two mol/kg-water reaction extents; fixed transported Na and Cl."""
    def __init__(self,config):
        self.c=config;self.speciation=Speciation();self.max_projection_mol_kgw=0.;self.nfev=0
    @lru_cache(maxsize=16384)
    def spec(self,nitrate,sulfate,calcium,dic,sodium,chloride):
        return self.speciation.calculate(replace(self.c,chloride_mol_per_kgw=chloride),nitrate,sulfate,calcium,dic,sodium)
    def advance(self,components,sulfur,calcite,dt_s,environment,biomass_mg_kgw,area_reference=None):
        n,so,ca,dic,na,cl=map(float,components)
        if min(n,so,ca,dic,na,cl,sulfur,calcite)<0:raise ValueError('Negative chemical inventory')
        limits=np.array([min(n,sulfur*6/5),calcite])
        if not self.c.reactions_enabled or not environment['in_contact'] or not np.any(limits):return np.zeros(2)
        c=replace(self.c,biomass_mg_VSS_per_kgw=float(biomass_mg_kgw))
        ref=calcite if area_reference is None else area_reference
        threshold=np.minimum(limits/100,c.depletion_tolerance_mol);active=limits>1e-14
        if environment['active_fraction']==0 or c.k_per_day==0:active[0]=False
        if not np.any(active):return np.zeros(2)
        def rhs(t,y):
            xi,eta=np.clip(y,0,limits);sp=self.spec(n-xi,so+5/6*xi,ca+eta,dic+eta,na,cl)
            fph=np.clip((sp['pH']-c.pH_stop)/(c.pH_full-c.pH_stop),0,1) if c.pH_inhibition else 1.
            rn=monod_rate_mg_N_day((n-xi)*MW_N*1000,c,c.kinetic_volume_L_per_kgw or sp['volume_L'])/(MW_N*1000)
            rn*=fph*environment['active_fraction']*environment['oxygen_factor']
            rc=calcite_rate_mol_day(c,calcite-eta,ref,sp)
            return [rn if active[0] else 0.,rc if active[1] else 0.]
        start=0.;stop=dt_s/86400;state=np.zeros(2)
        for _ in range(3):
            ids=np.flatnonzero(active);events=[]
            for i in ids:
                def event(t,y,i=i):return limits[i]-y[i]-threshold[i]
                event.terminal=True;event.direction=-1;events.append(event)
            sol=solve_ivp(rhs,(start,stop),state,method='BDF',rtol=c.rtol,atol=c.atol_mol,max_step=min(c.max_step_days,stop),events=events)
            if not sol.success:raise RuntimeError(sol.message)
            self.nfev+=sol.nfev;state=sol.y[:,-1];start=sol.t[-1]
            if sol.status!=1:break
            hit=next(i for i,e in zip(ids,sol.t_events) if len(e));active[hit]=False
            if start>=stop:break
        else:raise RuntimeError('Inventory event restart limit')
        projection=float(np.max(np.abs(state-np.clip(state,0,limits))))
        self.max_projection_mol_kgw=max(self.max_projection_mol_kgw,projection)
        if projection>max(100*c.atol_mol,1e-10):raise RuntimeError('Reaction overshoot')
        return np.clip(state,0,limits)

class ReactiveCoupling:
    def __init__(self,config):
        kw=dict(config.get('chemistry',{}).get('batch',{}))
        kw.setdefault('duration_days',float(config['end_s'])/86400);kw.setdefault('calcite_area_model','fixed_specific_area')
        if kw['calcite_area_model']!='fixed_specific_area':raise ValueError('Arriving particles require fixed_specific_area closure')
        self.batch=BatchConfig(**kw);self.batch.validate();self.cell=CellReaction(self.batch)
        self.schedule=ExposureSchedule(self.batch.environment_periods,config['end_s']/3600,self.batch.oxygen_half_inhibition_mg_L,self.batch.microbial_lag_hours)
        self.net_generated={s:0. for s in stage2.SPECIES+EXTRA};self.reacted_no3_kg=0.;self.calcite_dissolved_kg=0.;self.reaction_calls=0
    def events(self,end):return [h*3600 for h in self.schedule.boundaries if 0<=h*3600<=end]
    def solution(self,no3):
        c=self.batch;rho=self.rho;n=no3/(rho*MW_NO3/1000)
        sp=self.cell.speciation.calculate(c,n,c.sulfate_mol_per_kgw,c.calcium_mol_per_kgw,c.dic_mol_per_kgw)
        return dict(SO4=c.sulfate_mol_per_kgw*MW_SO4/1000*rho,Ca=c.calcium_mol_per_kgw*MW_CA/1000*rho,DIC=c.dic_mol_per_kgw*MW['DIC']/1000*rho,Na=sp['Na']*MW['Na']/1000*rho,Cl=c.chloride_mol_per_kgw*MW['Cl']/1000*rho,NO3_passive=no3)
    def initialize(self,g,theta,c,attached,strained,slurry,cfg,inlet,cb,wb):
        self.g=g;self.rho=slurry.carrier_density_kg_m3
        if slurry.temperature_C!=self.batch.temperature_C:raise ValueError('Slurry temperature must match chemistry temperature')
        if not np.isclose(slurry.caco3_density_kg_m3,self.batch.calcite_density_kg_m3):raise ValueError('Calcite density mismatch')
        if not np.isclose(slurry.caco3_diameter_m,self.batch.calcite_diameter_m,rtol=1e-10,atol=0):raise ValueError('Calcite diameter mismatch')
        self.biomass_bulk=theta*self.rho*self.batch.biomass_mg_VSS_per_kgw
        for s in EXTRA:c[s]=np.empty(g.shape)
        for value in np.unique(c['NO3']):
            sol=self.solution(float(value));mask=c['NO3']==value
            for s in EXTRA:c[s][mask]=sol[s]
        inlet.update(self.solution(inlet['NO3']))
        for s in EXTRA:cb[s]={}
        for f in FACES:
            sol=self.solution(float(cb['NO3'][f].concentration_kg_m3))
            for s in EXTRA:cb[s][f]=Boundary(cb['NO3'][f].kind,sol[s])
        for s in ('sulfur','caco3'):
            for pool,key in ((attached,'initial_attached_kg_m3_soil'),(strained,'initial_strained_kg_m3_soil')):
                arr=np.broadcast_to(cfg.get(key,{}).get(s,0.),g.shape).copy()
                if not np.all(np.isfinite(arr)) or np.any(arr<0):raise ValueError('Invalid retained inventory')
                pool[s][:]=arr
        self.contact_time=np.zeros(g.shape);self.age=np.zeros(g.shape);self.exposure=np.zeros(g.shape)
        self.moment_budgets={k:dict(in_kg_s=0.,out_kg_s=0.,source_kg_s=0.) for k in ('age','exposure')}
        self.local_reacted=np.zeros(g.shape);self.port_water_m3=np.zeros(len(cfg['ports']));self.start_time=time.perf_counter()
        return EXTRA
    def advance(self,water,old,new,attached,strained,t,dt,dispersion,cb):
        theta=water.theta;g=self.g;rho=self.rho;env=self.schedule.state((t+dt/2)/3600)
        solid={s:theta*new[s]+attached[s]+strained[s] for s in ('sulfur','caco3')}
        contact=((solid['sulfur']+solid['caco3'])>1e-10)&env['in_contact']
        self.contact_time+=dt*contact
        b={f:Boundary(cb['tracer'][f].kind,0.) for f in FACES}
        for name in ('age','exposure'):
            value,budget=transport_muscl(g,water,getattr(self,name),dt,dispersion,b,t+dt,np.zeros(g.shape))
            source=theta*new['tracer']*dt*(contact if name=='exposure' else 1.)
            value+=source/theta;setattr(self,name,value);ledger=self.moment_budgets[name]
            ledger['in_kg_s']+=budget['in_kg']+budget['source_in_kg'];ledger['out_kg_s']+=budget['out_kg']+budget['source_out_kg'];ledger['source_kg_s']+=float(source.sum()*g.volume)
        if not self.batch.reactions_enabled:return
        kgwater=theta*rho*g.volume;names=('NO3','SO4','Ca','DIC','Na','Cl')
        comps={s:new[s]/(rho*MW[s]/1000) for s in names}
        sulfur=solid['sulfur']/(theta*rho*MW_S/1000);calcite=solid['caco3']/(theta*rho*MW_CALCITE/1000)
        cache={};ext=np.zeros(g.shape+(2,))
        for idx in np.ndindex(g.shape):
            if max(sulfur[idx],calcite[idx])<=1e-14:continue
            state=tuple(float(comps[s][idx]) for s in names);x=float(self.biomass_bulk[idx]/(theta[idx]*rho))
            key=state+(float(sulfur[idx]),float(calcite[idx]),x)
            if key not in cache:
                cache[key]=self.cell.advance(state,sulfur[idx],calcite[idx],dt,env,x);self.reaction_calls+=1
            ext[idx]=cache[key]
        xi=ext[...,0];eta=ext[...,1]
        for s,moles in {'NO3':-xi,'SO4':5/6*xi,'Ca':eta,'DIC':eta}.items():
            new[s]+=moles*(rho*MW[s]/1000);self.net_generated[s]+=float(np.sum(moles*kgwater)*MW[s]/1000)
        for s,consumed in (('sulfur',5/6*xi),('caco3',eta)):
            used=consumed*(theta*rho*MW[s]/1000);f=np.divide(used,solid[s],out=np.zeros(g.shape),where=solid[s]>0)
            if np.any(f>1+1e-10):raise RuntimeError('Solid consumption exceeds inventory')
            f=np.minimum(f,1.);new[s]*=(1-f);attached[s]*=(1-f);strained[s]*=(1-f)
            self.net_generated[s]-=float(used.sum()*g.volume)
        self.local_reacted+=xi*kgwater*MW_NO3/1000;self.reacted_no3_kg+=float(np.sum(xi*kgwater)*MW_NO3/1000)
        self.calcite_dissolved_kg+=float(np.sum(eta*kgwater)*MW_CALCITE/1000)
    def accept_ports(self,rates,dt):
        if len(rates):self.port_water_m3+=np.asarray(rates)*dt
    def record(self,theta,c):
        row={'NO3_reacted_kg':self.reacted_no3_kg,'CaCO3_dissolved_kg':self.calcite_dissolved_kg,'N2_produced_mol':self.reacted_no3_kg/(MW_NO3/1000)/2}
        for i,v in enumerate(self.port_water_m3):row[f'port_{i+1}_water_m3']=float(v)
        for s,v in self.net_generated.items():row[s+'_reaction_net_kg']=v
        for name in ('age','exposure'):
            b=self.moment_budgets[name];stored=float(np.sum(theta*getattr(self,name))*self.g.volume)
            row[name+'_moment_residual_kg_s']=stored-b['in_kg_s']+b['out_kg_s']-b['source_kg_s']
        return row
    def snapshot(self,theta,c):
        ph=np.zeros(self.g.shape);alk=np.zeros(self.g.shape)
        for idx in np.ndindex(self.g.shape):
            vals=tuple(float(c[s][idx]/(self.rho*MW[s]/1000)) for s in ('NO3','SO4','Ca','DIC','Na','Cl'))
            sp=self.cell.spec(*vals);ph[idx]=sp['pH'];alk[idx]=sp['alk']
        ratio=lambda v:np.divide(v,c['tracer'],out=np.zeros_like(v),where=c['tracer']>1e-12)/3600
        return dict(pH=ph,alk_mol_kgw=alk,NO3_reacted_kg_cell=self.local_reacted.copy(),reagent_presence_hours=self.contact_time/3600,
          injected_tracer_mean_age_h=ratio(self.age),injected_tracer_mean_exposure_h=ratio(self.exposure),tracer_age_moment_kg_s_m3=self.age.copy(),tracer_exposure_moment_kg_s_m3=self.exposure.copy())
    def summary(self):
        return dict(model='stage4_component_transport_phreeqc_v0.5.0',chemistry_enabled=self.batch.reactions_enabled,denitrification_removed_kg=self.reacted_no3_kg,
          splitting='first_order_transport_then_reaction',calcite_area_model=self.batch.calcite_area_model,reaction_cell_integrations=self.reaction_calls,
          phreeqc_calls=self.cell.speciation.calls,database_sha256=self.cell.speciation.database_sha256,elapsed_s=time.perf_counter()-self.start_time,
          port_water_m3=self.port_water_m3.tolist(),max_reaction_projection_mol_kgw=self.cell.max_projection_mol_kgw,
          limitations=['scenario; not calibrated or whole-reactive-system OGS/experiment validated','oxygen/activity/lag prescribed; no oxygen transport/consumption or biomass growth',
            'biomass fixed per bulk soil; water content changes biomass per kg water','fixed effective specific surface and proportional accessibility of mobile/retained particles',
            'common component dispersion; no electrodiffusion or gases','N2 ledger only, no NO2/N2O/nitrification/biomass assimilation',
            'dissolution only; local fixed-water reaction, no porosity feedback','age/exposure moments are first-order cell-mixing diagnostics, not pore RTD',
            'reaction capacities <=1e-14 mol/kgw left unchanged; no inventory deleted','Stage2 outlet/rheology/retention assumptions remain',
            'no pipe-wall cut cells or internal pipe hydraulic losses'])

def solve(config,output=None,progress=None):return stage2.solve(config,output,progress,ReactiveCoupling(config))
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('config');p.add_argument('--out',required=True);a=p.parse_args()
    r=solve(json.loads(Path(a.config).read_text()),a.out,lambda v:print(json.dumps(v),flush=True));print(json.dumps(r['summary'],indent=2))
if __name__=='__main__':main()
