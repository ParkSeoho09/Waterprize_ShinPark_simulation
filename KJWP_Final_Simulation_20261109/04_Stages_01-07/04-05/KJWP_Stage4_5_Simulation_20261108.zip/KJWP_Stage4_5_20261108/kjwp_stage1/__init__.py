"""Research prototype: verified constant flow plus transient flow and tracers."""
__version__ = "0.5.1"
