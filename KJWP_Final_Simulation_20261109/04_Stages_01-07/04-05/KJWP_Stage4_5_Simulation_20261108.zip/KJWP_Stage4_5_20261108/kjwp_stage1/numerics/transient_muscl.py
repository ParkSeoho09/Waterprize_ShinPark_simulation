"""Conservative MUSCL/SSPRK2 transport over a backward-Euler water step.

Water flux is frozen over the accepted water interval; theta is interpolated
linearly between its conservative endpoints. Mass theta*C is the RK variable.
This improves solute accuracy but does NOT make the coupled water solve order 2.
"""
import numpy as np
from .fv import mc_slopes
from ..flow.richards import divergence
from ..physics.boundary import FACES


def transport_muscl(grid,water,old,dt,dispersion,boundaries,t,source_mass):
    if set(boundaries)!=set(FACES) or any(b.kind not in ('closed','dirichlet','inflow_flux','outflow') for b in boundaries.values()):
        raise ValueError('MUSCL transient backend requires six supported nonperiodic boundaries')
    old=np.asarray(old,dtype=float)
    if old.shape!=grid.shape or np.any(old<0) or not np.all(np.isfinite(old)):
        raise ValueError('invalid old concentration')
    thmin=np.minimum(water.theta_old,water.theta);thmax=np.maximum(water.theta_old,water.theta)
    if np.any(thmin<=0): raise ValueError('positive water content required for transport')
    loss=np.maximum(-water.source,0.).copy()
    for a,(dx,D,q0) in enumerate(zip(grid.spacing_xyz,dispersion,water.fluxes)):
        if not np.isfinite(D) or D<0: raise ValueError('finite nonnegative diagonal dispersion required')
        ax=2-a;q=np.moveaxis(q0,ax,-1)
        adv=2*(np.maximum(q[...,1:],0.)+np.maximum(-q[...,:-1],0.))/dx
        loss+=np.moveaxis(adv,-1,ax)
        # Upper bound includes half-cell Dirichlet faces and variable theta.
        loss+=4*float(thmax.max())*D/dx**2
    rate=float(np.max(loss/thmin));nsub=max(1,int(np.ceil(dt*rate/.4)))
    if nsub>100000: raise RuntimeError('transport substep limit exceeded')
    ds=dt/nsub;mass=water.theta_old*old;initial_mass=mass.copy()
    totals=dict(in_kg=0.,out_kg=0.,source_in_kg=0.,source_out_kg=0.,bottom_net_kg_s=0.,bottom_out_kg_s=0.)
    cumulative=np.zeros(grid.shape)

    def evaluate(m,theta):
        c=m/theta;fs=[];incoming=outgoing=0.
        for a,(dx,D,q0) in enumerate(zip(grid.spacing_xyz,dispersion,water.fluxes)):
            ax=2-a;v=np.moveaxis(c,ax,-1);th=np.moveaxis(theta,ax,-1);q=np.moveaxis(q0,ax,-1)
            slope=mc_slopes(v);left=v[...,:-1]+.5*slope[...,:-1];right=v[...,1:]-.5*slope[...,1:]
            f=np.empty_like(q)
            f[...,1:-1]=np.maximum(q[...,1:-1],0)*left+np.minimum(q[...,1:-1],0)*right-.5*(th[...,1:]+th[...,:-1])*D*np.diff(v,axis=-1)/dx
            for side,sign,face in ((0,-1,FACES[2*a]),(-1,1,FACES[2*a+1])):
                b=boundaries[face];qn=sign*q[...,side];edge=v[...,side]
                if b.kind=='closed':
                    if np.max(np.abs(qn))>1e-14: raise ValueError('solute closed boundary conflicts with water flux')
                    f[...,side]=0.;continue
                if b.kind=='outflow' and np.any(qn < -1e-14): raise ValueError('outflow reversed')
                cb=b.values(t,grid,a);out=np.maximum(qn,0)*edge+np.minimum(qn,0)*cb
                if b.kind=='dirichlet': out+=2*th[...,side]*D*(edge-cb)/dx
                f[...,side]=sign*out
                incoming-=float(np.minimum(out,0).sum()*grid.face_area(a))
                outgoing+=float(np.maximum(out,0).sum()*grid.face_area(a))
            fs.append(np.moveaxis(f,-1,ax))
        removal=np.minimum(water.source,0.)*c
        rate=-divergence(fs,grid)+source_mass+removal
        b=dict(in_kg=incoming,out_kg=outgoing,
            source_in_kg=float(np.maximum(source_mass,0).sum()*grid.volume),
            source_out_kg=float(-removal.sum()*grid.volume),
            bottom_net_kg_s=float(fs[2][-1].sum()*grid.face_area(2)),
            bottom_out_kg_s=float(np.maximum(fs[2][-1],0).sum()*grid.face_area(2)))
        return rate,b

    for j in range(nsub):
        th0=water.theta_old+(water.theta-water.theta_old)*(j/nsub)
        th1=water.theta_old+(water.theta-water.theta_old)*((j+1)/nsub)
        k0,b0=evaluate(mass,th0);stage=mass+ds*k0
        if stage.min() < -1e-14 or not np.all(np.isfinite(stage)): raise FloatingPointError('invalid SSPRK stage; no clipping')
        k1,b1=evaluate(stage,th1);mass=.5*mass+.5*(stage+ds*k1)
        cumulative+=.5*ds*(k0+k1)
        if mass.min() < -1e-14 or not np.all(np.isfinite(mass)): raise FloatingPointError('invalid MUSCL mass; no clipping')
        for k in totals: totals[k]+=.5*ds*(b0[k]+b1[k])
    totals['bottom_net_kg_s']/=dt;totals['bottom_out_kg_s']/=dt
    totals['cell_residual_max_kg']=float(np.abs(mass-initial_mass-cumulative).max()*grid.volume)
    return mass/water.theta,totals
