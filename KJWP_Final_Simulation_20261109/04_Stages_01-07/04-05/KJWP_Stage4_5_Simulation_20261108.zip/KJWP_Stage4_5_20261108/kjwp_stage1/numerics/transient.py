"""Conservative theta*C transport coupled to accepted Richards water steps.

Backward Euler water; default mass-based MUSCL/SSPRK2 solute subcycling, with an
implicit first-order donor-cell option for comparison. Constant diagonal D.
"""
from dataclasses import dataclass
import numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import spsolve
from ..physics.boundary import FACES, Boundary
from ..flow.richards import divergence, boundary_water_rates, FlowConvergenceError
from ..physics.injection import sources
from .transient_muscl import transport_muscl


def transport_step(grid,water,old,dt,dispersion,boundaries,t,source_mass):
    if set(boundaries)!=set(FACES): raise ValueError('all solute boundaries required')
    if any(b.kind not in ('closed','dirichlet','inflow_flux','outflow') for b in boundaries.values()):
        raise ValueError('transient backend does not yet support periodic solute boundaries')
    old=np.asarray(old,dtype=float)
    if old.shape!=grid.shape or np.any(old<0) or not np.all(np.isfinite(old)):
        raise ValueError('invalid old concentration')
    ids=np.arange(old.size).reshape(grid.shape);diag=water.theta.ravel()/dt
    rhs=(water.theta_old*old/dt+source_mass).ravel().copy()
    # Generic extraction is not exposed by Injection; for API-supplied negative
    # source, withdrawing fluid removes species at the new local concentration.
    diag=diag-np.minimum(water.source.ravel(),0.)
    rows=[];cols=[];data=[]
    coefficients=[]
    for a,(dx,D,q0) in enumerate(zip(grid.spacing_xyz,dispersion,water.fluxes)):
        if not np.isfinite(D) or D<0: raise ValueError('finite nonnegative diagonal dispersion required')
        ax=2-a;ii=np.moveaxis(ids,ax,-1);q=np.moveaxis(q0,ax,-1)
        th=np.moveaxis(water.theta,ax,-1);l=ii[...,:-1].ravel();r=ii[...,1:].ravel()
        g=.5*(th[...,:-1]+th[...,1:])*D/dx
        left=np.maximum(q[...,1:-1],0)+g
        right=np.minimum(q[...,1:-1],0)-g
        np.add.at(diag,l,(left/dx).ravel());np.add.at(diag,r,(-right/dx).ravel())
        rows.extend((l,r));cols.extend((r,l));data.extend(((right/dx).ravel(),(-left/dx).ravel()))
        cbounds=[]
        for side,sign,face in ((0,-1,FACES[2*a]),(-1,1,FACES[2*a+1])):
            b=boundaries[face];qn=sign*q[...,side];idx=ii[...,side].ravel()
            cb=b.values(t,grid,a)
            if b.kind=='closed':
                if np.max(np.abs(qn))>1e-14: raise ValueError('solute closed boundary conflicts with water flux')
                cbounds.append((np.zeros_like(qn),np.zeros_like(qn)));continue
            if b.kind=='outflow' and np.any(qn < -1e-14):
                raise ValueError('outflow reversed; specify inflow_flux for reversible open boundary')
            # inflow_flux accepts reversal: zero diffusive flux, prescribed
            # upstream concentration on inflow and local concentration on outflow.
            coeff=np.maximum(qn,0.)
            const=np.minimum(qn,0.)*cb
            if b.kind=='dirichlet':
                gd=2*th[...,side]*D/dx;coeff=coeff+gd;const=const-gd*cb
            np.add.at(diag,idx,(coeff/dx).ravel());np.add.at(rhs,idx,(-const/dx).ravel())
            cbounds.append((coeff,const))
        coefficients.append((left,right,cbounds))
    rows.append(np.arange(old.size));cols.append(np.arange(old.size));data.append(diag)
    A=coo_matrix((np.concatenate(data),(np.concatenate(rows),np.concatenate(cols))),
                 shape=(old.size,old.size)).tocsr()
    c=spsolve(A,rhs).reshape(grid.shape)
    if not np.all(np.isfinite(c)) or c.min() < -1e-12*max(1.,old.max()):
        raise FloatingPointError('invalid transient concentration; no clipping')
    fs=[];incoming=outgoing=0.
    for a,(left,right,cbounds) in enumerate(coefficients):
        ax=2-a;v=np.moveaxis(c,ax,-1);f=np.empty(v.shape[:-1]+(v.shape[-1]+1,))
        f[...,1:-1]=left*v[...,:-1]+right*v[...,1:]
        for side,sign,(coeff,const) in ((0,-1,cbounds[0]),(-1,1,cbounds[1])):
            out=coeff*v[...,side]+const;f[...,side]=sign*out
            incoming-=float(np.minimum(out,0).sum()*grid.face_area(a))
            outgoing+=float(np.maximum(out,0).sum()*grid.face_area(a))
        fs.append(np.moveaxis(f,-1,ax))
    net_source=source_mass+np.minimum(water.source,0.)*c
    local=water.theta*c-water.theta_old*old+dt*(divergence(fs,grid)-net_source)
    return c,dict(in_kg=dt*incoming,out_kg=dt*outgoing,
        bottom_net_kg_s=float(fs[2][-1].sum()*grid.face_area(2)),
        bottom_out_kg_s=float(np.maximum(fs[2][-1],0.).sum()*grid.face_area(2)),
        source_in_kg=float(dt*np.maximum(source_mass,0).sum()*grid.volume),
        source_out_kg=float(-dt*(np.minimum(water.source,0.)*c).sum()*grid.volume),
        cell_residual_max_kg=float(np.abs(local).max()*grid.volume))


@dataclass
class TransientResult:
    times_s: np.ndarray
    head_m: np.ndarray
    theta: np.ndarray
    concentration: dict
    history: list
    metadata: dict


def solve_transient(flow,head,initial,*,end_s,max_dt_s,save_times_s,dispersion_m2_s=(0.,0.,0.),
                    solute_boundaries=None,injections=(),min_dt_s=1e-5,max_steps=100000,
                    transport_scheme='muscl_mc'):
    g=flow.grid;h=np.array(head,dtype=float,copy=True);species=tuple(initial)
    if (not species or not np.all(np.isfinite((end_s,max_dt_s,min_dt_s)))
            or end_s<=0 or max_dt_s<=0 or min_dt_s<=0 or min_dt_s>max_dt_s):
        raise ValueError('invalid species/time controls')
    if np.asarray(dispersion_m2_s).shape!=(3,): raise ValueError('three dispersion coefficients required')
    if transport_scheme not in ('muscl_mc','implicit_upwind'): raise ValueError('unknown transport scheme')
    c={s:np.array(initial[s],dtype=float,copy=True) for s in species}
    for v in c.values():
        if v.shape!=g.shape or np.any(v<0) or not np.all(np.isfinite(v)): raise ValueError('invalid concentration')
    if h.shape!=g.shape or not np.all(np.isfinite(h)): raise ValueError('invalid head')
    save=np.asarray(save_times_s,dtype=float)
    if save.ndim!=1 or not np.all(np.isfinite(save)) or np.any(save<0) or np.any(save>end_s):
        raise ValueError('invalid save times')
    save=np.unique(np.r_[0.,save,end_s])
    events=[x for inj in injections for x in (inj.start_s,inj.end_s)]
    events += [x for b in flow.boundaries.values() for x in b.events]
    stops=np.unique(np.r_[save,[x for x in events if 0<x<end_s]])
    if solute_boundaries is None:
        solute_boundaries={s:{f:Boundary('closed' if b.kind=='closed' else 'inflow_flux',0.)
                             for f,b in flow.boundaries.items()} for s in species}
    if set(solute_boundaries)!=set(species): raise ValueError('solute boundary species mismatch')
    events += [x for bs in solute_boundaries.values() for b in bs.values() for x in b.events]
    stops=np.unique(np.r_[save,[x for x in events if 0<x<end_s]])
    sources(injections,g,0.,species)
    th0=flow.theta(h);w0=float(th0.sum()*g.volume)
    m0={s:float((th0*c[s]).sum()*g.volume) for s in species}
    w_in=w_out=0.;mi={s:0. for s in species};mo=mi.copy()
    heads=[h.copy()];thetas=[th0.copy()];fields={s:[v.copy()] for s,v in c.items()};times=[0.]
    history=[];t=0.;count=0;retries=0;next_dt=max_dt_s

    def record(dt,step=None,budgets=None):
        theta=flow.theta(h);w=float(theta.sum()*g.volume);den=w0+w_in
        row=dict(time_s=float(t),dt_s=float(dt),water_initial_m3=w0,water_stored_m3=w,
                 water_in_m3=w_in,water_out_m3=w_out,water_residual_m3=w0+w_in-w-w_out,
                 water_relative_residual=abs(w0+w_in-w-w_out)/den if den else 0.,
                 nonlinear_iterations=0 if step is None else step.iterations,
                 water_cell_balance_max=0. if step is None else step.cell_balance_max)
        for s in species:
            m=float((theta*c[s]).sum()*g.volume);den=m0[s]+mi[s]
            row[s]=dict(initial_kg=m0[s],in_kg=mi[s],out_kg=mo[s],stored_kg=m,
                        residual_kg=m0[s]+mi[s]-mo[s]-m,
                        relative_residual=abs(m0[s]+mi[s]-mo[s]-m)/den if den else 0.,
                        min_kg_m3=float(c[s].min()),max_kg_m3=float(c[s].max()),
                        bottom_net_kg_s=0. if budgets is None else budgets[s]['bottom_net_kg_s'],
                        bottom_out_kg_s=0. if budgets is None else budgets[s]['bottom_out_kg_s'],
                        cell_residual_max_kg=0. if budgets is None else budgets[s]['cell_residual_max_kg'])
        history.append(row)
    record(0.)
    for stop in stops[1:]:
        while t<stop:
            if count>=max_steps: raise RuntimeError('max_steps exceeded')
            dt=min(next_dt,stop-t)
            if t+dt==t: raise FloatingPointError('time cannot advance')
            sw,sm=sources(injections,g,t,species)
            while True:
                try: wstep=flow.step(h,t,dt,sw);break
                except FlowConvergenceError:
                    retries+=1;dt*=.5
                    if dt<min_dt_s: raise
            new={};budgets={}
            for s in species:
                transport=transport_muscl if transport_scheme=='muscl_mc' else transport_step
                new[s],budgets[s]=transport(g,wstep,c[s],dt,dispersion_m2_s,
                    solute_boundaries[s],np.nextafter(t+dt,t),sm[s])
                b=budgets[s];mi[s]+=b['in_kg']+b['source_in_kg'];mo[s]+=b['out_kg']+b['source_out_kg']
            bi,bo=boundary_water_rates(wstep.fluxes,g)
            w_in+=dt*(bi+float(np.maximum(sw,0).sum()*g.volume))
            w_out+=dt*(bo-float(np.minimum(sw,0).sum()*g.volume))
            h=wstep.head;c=new;t=stop if dt==stop-t else t+dt;count+=1
            record(dt,wstep,budgets);next_dt=min(max_dt_s,dt*1.3)
        if np.any(save==stop):
            times.append(float(t));heads.append(h.copy());thetas.append(flow.theta(h))
            for s in species: fields[s].append(c[s].copy())
    return TransientResult(np.array(times),np.stack(heads),np.stack(thetas),
        {s:np.stack(v) for s,v in fields.items()},history,
        dict(backend='mixed-form FV Richards + conservative mass-based FV solute',
             water_time_integrator='backward Euler',
             solute_time_integrator='SSPRK2 subcycling' if transport_scheme=='muscl_mc' else 'backward Euler',
             advection=transport_scheme,
             dispersion='constant diagonal',steps=count,rejected_water_steps=retries,
             theta_tolerance=flow.theta_tolerance,clipping=False,mass_renormalization=False,
             chemistry_implemented=False,particle_transport_implemented=False))
