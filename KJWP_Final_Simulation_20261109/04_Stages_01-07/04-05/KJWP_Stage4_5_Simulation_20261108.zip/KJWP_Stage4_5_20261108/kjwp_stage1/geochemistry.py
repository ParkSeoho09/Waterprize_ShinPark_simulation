"""Stage 3: well-mixed reaction cell with prescribed environmental exposure.

Inventories are mol / kg water. Biomass is a fixed effective activity, not
a growth model. PHREEQC initial speciation preserves supplied valence totals;
no redox equilibrium, gas equilibrium or mineral equilibrium is invoked.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
from dataclasses import asdict, dataclass
from pathlib import Path

import numpy as np
from scipy.integrate import solve_ivp
from .reaction_environment import ExposureSchedule, EnvironmentPeriod

MW_N = 14.0067
MW_NO3 = 62.0049
MW_S = 32.065
MW_SO4 = 96.0626
MW_CA = 40.078
MW_CALCITE = 100.0869


@dataclass(frozen=True)
class BatchConfig:
    nitrate_mg_per_kgw: float = 40.0  # NO3 ion, NOT NO3-N
    sulfur_g_per_kgw: float = 0.3
    calcite_g_per_kgw: float = 0.3 * 2710 / (3 * 2070)
    dic_mol_per_kgw: float = 0.00015
    calcium_mol_per_kgw: float = 0.0002
    sulfate_mol_per_kgw: float = 0.0001
    chloride_mol_per_kgw: float = 0.001
    initial_pH: float = 7.2
    temperature_C: float = 25.0
    biomass_mg_VSS_per_kgw: float = 100.0
    k_per_day: float = 0.15
    ks_mg_N_L: float = 0.398
    kinetic_volume_L_per_kgw: float | None = None  # None uses PHREEQC volume
    calcite_diameter_m: float = 0.0005
    calcite_density_kg_m3: float = 2710.0
    calcite_area_factor: float = 1.0
    calcite_area_model: str = 'shrinking_sphere'
    pH_stop: float = 5.5
    pH_full: float = 6.5
    pH_inhibition: bool = True
    reactions_enabled: bool = True
    duration_days: float = 7.0
    max_step_days: float = 0.05
    rtol: float = 1e-7
    atol_mol: float = 1e-12
    depletion_tolerance_mol: float = 1e-12
    output_count: int = 169
    method: str = 'BDF'
    environment_periods: tuple[EnvironmentPeriod | dict, ...] = ()
    oxygen_half_inhibition_mg_L: float | None = None
    microbial_lag_hours: float = 0.0
    environment_source: str = 'scenario'

    def validate(self):
        if self.calcite_area_model not in ('shrinking_sphere','fixed_specific_area'): raise ValueError('Invalid area model')
        for key, value in asdict(self).items():
            if isinstance(value, (float, int)) and not np.isfinite(value):
                raise ValueError(f'{key} must be finite')
        nonnegative = ('nitrate_mg_per_kgw', 'sulfur_g_per_kgw',
                       'calcite_g_per_kgw', 'dic_mol_per_kgw',
                       'calcium_mol_per_kgw', 'sulfate_mol_per_kgw',
                       'chloride_mol_per_kgw', 'biomass_mg_VSS_per_kgw',
                       'k_per_day', 'calcite_area_factor')
        for key in nonnegative:
            if getattr(self, key) < 0:
                raise ValueError(f'{key} must be nonnegative')
        for key in ('ks_mg_N_L', 'calcite_diameter_m',
                    'calcite_density_kg_m3', 'duration_days',
                    'max_step_days', 'rtol', 'atol_mol', 'depletion_tolerance_mol'):
            if getattr(self, key) <= 0:
                raise ValueError(f'{key} must be positive')
        if not 0 < self.pH_stop < self.pH_full < 14:
            raise ValueError('Invalid pH inhibition thresholds')
        if not 0 < self.initial_pH < 14:
            raise ValueError('Invalid initial pH')
        if self.temperature_C != 25.0:
            raise ValueError('Biokinetic reference is restricted to 25 C; recalibration needed')
        if self.output_count < 2 or int(self.output_count) != self.output_count:
            raise ValueError('output_count must be an integer >=2')
        if self.method not in ('BDF', 'Radau', 'DOP853'):
            raise ValueError('Unsupported integration method')
        if self.kinetic_volume_L_per_kgw is not None and self.kinetic_volume_L_per_kgw <= 0:
            raise ValueError('Reference kinetic volume must be positive')
        if self.environment_source not in ('scenario', 'user_supplied_measurements'):
            raise ValueError('environment_source must identify scenario or user_supplied_measurements')
        ExposureSchedule(self.environment_periods, self.duration_days * 24,
                         self.oxygen_half_inhibition_mg_L, self.microbial_lag_hours)


class Speciation:
    """A fresh SOLUTION per call, avoiding spontaneous redox equilibration."""
    def __init__(self):
        from phreeqpython import PhreeqPython
        import phreeqpython
        self.database_path = Path(phreeqpython.__file__).parent / 'database' / 'phreeqc.dat'
        self.database_sha256 = hashlib.sha256(self.database_path.read_bytes()).hexdigest()
        self.engine = PhreeqPython(database='phreeqc.dat')
        self.calls = 0
        self.engine.ip.run_string('''SELECTED_OUTPUT 1
 -reset false
 -high_precision true
USER_PUNCH 1
 -headings pH alk Ca C N S Na charge si_calcite a_H a_CO2 a_water volume_L
 -start
 10 PUNCH -LA("H+"), ALK, TOT("Ca"), TOT("C(4)"), TOT("N(5)"), TOT("S(6)"), TOT("Na"), CHARGE_BALANCE, SI("Calcite"), ACT("H+"), ACT("CO2"), ACT("H2O"), SOLN_VOL
 -end
END
''')

    def calculate(self, c, nitrate, sulfate, calcium, dic, sodium=None):
        pH = str(c.initial_pH) + (' charge' if sodium is not None else '')
        na = f'{sodium:.17g}' if sodium is not None else '0.001 charge'
        text = f'''SOLUTION 1
 units mol/kgw
 -water 1
 temp {c.temperature_C:.17g}
 pH {pH}
 Ca {calcium:.17g}
 C(4) {dic:.17g}
 N(5) {nitrate:.17g}
 S(6) {sulfate:.17g}
 Cl {c.chloride_mol_per_kgw:.17g}
 Na {na}
END
'''
        self.engine.ip.run_string(text)
        table = self.engine.ip.get_selected_output_array()
        self.calls += 1
        result = dict(zip(table[0], table[-1]))
        if not all(np.isfinite(v) for v in result.values()):
            raise RuntimeError('Nonfinite PHREEQC output')
        return result


def monod_rate_mg_N_day(nitrate_mg_N, c, volume_L_per_kgw=1.0):
    concentration = max(nitrate_mg_N, 0) / volume_L_per_kgw
    return c.k_per_day * c.biomass_mg_VSS_per_kgw * concentration / (c.ks_mg_N_L + concentration)


def calcite_rate_mol_day(c, remaining, initial, spec):
    """PHREEQC/PWP dissolution-only law, cm2, mmol, seconds -> mol/day."""
    if initial <= 0 or remaining <= 0 or spec['si_calcite'] >= 0:
        return 0.0
    tk = c.temperature_C + 273.15
    k1 = 10 ** (0.198 - 444.0 / tk)
    k2 = 10 ** (2.84 - 2177.0 / tk)
    k3 = 10 ** (-5.86 - 317.0 / tk)
    area0 = 6 * (initial * MW_CALCITE / 1000) / (c.calcite_density_kg_m3 * c.calcite_diameter_m) * 1e4
    exponent = 2 / 3 if c.calcite_area_model == 'shrinking_sphere' else 1.0
    area = area0 * c.calcite_area_factor * (remaining / initial) ** exponent
    driving = -np.expm1(np.log(10) * 2 / 3 * spec['si_calcite'])
    return area * (k1 * spec['a_H'] + k2 * spec['a_CO2'] + k3 * spec['a_water']) * driving * 0.001 * 86400


def simulate(c=BatchConfig()):
    c.validate()
    schedule = ExposureSchedule(c.environment_periods, c.duration_days * 24,
                                c.oxygen_half_inhibition_mg_L, c.microbial_lag_hours)
    chemistry = Speciation()
    n0 = c.nitrate_mg_per_kgw / (MW_NO3 * 1000)
    s0 = c.sulfur_g_per_kgw / MW_S
    ca0 = c.calcite_g_per_kgw / MW_CALCITE
    limits = np.array([min(n0, s0 * 6 / 5), ca0])
    initial = chemistry.calculate(c, n0, c.sulfate_mol_per_kgw,
                                  c.calcium_mol_per_kgw, c.dic_mol_per_kgw)
    sodium = initial['Na']

    def speciate(y):
        xi, eta = np.clip(y, 0, limits)
        return chemistry.calculate(c, n0 - xi, c.sulfate_mol_per_kgw + 5 / 6 * xi,
                                   c.calcium_mol_per_kgw + eta,
                                   c.dic_mol_per_kgw + eta, sodium)

    # Stop just above mathematical exhaustion. Monod approaches zero only
    # asymptotically; an event exactly at zero is ill-conditioned. Leave the
    # tiny residual in its original pool rather than deleting/projecting it.
    depletion = np.minimum(limits / 100, c.depletion_tolerance_mol)
    active = limits > 0
    environment = schedule.state(0)

    def rhs(t, y):
        if not c.reactions_enabled or not environment['in_contact']:
            return np.zeros(2)
        xi, eta = np.clip(y, 0, limits)
        spec = speciate(y)
        fph = np.clip((spec['pH'] - c.pH_stop) / (c.pH_full - c.pH_stop), 0, 1) if c.pH_inhibition else 1.0
        volume = c.kinetic_volume_L_per_kgw or spec['volume_L']
        rn = monod_rate_mg_N_day((n0 - xi) * MW_N * 1000, c, volume) / (MW_N * 1000) * fph
        rn *= environment['active_fraction'] * environment['oxygen_factor']
        rc = calcite_rate_mol_day(c, ca0 - eta, ca0, spec)
        return [rn if active[0] else 0.0, rc if active[1] else 0.0]

    # Include schedule boundaries in outputs and never integrate across a jump.
    times = np.unique(np.concatenate((np.linspace(0, c.duration_days, c.output_count),
                                     np.array(schedule.boundaries) / 24)))
    states = np.empty((2, len(times)))
    start = 0.0
    state = np.zeros(2)
    events_log = []
    nfev = 0
    for start_hour, stop_hour in zip(schedule.boundaries, schedule.boundaries[1:]):
        start, stop = start_hour / 24, stop_hour / 24
        environment = schedule.state((start_hour + stop_hour) / 2)
        if not environment['in_contact'] or not c.reactions_enabled:
            take = (times >= start) & (times <= stop)
            states[:, take] = state[:, None]
            continue
        for _ in range(3):  # at most two finite-inventory events per interval
            ids = [i for i in range(2) if active[i]]
            events = []
            for i in ids:
                def event(t, y, i=i):
                    return limits[i] - y[i] - depletion[i]
                event.terminal = True
                event.direction = -1
                events.append(event)
            sol = solve_ivp(rhs, (start, stop), state, method=c.method,
                            rtol=c.rtol, atol=c.atol_mol, max_step=c.max_step_days,
                            events=events, dense_output=True)
            if not sol.success:
                raise RuntimeError(sol.message)
            nfev += sol.nfev
            end = sol.t[-1]
            take = (times >= start) & (times <= end)
            states[:, take] = sol.sol(times[take])
            state = sol.y[:, -1].copy()
            if sol.status == 1:
                hit = next(i for i, e in zip(ids, sol.t_events) if len(e))
                active[hit] = False
                events_log.append({'day': float(end), 'pool': ['nitrate_or_sulfur', 'calcite'][hit],
                                   'remaining_reaction_capacity_mol_kgw': float(limits[hit]-state[hit])})
            if end >= stop:
                break
            start = end
        else:
            raise RuntimeError('Event restart limit exceeded')
    correction = float(np.max(np.abs(states - np.clip(states, 0, limits[:, None]))))
    if correction > max(100 * c.atol_mol, 1e-10):
        raise RuntimeError(f'Inventory overshoot {correction} mol/kgw')
    states = np.clip(states, 0, limits[:, None])
    records = []
    for t, (xi, eta) in zip(times, states.T):
        sp = speciate([xi, eta])
        environment = schedule.state(t * 24)
        contact_hours, weighted_hours = schedule.cumulative_hours(t * 24)
        row = {
            'day': float(t), 'NO3_mg_kgw': (n0 - xi) * MW_NO3 * 1000,
            'NO3_N_mg_kgw': (n0 - xi) * MW_N * 1000,
            'N2_produced_mol_kgw': xi / 2, 'S0_g_kgw': (s0 - 5 / 6 * xi) * MW_S,
            'CaCO3_g_kgw': (ca0 - eta) * MW_CALCITE,
            'SO4_mg_kgw': sp['S'] * MW_SO4 * 1000,
            'Ca_mg_kgw': sp['Ca'] * MW_CA * 1000,
            'DIC_mmol_kgw': sp['C'] * 1000, 'alk_meq_kgw': sp['alk'] * 1000,
            'pH': sp['pH'], 'calcite_SI': sp['si_calcite'],
            'solution_volume_L_per_kgw': sp['volume_L'],
            'NO3_mg_L_solution': (n0 - xi) * MW_NO3 * 1000 / sp['volume_L'],
            'reacted_NO3_mg_kgw': xi * MW_NO3 * 1000,
            'dilution_removed_NO3_mg_kgw': 0.0,
            'n_balance_mol_kgw': sp['N'] + xi - n0,
            's_balance_mol_kgw': sp['S'] + s0 - 5 / 6 * xi - (c.sulfate_mol_per_kgw + s0),
            'ca_balance_mol_kgw': sp['Ca'] + ca0 - eta - (c.calcium_mol_per_kgw + ca0),
            'c_balance_mol_kgw': sp['C'] + ca0 - eta - (c.dic_mol_per_kgw + ca0),
            'alk_balance_eq_kgw': sp['alk'] - (initial['alk'] - 2 / 3 * xi + 2 * eta),
            'charge_balance_eq_kgw': sp['charge'],
            'prescribed_DO_mg_L': environment['dissolved_oxygen_mg_L'],
            'oxygen_inhibition_factor': environment['oxygen_factor'],
            'active_fraction': environment['active_fraction'],
            'effective_biomass_mg_VSS_kgw': c.biomass_mg_VSS_per_kgw * environment['active_fraction'],
            'in_contact': environment['in_contact'],
            'prescribed_contact_hours': contact_hours,
            'activity_oxygen_weighted_contact_hours': weighted_hours,
        }
        records.append({k: float(v) for k, v in row.items()})
    balances = {key: max(abs(r[key]) for r in records) for key in records[0] if 'balance' in key}
    return {'config': asdict(c), 'records': records, 'validation': balances,
            'events': events_log, 'inventory_roundoff_correction_mol_kgw': correction,
            'solver_nfev': nfev, 'speciation_calls': chemistry.calls,
            'database_sha256': chemistry.database_sha256,
            'initial_sodium_mol_kgw': sodium,
            'scope': 'Prescribed DO/activity/contact exposure; fixed solvent mass; biochemical growth, oxygen consumption, aerobic sulfur oxidation and transport require further models/calibration.'}


def save_result(result, directory):
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    with (directory / 'time_series.csv').open('w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=result['records'][0])
        writer.writeheader()
        writer.writerows(result['records'])
    (directory / 'result.json').write_text(json.dumps(result, indent=2), encoding='utf-8')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', type=Path)
    parser.add_argument('--output', type=Path, default=Path('stage3_results/custom'))
    args = parser.parse_args()
    config = BatchConfig(**json.loads(args.config.read_text())) if args.config else BatchConfig()
    result = simulate(config)
    save_result(result, args.output)
    print(json.dumps({'final': result['records'][-1], 'balances': result['validation']}, indent=2))


if __name__ == '__main__':
    main()
