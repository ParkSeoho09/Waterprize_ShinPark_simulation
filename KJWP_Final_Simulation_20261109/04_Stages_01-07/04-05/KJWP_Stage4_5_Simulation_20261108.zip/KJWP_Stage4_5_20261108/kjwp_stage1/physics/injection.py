"""Finite-volume water + dissolved-species injection; NOT solid particle transport."""
from dataclasses import dataclass, field
import numpy as np


@dataclass(frozen=True)
class Injection:
    position_m: tuple
    rate_m3_s: float
    start_s: float
    end_s: float
    concentrations_kg_m3: dict = field(default_factory=dict)
    radius_m: float = 0.  # zero -> containing cell; >0 -> cell centers inside sphere

    def __post_init__(self):
        vals=(*self.position_m,self.rate_m3_s,self.start_s,self.end_s,self.radius_m)
        if (len(self.position_m)!=3 or not np.all(np.isfinite(vals)) or self.rate_m3_s<=0
                or self.start_s<0 or self.end_s<=self.start_s or self.radius_m<0
                or any(not np.isfinite(c) or c<0 for c in self.concentrations_kg_m3.values())):
            raise ValueError('invalid injection (positive rate, nonnegative concentrations, finite pulse required)')

    def weights(self,grid):
        p=np.array(self.position_m)
        if np.any(p<0) or np.any(p>=grid.lengths_m): raise ValueError('injection outside grid')
        if self.radius_m and (np.any(p-self.radius_m<0) or np.any(p+self.radius_m>grid.lengths_m)):
            raise ValueError('finite injection sphere must fit wholly inside domain')
        w=np.zeros(grid.shape)
        if self.radius_m==0:
            ijk=np.floor(p/np.array(grid.spacing_xyz)).astype(int);w[tuple(ijk[::-1])]=1.
        else:
            z,y,x=grid.mesh_zyx()
            w[((x-p[0])**2+(y-p[1])**2+(z-p[2])**2)<=self.radius_m**2]=1.
            if w.sum()==0: raise ValueError('injection radius contains no cell centers; refine grid')
        return w/w.sum()


def sources(injections,grid,t,species):
    water=np.zeros(grid.shape);solute={s:np.zeros(grid.shape) for s in species}
    for inj in injections:
        unknown=set(inj.concentrations_kg_m3)-set(species)
        if unknown: raise ValueError(f'unknown injection species {unknown}')
        w=inj.weights(grid)  # validate also before/after pulse
        if inj.start_s<=t<inj.end_s:
            sw=inj.rate_m3_s*w/grid.volume;water+=sw
            for s in species: solute[s]+=sw*inj.concentrations_kg_m3.get(s,0.)
    return water,solute
