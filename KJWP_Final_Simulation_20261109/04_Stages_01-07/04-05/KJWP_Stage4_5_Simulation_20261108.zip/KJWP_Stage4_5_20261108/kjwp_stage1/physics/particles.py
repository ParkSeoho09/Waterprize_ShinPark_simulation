"""Dilute particles: constitutive hypotheses and conservative local retention.

Mobile concentration is kg solid / m3 CARRIER WATER. Retained pools are
kg solid / m3 BULK SOIL. No chemistry, aggregation, clogging or pore exclusion.
Rates and porous-medium settling reduction require experimental calibration.
"""
from dataclasses import dataclass
import numpy as np

G = 9.80665
PARTICLES = ('sulfur', 'caco3')


def mixture_properties(slurry, mobile):
    """Additive volume mixture, Einstein dilute viscosity; NOT measured rheology."""
    if slurry.viscosity_model != 'einstein_dilute':
        raise ValueError('coupled solver requires einstein_dilute; measured dilution curve not supplied')
    s, c = np.broadcast_arrays(mobile['sulfur'], mobile['caco3'])
    if any(np.any(a < 0) or not np.all(np.isfinite(a)) for a in (s, c)):
        raise ValueError('invalid mobile particle concentration')
    b = s / slurry.sulfur_density_kg_m3 + c / slurry.caco3_density_kg_m3
    phi = b / (1 + b)
    if np.max(phi) > .02 * (1 + 1e-10):
        raise ValueError('local mobile solid fraction exceeds dilute model scope (0.02)')
    rho = (slurry.carrier_density_kg_m3 + s + c) / (1 + b)
    mu = slurry.carrier_viscosity_Pa_s * (1 + 2.5 * phi)
    # Carrier volume flux / water-only Darcy flux at equal pressure gradient.
    mobility = (1 - phi) * slurry.carrier_viscosity_Pa_s / mu
    return dict(phi=phi, density_kg_m3=rho, viscosity_Pa_s=mu,
                carrier_mobility_ratio=mobility,
                gravity_ratio=rho / slurry.carrier_density_kg_m3)


@dataclass(frozen=True)
class Retention:
    attachment_s_inv: float = 0.
    detachment_s_inv: float = 0.
    straining_s_inv: float = 0.

    def __post_init__(self):
        if any(not np.isfinite(v) or v < 0 for v in
               (self.attachment_s_inv, self.detachment_s_inv, self.straining_s_inv)):
            raise ValueError('retention rates must be finite and nonnegative')

    def step(self, mobile_bulk, attached, strained, dt):
        """Positive analytic exchange and straining, symmetric splitting.

        dm/dt=-(ka+ks)m+kd*a, da/dt=ka*m-kd*a, ds/dt=ks*m.
        Each split conserves m+a+s. Rates do not imply validated soil physics.
        """
        if not np.isfinite(dt) or dt < 0:
            raise ValueError('invalid retention interval')
        m, a, s = (np.array(v, dtype=float, copy=True) for v in
                   np.broadcast_arrays(mobile_bulk, attached, strained))
        if any(np.any(v < 0) or not np.all(np.isfinite(v)) for v in (m, a, s)):
            raise ValueError('invalid retention pool')
        f = np.exp(-self.straining_s_inv * dt / 2)
        s += (1-f)*m
        m *= f
        ka, kd = self.attachment_s_inv, self.detachment_s_inv
        if ka+kd > 0:
            one_minus_e = -np.expm1(-(ka+kd)*dt)
            change = one_minus_e * (ka*m-kd*a)/(ka+kd)
            m, a = m-change, a+change
        s += (1-f)*m
        m *= f
        return m, a, s


def settling_velocity(slurry, species, properties, reduction):
    if not np.isfinite(reduction) or not 0 <= reduction <= 1:
        raise ValueError('settling reduction must be in [0,1]')
    density = getattr(slurry, species+'_density_kg_m3')
    diameter = getattr(slurry, species+'_diameter_m')
    # Free-fluid Stokes velocity times an explicit, empirical porous-medium factor.
    return reduction*(density-properties['density_kg_m3'])*G*diameter**2 / (
        18*properties['viscosity_Pa_s'])


def particle_fluxes(water, velocity, bottom_open):
    """Add downward drift inside soil; impermeable boundaries retain particles."""
    q = [v.copy() for v in water.fluxes]
    th = .5*(water.theta_old+water.theta)
    drift = th*velocity
    q[2][1:-1] += .5*(drift[:-1]+drift[1:])
    if bottom_open:
        q[2][-1] += drift[-1]
    return tuple(q)
