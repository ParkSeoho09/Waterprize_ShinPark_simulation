"""Slurry inputs and equal dry-solid dose accounting; no flow/particle solver.

Volume ratios use TRUE solid volume, not loose powder bulk volume.
All mixture relations assume additive volumes. Einstein viscosity is an ideal
dilute, rigid-sphere, nonaggregating approximation, not measured rheology.
"""
from dataclasses import dataclass, asdict
import math


@dataclass(frozen=True)
class Slurry:
    sulfur_volume_parts: float = 3.
    caco3_volume_parts: float = 1.
    solid_volume_fraction: float = .02
    sulfur_density_kg_m3: float = 2070.
    caco3_density_kg_m3: float = 2700.
    carrier_density_kg_m3: float = 998.2
    carrier_viscosity_Pa_s: float = 1.002e-3
    sulfur_diameter_m: float = 5e-6
    caco3_diameter_m: float = 5e-6
    temperature_C: float = 20.
    viscosity_model: str = 'einstein_dilute'
    measured_viscosity_Pa_s: float | None = None

    def __post_init__(self):
        positive=(self.sulfur_volume_parts,self.caco3_volume_parts,
            self.sulfur_density_kg_m3,self.caco3_density_kg_m3,self.carrier_density_kg_m3,
            self.carrier_viscosity_Pa_s,self.sulfur_diameter_m,self.caco3_diameter_m)
        if any(not math.isfinite(x) or x<=0 for x in positive):
            raise ValueError('finite positive composition, densities, viscosity and diameters required')
        if not math.isfinite(self.solid_volume_fraction) or not 0<self.solid_volume_fraction<1:
            raise ValueError('solid volume fraction must be strictly between 0 and 1')
        if not math.isfinite(self.temperature_C) or self.temperature_C<=-273.15:
            raise ValueError('invalid temperature')
        if self.viscosity_model=='einstein_dilute':
            # Conservative project scope guard, NOT a universal validity limit.
            if self.solid_volume_fraction>.02 or self.measured_viscosity_Pa_s is not None:
                raise ValueError('dilute approximation limited here to phi<=0.02; use measured_constant for measured data')
        elif self.viscosity_model=='measured_constant':
            if self.measured_viscosity_Pa_s is None or not math.isfinite(self.measured_viscosity_Pa_s) or self.measured_viscosity_Pa_s<=0:
                raise ValueError('measured_constant requires positive measured viscosity')
        else: raise ValueError('unknown viscosity model')

    @property
    def sulfur_fraction_of_solids_by_volume(self):
        return self.sulfur_volume_parts/(self.sulfur_volume_parts+self.caco3_volume_parts)

    @property
    def component_kg_per_m3_slurry(self):
        f=self.sulfur_fraction_of_solids_by_volume;p=self.solid_volume_fraction
        return dict(sulfur=p*f*self.sulfur_density_kg_m3,
                    caco3=p*(1-f)*self.caco3_density_kg_m3,
                    carrier=(1-p)*self.carrier_density_kg_m3)

    @property
    def solid_kg_per_m3_slurry(self):
        c=self.component_kg_per_m3_slurry
        return c['sulfur']+c['caco3']

    @property
    def density_kg_m3(self): return sum(self.component_kg_per_m3_slurry.values())

    @property
    def viscosity_Pa_s(self):
        if self.viscosity_model=='measured_constant': return self.measured_viscosity_Pa_s
        return self.carrier_viscosity_Pa_s*(1+2.5*self.solid_volume_fraction)

    def volume_for_solid_mass(self,target_kg):
        if not math.isfinite(target_kg) or target_kg<=0: raise ValueError('positive dry-solid dose required')
        return target_kg/self.solid_kg_per_m3_slurry

    def summary(self):
        return dict(inputs=asdict(self),ratio_basis='true_solid_volume',
            derived=dict(component_kg_per_m3_slurry=self.component_kg_per_m3_slurry,
                         density_kg_m3=self.density_kg_m3,viscosity_Pa_s=self.viscosity_Pa_s),
            status='material inputs and dose accounting ONLY; not connected to flow/particle transport',
            limitations=['temperature is a recorded condition; carrier properties must be updated consistently',
                         'no validation of dispersion stability, pore injectability or measured slurry rheology',
                         'particle diameters are inputs; settling and filtration are not solved'])


class DoseBudget:
    """Account ACCEPTED inlet volumes; reject overshoot instead of rescaling flux.

dt_for_constant_rate is exact only for a rate fixed over that interval. A future
pressure-controlled solver must locate the dose event and re-solve its final
hydraulic interval; it must not clip volume/mass after computing the fields.
"""
    def __init__(self,slurry,target_solid_kg,*,allow_zero=False):
        self.slurry=slurry;self.target_solid_kg=target_solid_kg
        self.target_volume_m3=0. if allow_zero and target_solid_kg == 0 else slurry.volume_for_solid_mass(target_solid_kg)
        self.injected_volume_m3=0.

    @property
    def remaining_volume_m3(self): return max(0.,self.target_volume_m3-self.injected_volume_m3)

    @property
    def done(self):
        return abs(self.target_volume_m3-self.injected_volume_m3)<=1e-12*self.target_volume_m3

    def dt_for_constant_rate(self,rate_m3_s,proposed_dt_s):
        if not math.isfinite(rate_m3_s) or rate_m3_s<0 or not math.isfinite(proposed_dt_s) or proposed_dt_s<=0:
            raise ValueError('nonnegative rate and positive finite dt required')
        if self.done: return 0.
        return proposed_dt_s if rate_m3_s==0 else min(proposed_dt_s,self.remaining_volume_m3/rate_m3_s)

    def accept(self,volume_m3):
        if not math.isfinite(volume_m3) or volume_m3<0: raise ValueError('nonnegative accepted inlet volume required')
        new=self.injected_volume_m3+volume_m3
        if new-self.target_volume_m3>1e-12*self.target_volume_m3:
            raise ValueError('dose overshoot: shorten and re-solve hydraulic step; do not rescale flux')
        self.injected_volume_m3=new

    def summary(self):
        mass={k:v*self.injected_volume_m3 for k,v in self.slurry.component_kg_per_m3_slurry.items()}
        solid=mass['sulfur']+mass['caco3']
        return dict(target_dry_solid_kg=self.target_solid_kg,target_slurry_volume_m3=self.target_volume_m3,
                    injected_slurry_volume_m3=self.injected_volume_m3,component_injected_kg=mass,
                    injected_dry_solid_kg=solid,solid_dose_residual_kg=self.target_solid_kg-solid,done=self.done)
