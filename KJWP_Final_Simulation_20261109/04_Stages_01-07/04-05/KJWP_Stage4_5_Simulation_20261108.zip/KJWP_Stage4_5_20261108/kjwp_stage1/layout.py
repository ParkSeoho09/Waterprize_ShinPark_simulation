"""Stage 5 service-pipe coordinates/control compiler, not pipe CFD."""
import argparse
import copy
import json
from pathlib import Path
import numpy as np
from .core.grid import Grid
from .flow.pressure import PressurePort
from .physics.slurry import Slurry

def compile_layout(base, layout):
    cfg = copy.deepcopy(base)
    grid = Grid(tuple(cfg['grid']['lengths_m']), tuple(cfg['grid']['cells_xyz']))
    end_s = float(cfg['end_s'])
    if not np.isfinite(end_s) or end_s <= 0:
        raise ValueError('Invalid simulation duration')
    if layout.get('schema_version') != 1:
        raise ValueError('layout schema_version must be 1')
    kind = layout.get('kind', 'injection')
    if kind not in ('injection', 'no_injection'):
        raise ValueError('Unknown layout kind')
    if kind == 'no_injection' and (layout.get('pipes') or layout.get('direct_ports')):
        raise ValueError('A no-injection control cannot have outlets')

    ports, geometry, port_cells = [], [], {}
    pipe_ids = set()

    def add_port(tag, position, control):
        if not isinstance(tag, str) or not tag or tag in port_cells:
            raise ValueError(f'Invalid or duplicate outlet id: {tag!r}')
        try:
            port = PressurePort(position_m=position, **control)
            cell = port.cell(grid)
        except (ValueError, TypeError) as exc:
            raise ValueError(f'Outlet {tag}: {exc}') from exc
        if port.start_s >= end_s:
            raise ValueError(f'Outlet {tag}: start_s must precede end_s of the simulation')
        ports.append(dict(position_m=position, **control))
        port_cells[tag] = [int(index) for index in cell]

    for pipe in layout.get('pipes', []):
        name = pipe['id']
        if not isinstance(name, str) or not name or ':' in name or name in pipe_ids:
            raise ValueError(f'Invalid or duplicate pipe id: {name!r}')
        pipe_ids.add(name)
        origin = np.asarray(pipe['body_top_m'], dtype=float)
        length = float(pipe['body_length_m'])
        od = float(pipe['outer_diameter_m'])
        inner = float(pipe['inner_diameter_m'])
        tilt, az, roll = np.deg2rad([
            pipe.get('tilt_from_vertical_deg', 0),
            pipe.get('azimuth_deg', 0),
            pipe.get('roll_deg', 0),
        ])
        if origin.shape != (3,) or not np.all(np.isfinite(origin)) or not np.all(
            np.isfinite([length, od, inner, tilt, az, roll])
        ):
            raise ValueError(f'Pipe {name}: nonfinite or invalid geometry')
        if length <= 0 or not 0 < inner < od:
            raise ValueError(f'Pipe {name}: invalid dimensions')
        axis = np.array([np.sin(tilt)*np.cos(az), np.sin(tilt)*np.sin(az), np.cos(tilt)])
        a = np.array([np.cos(tilt)*np.cos(az), np.cos(tilt)*np.sin(az), -np.sin(tilt)])
        b = np.array([-np.sin(az), np.cos(az), 0.])
        radial = np.cos(roll)*a + np.sin(roll)*b
        geometry.append(dict(
            id=name, body_top_m=origin.tolist(), body_end_m=(origin + length*axis).tolist(),
            outer_diameter_m=od, inner_diameter_m=inner,
        ))
        offsets = pipe['paired_port_offsets_m']
        disabled = set(pipe.get('disabled_port_ids', []))
        overrides = pipe.get('port_controls', {})
        if len(set(offsets)) != len(offsets):
            raise ValueError(f'Pipe {name}: duplicate offsets')
        valid_ids = {f'{name}:{i+1}:{side}' for i in range(len(offsets)) for side in ('A', 'B')}
        if not disabled <= valid_ids:
            raise ValueError(f'Pipe {name}: unknown disabled outlet id')
        if not overrides.keys() <= valid_ids - disabled:
            raise ValueError(f'Pipe {name}: control references an unknown or disabled outlet')
        for i, offset in enumerate(offsets):
            if not np.isfinite(offset) or not 0 < offset < length:
                raise ValueError(f'Pipe {name}: outlet offset must be inside body')
            for side, sign in (('A', 1), ('B', -1)):
                tag = f'{name}:{i+1}:{side}'
                if tag in disabled:
                    continue
                position = (origin + offset*axis + sign*od/2*radial).tolist()
                control = {**pipe['control'], **overrides.get(tag, {})}
                add_port(tag, position, control)

    for item in layout.get('direct_ports', []):
        add_port(item['id'], item['position_m'], item['control'])
    if kind == 'injection' and not ports:
        raise ValueError('An injection layout requires at least one active outlet')
    if ports and len(np.unique([port['position_m'] for port in ports], axis=0)) != len(ports):
        raise ValueError('Duplicate outlet coordinates')

    cell_ports = {}
    for tag, cell in port_cells.items():
        cell_ports.setdefault(tuple(cell), []).append(tag)
    shared_cells = [
        dict(cell_zyx=list(cell), port_ids=tags)
        for cell, tags in cell_ports.items() if len(tags) > 1
    ]
    cfg['ports'] = ports
    slurry = Slurry(**cfg.get('slurry', {}))
    if kind == 'no_injection':
        cfg['target_dry_solid_kg'] = 0.
        slurry_volume = 0.
    else:
        slurry_volume = slurry.volume_for_solid_mass(cfg['target_dry_solid_kg'])
    cfg['layout_metadata'] = dict(
        schema_version=1, layout_id=layout['id'], kind=kind, pipes=geometry,
        port_ids=list(port_cells), port_cells_zyx=port_cells, shared_cells=shared_cells,
        original_layout=layout,
        geometry_role='port coordinates/controls; no pipe-wall cut cells or internal pressure loss',
        planned_dose=dict(
            dry_solid_kg=cfg['target_dry_solid_kg'], slurry_m3=slurry_volume,
            carrier_water_m3=slurry_volume*(1-slurry.solid_volume_fraction),
        ),
    )
    return cfg


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('base');p.add_argument('layout');p.add_argument('--out',required=True);p.add_argument('--run',action='store_true');a=p.parse_args()
    cfg=compile_layout(json.loads(Path(a.base).read_text()),json.loads(Path(a.layout).read_text()));out=Path(a.out);out.mkdir(parents=True,exist_ok=True)
    (out/'compiled_input.json').write_text(json.dumps(cfg,indent=2)+'\n')
    if a.run:
        from .reactive_transport import solve
        r=solve(cfg,out,lambda v:print(json.dumps(v),flush=True));print(json.dumps(r['summary'],indent=2))
if __name__=='__main__':main()
