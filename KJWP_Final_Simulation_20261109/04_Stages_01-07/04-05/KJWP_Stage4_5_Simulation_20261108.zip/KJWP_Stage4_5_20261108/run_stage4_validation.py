import copy,json
from pathlib import Path
import numpy as np
from kjwp_stage1 import stage2
from kjwp_stage1.reactive_transport import solve,CellReaction
from kjwp_stage1.geochemistry import BatchConfig,simulate,MW_NO3,MW_S,MW_CALCITE
from kjwp_stage1.reaction_environment import ExposureSchedule
ROOT=Path(__file__).parent
def main():
    out=ROOT/'stage4_results';out.mkdir(exist_ok=True)
    cfg=json.loads((ROOT/'configs/stage4/coupled_small.json').read_text());off=copy.deepcopy(cfg);off['chemistry']['batch']['reactions_enabled']=False
    a=stage2.solve(off);b=solve(off,out/'reaction_off')
    differences={k:float(max(np.max(np.abs(x[k]-y[k])) for x,y in zip(a['fields'],b['fields']))) for k in a['fields'][0] if k!='time_s'}
    assert max(differences.values())==0;print('reaction-off exact Stage2 match',flush=True)
    cell_checks=[]
    for area in ('shrinking_sphere','fixed_specific_area'):
        c=BatchConfig(duration_days=1,output_count=25,calcite_area_model=area,rtol=1e-9,atol_mol=1e-14)
        ref=simulate(c)['records'][-1];cell=CellReaction(c);n=c.nitrate_mg_per_kgw/(MW_NO3*1000)
        sp=cell.speciation.calculate(c,n,c.sulfate_mol_per_kgw,c.calcium_mol_per_kgw,c.dic_mol_per_kgw)
        xi,eta=cell.advance((n,c.sulfate_mol_per_kgw,c.calcium_mol_per_kgw,c.dic_mol_per_kgw,sp['Na'],c.chloride_mol_per_kgw),c.sulfur_g_per_kgw/MW_S,c.calcite_g_per_kgw/MW_CALCITE,86400,ExposureSchedule([],24,None,0).state(0),100)
        error=abs((n-xi)*MW_NO3*1000-ref['NO3_mg_kgw']);assert error<1e-7;cell_checks.append(dict(area_model=area,no3_error_mg_kgw=error))
    cfg['initial_attached_kg_m3_soil']={'sulfur':.03,'caco3':.01};cfg.update(end_s=10800.,save_times_s=[0,3600,10800.])
    runs=[]
    for dt in (1200.,600.,300.):
        c=copy.deepcopy(cfg);c['max_dt_s']=dt;r=solve(c,out/f'dt_{int(dt)}');runs.append(r)
        print(json.dumps({'dt':dt,'reacted_mg':r['summary']['denitrification_removed_kg']*1e6,'seconds':r['summary']['elapsed_s']}),flush=True)
    convergence=[]
    for a,b in zip(runs,runs[1:]):
        va=a['fields'][-1]['NO3_kg_m3_carrier'];vb=b['fields'][-1]['NO3_kg_m3_carrier'];w=b['fields'][-1]['theta']
        convergence.append(dict(coarse_dt_s=a['config']['max_dt_s'],fine_dt_s=b['config']['max_dt_s'],water_weighted_L1_relative=float(np.sum(w*np.abs(va-vb))/np.sum(w*vb)),reacted_mass_relative_difference=abs(a['summary']['denitrification_removed_kg']/b['summary']['denitrification_removed_kg']-1)))
    assert convergence[1]['water_weighted_L1_relative']<convergence[0]['water_weighted_L1_relative'];assert convergence[1]['water_weighted_L1_relative']<.01
    balances=[]
    for r in runs:
        a,b=r['history'][0],r['history'][-1]
        residuals={s:abs(b[s+'_residual_kg'])/max(a[s+'_stored_kg']+b[s+'_in_kg']+abs(b[s+'_reaction_net_kg']),1e-20) for s in ('NO3','tracer','sulfur','caco3','SO4','Ca','DIC','Na','Cl','NO3_passive')}
        assert max(residuals.values())<1e-9
        balances.append(dict(dt_s=r['config']['max_dt_s'],relative_residuals=residuals,passive_shadow_identity_residual_kg=b['NO3_passive_stored_kg']-b['NO3_stored_kg']+b['NO3_passive_out_kg']-b['NO3_out_kg']-b['NO3_reacted_kg'],water_residual_m3=b['water_residual_m3']))
    result=dict(status='PASS',zero_reaction_field_max_differences=differences,closed_cell_comparison=cell_checks,time_refinement=convergence,mass_balances=balances,limits='No full reactive OGS benchmark, spatial convergence or experiment. First-order splitting.')
    (out/'VALIDATION.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
