"""Run explicit layout jobs with common soil and forcing."""
import argparse
import hashlib
import json
import math
from pathlib import Path

from kjwp_stage1.layout import compile_layout
from kjwp_stage1.reactive_transport import solve


def write_json(path, value):
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + '\n'
    tmp = path.with_suffix('.tmp')
    tmp.write_text(raw, encoding='utf-8')
    tmp.replace(path)
    return raw


def summarize_run(summary, metadata):
    final = summary['final']
    available = summary['initial']['NO3_stored_kg'] + final['NO3_in_kg']
    port_water = summary['port_water_m3']
    actual_water = math.fsum(port_water)
    actual_solid = summary['dose']['injected_dry_solid_kg']
    planned = metadata['planned_dose']
    actual_matches = (
        math.isclose(actual_solid, planned['dry_solid_kg'], rel_tol=2e-12)
        and math.isclose(actual_water, planned['carrier_water_m3'], rel_tol=2e-12)
    )
    return dict(
        status='finished', dose_completed=summary['dose']['done'],
        actual_dose_matches_plan=actual_matches,
        actual_dry_solid_kg=actual_solid, actual_carrier_water_m3=actual_water,
        port_carrier_water_m3=dict(zip(metadata['port_ids'], port_water, strict=True)),
        injection_completion_s=summary['injection_completion_s'],
        NO3_reacted_kg=final['NO3_reacted_kg'], NO3_available_kg=available,
        NO3_reacted_fraction=final['NO3_reacted_kg']/available if available > 0 else None,
        NO3_out_kg=final['NO3_out_kg'], NO3_bottom_out_kg=final['NO3_bottom_out_kg'],
        NO3_remaining_kg=final['NO3_stored_kg'], NO3_balance_residual_kg=final['NO3_residual_kg'],
    )


def run_batch(manifest, out, compile_only=False):
    manifest = Path(manifest).resolve()
    data = json.loads(manifest.read_text(encoding='utf-8'))
    if data.get('schema_version') != 1:
        raise ValueError('schema_version must be 1')
    base = json.loads((manifest.parent/data['base']).read_text(encoding='utf-8'))
    jobs = {}
    planned = None
    for job in data['jobs']:
        name = job['id']
        if (not isinstance(name, str) or not name or name.casefold() in jobs
                or any(c not in 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-' for c in name)):
            raise ValueError('Invalid or duplicate job id')
        layout = json.loads((manifest.parent/job['layout']).read_text(encoding='utf-8'))
        cfg = compile_layout(base, layout)
        meta = cfg['layout_metadata']
        if meta['kind'] == 'injection':
            if planned is not None and meta['planned_dose'] != planned:
                raise ValueError('Unequal planned dose')
            planned = meta['planned_dose']
        jobs[name.casefold()] = (name, cfg)
    if not jobs:
        raise ValueError('At least one job required')

    out = Path(out)
    out.mkdir(parents=True, exist_ok=False)
    rows = []

    def save_progress():
        finished = len(rows) == len(jobs) and all(row['status'] == 'finished' for row in rows)
        injected = [row for row in rows if row['kind'] == 'injection']
        ready = finished and len(injected) >= 2 and all(
            row['dose_completed'] and row['actual_dose_matches_plan'] for row in rows
        )
        return write_json(out/'batch_summary.json', dict(
            schema_version=1, jobs=rows, requested_job_count=len(jobs),
            all_requested_jobs_finished=finished, comparison_ready=ready,
        ))

    for name, cfg in jobs.values():
        folder = out/name
        folder.mkdir()
        raw = write_json(folder/'compiled_input.json', cfg)
        meta = cfg['layout_metadata']
        row = dict(
            id=name, kind=meta['kind'], input_sha256=hashlib.sha256(raw.encode()).hexdigest(),
            status='compiled' if compile_only else 'running', planned_dose=meta['planned_dose'],
            shared_cells=meta['shared_cells'],
        )
        rows.append(row)
        save_progress()
        if compile_only:
            continue
        try:
            result = solve(cfg, folder, lambda v: print(json.dumps(dict(job=name, **v)), flush=True))
            row.update(summarize_run(result['summary'], meta))
        except Exception as exc:
            row.update(status='failed', error=str(exc))
            save_progress()
            raise
        save_progress()
    return rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('manifest')
    parser.add_argument('--out', required=True)
    parser.add_argument('--compile-only', action='store_true')
    args = parser.parse_args()
    print(json.dumps(run_batch(args.manifest, args.out, args.compile_only), indent=2))


if __name__ == '__main__':
    main()
