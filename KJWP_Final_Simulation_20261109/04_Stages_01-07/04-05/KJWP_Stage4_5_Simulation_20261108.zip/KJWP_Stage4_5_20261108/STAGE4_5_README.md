# KJWP Stage 4 결합 및 Stage 5 배치 검토 · v0.5.1

`KJWP_Stage4_5_Report_20261108.html`을 브라우저로 열면 실제 저장된 계산 결과를 볼 수 있다. 인터넷이나 재계산이 필요 없다.

4단계는 기존 압력 기반 Richards–MUSCL–입자 엔진에 성분 수송·PHREEQC 반응을 연결한다. 5단계는 서비스관 1개, 측면 출구 6개를 좌표로 변환해 48시간 계산하는 샘플이다. 최종 배치 선정, CAD 해석 격자 생성, 최종 UI, 실험 검증은 완료하지 않았다.

## 재실행

Python 3.10 이상, PhreeqPython 1.6.2. 이번 실행은 Linux/Python 3.12에서 검증했다. Windows BAT는 제공하지만 Windows 실행 검증은 하지 않았다.

```bash
python -m pip install -e ".[geochemistry,test]"
python -m pytest -q
python run_stage4_validation.py
python -m kjwp_stage1.layout configs/stage5/base_sample.json configs/stage5/layout_sample.json --out stage5_results/sample --run
python build_stage4_5_report.py
```

계산은 기기 성능에 따라 수분 이상 걸릴 수 있다. 저장된 결과를 보는 데 실행은 필요 없다.

## 다음 모델링 작업

`docs/STAGE5_HANDOFF.md`를 다른 채팅에 함께 전달한다. 공통 조건은 base_sample.json, 관/출구 위치·각도·제어는 layout_sample.json으로 분리했다. run_layout_batch.py는 주어진 후보들을 자동 실행하며 최적화 알고리즘은 아니다. 같은 base를 쓰는 무주입 대조군, 출구별 제어, 격자 셀 공유 진단, 실제 고체량·운반수량 판정 및 바닥 질산염 유출량을 추가했다. 90초 배치 검증 요약은 stage5_results/review에 있다.

## 파일

- stage4_results/VALIDATION.json — 무반응·단일셀·수지·시간 수렴.
- stage5_results/sample — 48시간 샘플 입력, 시간 수지 CSV, 3D NPZ, 출구별 투입량.
- stage5_results/batch_execution_check — 짧은 실제 배치 자동 실행 검사.
- docs/STAGE4_METHODS.md, STAGE4_REFERENCES.md — 식/단위/가정/논문.
- stage2_validated_engine — 기존 독립 OGS 비교 보관본. 이번 압력·입자·반응 전체의 OGS 검증을 의미하지 않는다.
- 이전 Stage 1–3 보고서와 코드도 포함되어 있다. 이 ZIP의 최신 실행 안내는 이 파일이다.
