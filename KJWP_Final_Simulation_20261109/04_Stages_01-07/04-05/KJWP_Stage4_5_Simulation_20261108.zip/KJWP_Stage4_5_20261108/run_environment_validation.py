"""Run explicit scenario inputs and verify the environmental extension."""
from dataclasses import asdict, replace
from pathlib import Path
import csv
import json
import numpy as np

from kjwp_stage1.geochemistry import BatchConfig, simulate, save_result
from kjwp_stage1.reaction_environment import EnvironmentPeriod

ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT / 'environment_results'


def contact_case(base, hours):
    return replace(base, environment_periods=(EnvironmentPeriod(),
        EnvironmentPeriod(start_hour=hours, in_contact=False)))


def main():
    OUTPUT.mkdir(exist_ok=True)
    config_directory = ROOT / 'configs/environment'
    config_directory.mkdir(exist_ok=True)
    base = BatchConfig()
    cases = {'reference': base, 'no_contact': replace(base,
        environment_periods=(EnvironmentPeriod(in_contact=False),))}
    for oxygen in (0.5, 3.0, 6.0):
        cases[f'oxygen_{oxygen:g}'] = replace(base, oxygen_half_inhibition_mg_L=1,
            environment_periods=(EnvironmentPeriod(dissolved_oxygen_mg_L=oxygen),))
    cases['oxygen_6_KI4'] = replace(cases['oxygen_6'], oxygen_half_inhibition_mg_L=4)
    cases['activity_10_percent'] = replace(base,
        environment_periods=(EnvironmentPeriod(active_fraction=0.1),))
    cases['lag_24_hours'] = replace(base, microbial_lag_hours=24)
    for hours in (5/60, 3, 12, 24, 48):
        label = '5min' if hours < 1 else f'{hours:g}h'
        cases[f'contact_{label}'] = contact_case(base, hours)
    cases['oxygen_drop_after_24h'] = replace(base, oxygen_half_inhibition_mg_L=1,
        environment_periods=(EnvironmentPeriod(dissolved_oxygen_mg_L=6),
            EnvironmentPeriod(start_hour=24, dissolved_oxygen_mg_L=0.2)))
    results = {}
    summary = []
    for name, config in cases.items():
        result = simulate(config)
        results[name] = result
        save_result(result, OUTPUT / name)
        (config_directory / f'{name}.json').write_text(json.dumps(asdict(config), indent=2))
        rows = result['records']
        final = rows[-1]
        at_24h = next(row for row in rows if abs(row['day'] - 1) < 1e-12)
        t90 = next((row['day'] * 24 for row in rows if row['NO3_mg_kgw'] <= 4), None)
        summary.append({
            'case': name, 'NO3_at_24h_mg_kgw': at_24h['NO3_mg_kgw'],
            'NO3_final_mg_kgw': final['NO3_mg_kgw'],
            'reaction_at_24h_percent': at_24h['reacted_NO3_mg_kgw'] / 40 * 100,
            'reaction_final_percent': final['reacted_NO3_mg_kgw'] / 40 * 100,
            't90_first_output_hours': t90,
            'contact_hours': final['prescribed_contact_hours'],
            'weighted_contact_hours': final['activity_oxygen_weighted_contact_hours'],
            'pH_min': min(row['pH'] for row in rows),
            'pH_final': final['pH'],
        })
        print(name, '24h reacted', round(summary[-1]['reaction_at_24h_percent'], 3),
              'percent; t90 hours', t90, flush=True)
    baseline = json.loads((ROOT / 'stage3_results/mixed/result.json').read_text())
    current = results['reference']['records']
    baseline_error = max(abs(old[key] - new[key])
        for old, new in zip(baseline['records'], current) for key in old)
    assert len(baseline['records']) == len(current)
    checks = {'legacy_max_absolute_field_difference': baseline_error,
              'max_balance_residual_mol_or_eq_kgw': max(
                  max(result['validation'].values()) for result in results.values())}
    comparisons = []
    for name in ('contact_5min', 'oxygen_drop_after_24h', 'lag_24_hours'):
        fine = simulate(replace(cases[name], max_step_days=0.0125, rtol=1e-10, atol_mol=1e-14))
        coarse = results[name]
        comparisons.append({'case':name,
            'max_NO3_difference_mg_kgw': max(abs(a['NO3_mg_kgw']-b['NO3_mg_kgw'])
                 for a,b in zip(coarse['records'],fine['records'])),
            'max_pH_difference': max(abs(a['pH']-b['pH'])
                 for a,b in zip(coarse['records'],fine['records']))})
    checks['time_step_comparisons'] = comparisons
    checks['all_passed'] = bool(baseline_error < 1e-10
        and checks['max_balance_residual_mol_or_eq_kgw'] < 1e-10
        and all(row['max_NO3_difference_mg_kgw'] < 0.002
                and row['max_pH_difference'] < 1e-4 for row in comparisons))
    checks['cases'] = summary
    checks['oxygen_response'] = {
        'law':'KI/(KI+DO)', 'KI_mg_L_scenario_values':[1,4],
        'status':'Uncalibrated sensitivity assumptions; literature supports condition dependence, not these parameter values.'}
    checks['omitted_processes'] = ['endogenous oxygen consumption and gas transport',
        'aerobic sulfur oxidation', 'biomass growth/decay and nutrient limitation',
        'hydrodynamic residence-time distribution']
    (OUTPUT / 'VALIDATION.json').write_text(json.dumps(checks,indent=2))
    with (OUTPUT / 'summary.csv').open('w',newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=summary[0])
        writer.writeheader()
        writer.writerows(summary)
    print(json.dumps({key:value for key,value in checks.items() if key != 'cases'},indent=2))
    if not checks['all_passed']:
        raise RuntimeError('Environmental validation failed')


if __name__ == '__main__':
    main()
