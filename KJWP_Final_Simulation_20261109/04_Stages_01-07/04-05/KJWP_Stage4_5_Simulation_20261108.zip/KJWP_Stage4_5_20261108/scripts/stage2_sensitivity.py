"""Stage 2: physical symmetry, rate response and source-budget verification."""
import copy
import json
from pathlib import Path
import numpy as np
from kjwp_stage1.transient_cli import build,write_outputs
from kjwp_stage1.numerics.transient import solve_transient


def main():
    config=json.loads(Path('configs/stage2_injection.json').read_text(encoding='utf-8'))
    out=Path('outputs/spec_3_1/stage2_checks');out.mkdir(parents=True,exist_ok=True)
    results={};rows=[]
    for name in ('baseline','mirror_x','half_rate','no_injection'):
        c=copy.deepcopy(config)
        if name=='mirror_x': c['injections'][0]['position_m'][0]=.275
        if name=='half_rate': c['injections'][0]['rate_m3_s']*=.5
        if name=='no_injection': c['injections']=[]
        f,h,init,args=build(c);r=solve_transient(f,h,init,**args);results[name]=r
        write_outputs(r,f.grid,c,out/name)
        z,y,x=f.grid.mesh_zyx();tr=r.theta[-1]*r.concentration['tracer'][-1]*f.grid.volume
        total=float(tr.sum())
        centroid=[float((tr*a).sum()/total) if total else None for a in (x,y,z)]
        q,_=f.faces_and_matrix(r.head_m[-1],r.times_s[-1])
        inj=c['injections'][0] if c['injections'] else None
        expected=inj['rate_m3_s']*(inj['end_s']-inj['start_s']) if inj else 0.
        b=r.history[-1]
        rows.append(dict(case=name,expected_water_input_m3=expected,numerical_water_input_m3=b['water_in_m3'],
            tracer_input_kg=b['tracer']['in_kg'],expected_tracer_input_kg=expected*.04,
            nitrate_mass_change_kg=b['NO3']['stored_kg']-b['NO3']['initial_kg'],
            nitrate_min_mg_L=b['NO3']['min_kg_m3']*1000,
            tracer_centroid_xyz_m=centroid,max_head_change_m=float(np.abs(r.head_m[-1]-r.head_m[0]).max()),
            max_lateral_flux_m_s=max(float(np.abs(v).max()) for v in q[:2]),
            water_relative_residual=b['water_relative_residual'],tracer_relative_residual=b['tracer']['relative_residual']))
    a=results['baseline'];b=results['mirror_x']
    diff=float(np.abs(a.concentration['tracer'][-1,...,::-1]-b.concentration['tracer'][-1]).max())
    baseline=rows[0];half=rows[2];none=rows[3]
    checks=dict(mirror_x_max_concentration_difference_kg_m3=diff,
        mirror_symmetry_passed=diff<1e-10,
        exact_water_and_tracer_supply_passed=all(abs(r['numerical_water_input_m3']-r['expected_water_input_m3'])<1e-14
            and abs(r['tracer_input_kg']-r['expected_tracer_input_kg'])<1e-15 for r in rows),
        nitrate_not_destroyed_passed=all(abs(r['nitrate_mass_change_kg'])<1e-13 for r in rows),
        rate_response_passed=baseline['max_head_change_m']>half['max_head_change_m']>none['max_head_change_m']
            and baseline['max_lateral_flux_m_s']>half['max_lateral_flux_m_s']>1e-16,
        no_source_equilibrium_passed=none['max_head_change_m']<1e-12)
    passed=all(v for k,v in checks.items() if k.endswith('_passed'))
    (out/'checks.json').write_text(json.dumps(dict(passed=passed,checks=checks,cases=rows),indent=2),encoding='utf-8')
    print(json.dumps(dict(passed=passed,checks=checks,cases=rows),indent=2),flush=True)
    if not passed: raise SystemExit(1)


if __name__=='__main__': main()
