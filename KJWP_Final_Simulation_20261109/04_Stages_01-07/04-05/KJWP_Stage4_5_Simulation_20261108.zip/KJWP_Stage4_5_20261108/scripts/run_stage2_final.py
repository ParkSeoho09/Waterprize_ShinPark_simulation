"""Reproducible Stage 2 implementation checks, not experimental validation.

Run from project root: python scripts/run_stage2_final.py
Each case writes its own exact input, summary, time history and 3D arrays.
"""
import copy
import json
from pathlib import Path
import sys
import time
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from kjwp_stage1.stage2 import solve

OUT=ROOT/'outputs/stage2_final'


def main():
    import argparse
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--cases',nargs='*',help='rerun named cases only; require matching existing inputs for all others')
    args=parser.parse_args()
    base=json.loads((ROOT/'configs/stage2_pressure_particles.json').read_text())
    cases={}
    for name,pressure in [('low_pressure',3000.),('high_pressure',10000.),('insufficient_window',1000.)]:
        c=copy.deepcopy(base); c['ports'][0]['outlet_gauge_pressure_Pa']=pressure
        if name=='insufficient_window': c['ports'][0]['end_s']=301.
        c['case_name']=name; cases[name]=c
    c=copy.deepcopy(base); c['ports'][0]['outlet_gauge_pressure_Pa']=-1e6
    c['case_name']='no_injection_check_valve_closed'; cases['no_injection']=c
    c=copy.deepcopy(base); c['ports'][0]['position_m'][0]=.1125
    c['case_name']='mirror_x'; cases['mirror_x']=c
    c=copy.deepcopy(base); c['retention']={}; c['case_name']='no_retention'
    cases['no_retention']=c
    c=copy.deepcopy(base); c['settling_reduction']=0.; c['case_name']='no_settling'
    cases['no_settling']=c
    for name,dt in [('dt30',30.),('dt15',15.)]:
        c=copy.deepcopy(base); c['max_dt_s']=dt; c['case_name']=name; cases[name]=c
    c=copy.deepcopy(base); c['grid']['cells_xyz']=[12,12,24]
    c['case_name']='grid12'; cases['grid12']=c
    # Always re-run base when explicitly invoking this reproducibility script.
    cases={'base':base,**cases}
    durations={}
    previous=OUT/'implementation_checks.json'
    if previous.exists():
        durations={n:v['elapsed_s'] for n,v in json.loads(previous.read_text())['cases'].items()}
    if args.cases is not None and set(args.cases)-set(cases):
        parser.error('unknown case name')
    for name,c in cases.items():
        if args.cases is not None and name not in args.cases:
            saved=json.loads((OUT/name/'input.json').read_text())
            if saved!=c: raise ValueError('stored input differs: rerun '+name)
            durations.setdefault(name,None)
            continue
        start=time.monotonic()
        print('RUN',name,flush=True)
        solve(c,OUT/name)
        durations[name]=time.monotonic()-start
        print('DONE',name,round(durations[name],3),'s',flush=True)
    summaries={n:json.loads((OUT/n/'summary.json').read_text()) for n in cases}
    check={}
    for n,s in summaries.items():
        f=s['final']; start=s['initial']
        mass_errors={p:abs(f[p+'_residual_kg'])/(f[p+'_in_kg']+start[p+'_stored_kg'])
                     for p in ('NO3','tracer','sulfur','caco3')
                     if f[p+'_in_kg']+start[p+'_stored_kg']>0}
        check[n]=dict(max_species_relative_mass_residual=max(mass_errors.values()),
          species_relative_mass_residuals=mass_errors,
          water_relative_residual_to_throughput=abs(f['water_residual_m3'])/(f['water_in_m3']+f['water_out_m3']),
          solid_relative_dose_error=abs(s['dose']['solid_dose_residual_kg'])/s['dose']['target_dry_solid_kg'],
          dose_done=s['dose']['done'],injection_completion_s=s['injection_completion_s'],
          elapsed_s=durations[n])
    a=np.load(OUT/'base/fields.npz'); b=np.load(OUT/'mirror_x/fields.npz')
    mirror={key:float(np.max(np.abs(a[key]-b[key][...,::-1]))) for key in a.files if a[key].ndim==4}
    temporal=[]
    for coarse,fine in [('base','dt30'),('dt30','dt15')]:
        ca=np.load(OUT/coarse/'fields.npz'); fi=np.load(OUT/fine/'fields.npz')
        # Conservative particle bulk density, not just aqueous concentration.
        pa=sum(ca['theta'][-1]*ca[p+'_kg_m3_carrier'][-1]+ca[p+'_attached_kg_m3_soil'][-1]
               +ca[p+'_strained_kg_m3_soil'][-1] for p in ('sulfur','caco3'))
        pb=sum(fi['theta'][-1]*fi[p+'_kg_m3_carrier'][-1]+fi[p+'_attached_kg_m3_soil'][-1]
               +fi[p+'_strained_kg_m3_soil'][-1] for p in ('sulfur','caco3'))
        tstart=base['ports'][0]['start_s']
        c0=summaries[coarse]['injection_completion_s']-tstart
        c1=summaries[fine]['injection_completion_s']-tstart
        temporal.append(dict(coarse=coarse,fine=fine,
          particle_total_bulk_relative_L1=float(np.abs(pa-pb).sum()/np.abs(pb).sum()),
          completion_relative_difference=abs(c0-c1)/c1,
          head_RMSE_m=float(np.sqrt(np.mean((ca['head_m'][-1]-fi['head_m'][-1])**2)))))
    grid=dict(coarse='base',fine='grid12',
        completion_relative_difference=abs(summaries['base']['injection_completion_s']-
          summaries['grid12']['injection_completion_s'])/(summaries['grid12']['injection_completion_s']-base['ports'][0]['start_s']),
        completion_time_basis='duration from injection start, excluding preceding 300 s',
        retained_sulfur_relative_difference=abs(summaries['base']['final']['sulfur_attached_kg']+
          summaries['base']['final']['sulfur_strained_kg']-
          summaries['grid12']['final']['sulfur_attached_kg']-
          summaries['grid12']['final']['sulfur_strained_kg'])/
          (summaries['grid12']['final']['sulfur_attached_kg']+summaries['grid12']['final']['sulfur_strained_kg']),
        status='two-grid sensitivity screen only; no established mesh convergence order')
    requirements={
      'mass_conservation_1e_10': all(v['max_species_relative_mass_residual']<1e-10 for v in check.values()),
      'water_throughput_residual_1e_7': all(v['water_relative_residual_to_throughput']<1e-7 for v in check.values()),
      'same_dose_1e_12': all(v['dose_done'] and v['solid_relative_dose_error']<1e-12 for n,v in check.items()
                             if n not in ('no_injection','insufficient_window')),
      'incomplete_dose_honestly_flagged': (not check['insufficient_window']['dose_done'] and
                                          summaries['insufficient_window']['injection_completion_s'] is None),
      'mirror_1e_10': max(mirror.values())<1e-10,
      'no_injection_zero_solid': summaries['no_injection']['dose']['injected_dry_solid_kg']==0.,
      'pressure_completion_order': (all(summaries[n]['injection_completion_s'] is not None for n in
                                  ('high_pressure','base','low_pressure')) and
                                  summaries['high_pressure']['injection_completion_s']<
                                  summaries['base']['injection_completion_s']<summaries['low_pressure']['injection_completion_s']),
      'no_retention_zero_retained': all(summaries['no_retention']['final'][p+'_'+pool+'_kg']==0.
                                      for p in ('sulfur','caco3') for pool in ('attached','strained')),
      'temporal_difference_decreases': temporal[1]['particle_total_bulk_relative_L1']<temporal[0]['particle_total_bulk_relative_L1'],
    }
    report=dict(cases=check,mirror_max_absolute_differences=mirror,time_refinement=temporal,
                grid_sensitivity=grid,implementation_requirements=requirements,
                status='implementation checks only; independent OGS and physical experiments pending')
    (OUT/'implementation_checks.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2),flush=True)
    if not all(requirements.values()): raise SystemExit('Some implementation requirements failed: see JSON')


if __name__=='__main__': main()
