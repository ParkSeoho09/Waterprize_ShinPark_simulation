"""Reproducible numerical verification, not field validation or OGS comparison."""
from pathlib import Path
import json
import sys
import numpy as np
from scipy.integrate import solve_ivp
from scipy.special import erf
from kjwp_stage1.core.grid import Grid
from kjwp_stage1.flow.hydraulics import CeliaHaverkamp
from kjwp_stage1.flow.richards import RichardsFlow, WaterBoundary
from kjwp_stage1.physics.boundary import FACES, Boundary
from kjwp_stage1.numerics.transient import solve_transient


class VerificationSoil:
    """Artificial linear retention, constant K: verification only."""
    ks_m_s = 1e-5
    def theta(self, h): return .4 + .05*h
    def capacity(self, h): return np.full_like(h, .05)
    def relative_k(self, h): return np.ones_like(h)


def eigenmode():
    spatial=[]
    for n in (6, 10, 16):
        g=Grid((.3,.4,.5),(n,n,n)); z,y,x=g.mesh_zyx()
        p=np.cos(np.pi*x/.3)*np.cos(np.pi*y/.4)*np.cos(np.pi*z/.5)
        f=RichardsFlow(g,VerificationSoil(),{a:WaterBoundary() for a in FACES},theta_tolerance=1e-12)
        dt=.5; lam=sum((np.pi/L)**2 for L in g.lengths_m)
        expected=z-2+.01*p/(1+dt*1e-5*lam/.05)
        actual=f.step(z-2+.01*p,0,dt).head
        spatial.append(dict(n=n,error=float(np.sqrt(np.mean((actual-expected)**2)))))
    for a,b in zip(spatial,spatial[1:]):
        b['order']=float(np.log(a['error']/b['error'])/np.log(b['n']/a['n']))
    g=Grid((.3,.4,.5),(6,6,6)); z,y,x=g.mesh_zyx()
    p=np.cos(np.pi*x/.3)*np.cos(np.pi*y/.4)*np.cos(np.pi*z/.5)
    lam=sum(4*np.sin(np.pi/(2*n))**2/dx**2 for n,dx in zip(g.cells_xyz,g.spacing_xyz))
    f=RichardsFlow(g,VerificationSoil(),{a:WaterBoundary() for a in FACES},theta_tolerance=1e-12)
    temporal=[]
    for dt in (2.,1.,.5):
        h=z-2+.01*p
        for t in np.arange(0,10,dt): h=f.step(h,float(t),dt).head
        exact=z-2+.01*p*np.exp(-1e-5*lam*10/.05)
        temporal.append(dict(dt_s=dt,error=float(np.sqrt(np.mean((h-exact)**2)))))
    for a,b in zip(temporal,temporal[1:]): b['order']=float(np.log2(a['error']/b['error']))
    return dict(spatial=spatial,temporal=temporal,
        passed=all(r['order']>1.9 for r in spatial[1:]) and all(r['order']>.9 for r in temporal[1:]))


def celia_reference():
    # Published Celia problem conditions, cell-centered FV discretization.
    # Independent theta-state BDF implementation on the SAME spatial grid.
    soil=CeliaHaverkamp(); nz=40; dz=.4/nz
    def rhs(t,theta):
        h=soil.head_from_theta(theta); k=soil.ks_m_s*soil.relative_k(h)
        q=np.empty(nz+1)
        q[1:-1]=-2*k[:-1]*k[1:]/(k[:-1]+k[1:])*(np.diff(h)/dz-1)
        q[0]=-k[0]*((h[0]+.207)/(dz/2)-1)
        q[-1]=-k[-1]*((-.615-h[-1])/(dz/2)-1)
        return -np.diff(q)/dz
    ref=solve_ivp(rhs,(0.,360.),np.full(nz,float(soil.theta(np.array(-.615)))),
                  method='BDF',rtol=1e-10,atol=1e-12,max_step=1.)
    if not ref.success: raise RuntimeError(ref.message)
    h_ref=soil.head_from_theta(ref.y[:,-1])
    g=Grid((.02,.02,.4),(2,2,nz)); b={a:WaterBoundary() for a in FACES}
    b['z-']=WaterBoundary('head',-.207); b['z+']=WaterBoundary('head',-.615)
    rows=[]
    for dt in (5.,2.5,1.25):
        f=RichardsFlow(g,soil,b,theta_tolerance=1e-12)
        r=solve_transient(f,np.full(g.shape,-.615),{'inert':np.zeros(g.shape)},
                          end_s=360,max_dt_s=dt,save_times_s=[360])
        h=r.head_m[-1,:,0,0]
        rows.append(dict(dt_s=dt,head_rmse_m=float(np.sqrt(np.mean((h-h_ref)**2))),
            water_relative_residual=r.history[-1]['water_relative_residual'],
            lateral_head_spread_m=float(np.ptp(r.head_m[-1],axis=(1,2)).max()),
            accepted_steps=r.metadata['steps'],rejected_steps=r.metadata['rejected_water_steps']))
    for a,b in zip(rows,rows[1:]): b['order']=float(np.log2(a['head_rmse_m']/b['head_rmse_m']))
    return dict(source='https://doi.org/10.5194/gmd-16-659-2023',
        comparison='independent BDF time integration of same FV spatial problem; NOT author output or external solver',
        reference_rtol=1e-10,reference_atol=1e-12,reference_max_step_s=1.,
        rows=rows,depth_m=g.centers_xyz[2].tolist(),reference_head_m=h_ref.tolist(),
        final_head_m=h.tolist(),
        passed=all(r['order']>.85 for r in rows[1:]) and all(r['water_relative_residual']<1e-7 for r in rows))


def transport_refinement(scheme='muscl_mc'):
    rows=[]
    # Smooth Gaussian, zero-gradient open boundary, negligible Gaussian tails.
    # First-order BE/upwind backend; not the old MUSCL second-order backend.
    for n in (60,120,240):
        g=Grid((.02,.02,1.),(2,2,n)); z,_,_=g.mesh_zyx(); edges=g.edges_xyz[2]
        s=VerificationSoil(); s.ks_m_s=1e-4
        b={a:WaterBoundary() for a in FACES}
        b['z-']=WaterBoundary('head',-.5);b['z+']=WaterBoundary('head',-.5)
        f=RichardsFlow(g,s,b,theta_tolerance=1e-12)
        theta=.4+.05*(-.5); u=s.ks_m_s/theta; sig=.035; D=1e-7; end=500.
        def avg(center,width):
            return .01*sig*np.sqrt(np.pi/2)*np.diff(erf((edges-center)/(np.sqrt(2)*width)))/np.diff(edges)
        c0=np.broadcast_to(avg(.25,sig)[:,None,None],g.shape).copy()
        exact=avg(.25+u*end,np.sqrt(sig**2+2*D*end))
        cb={a:Boundary('closed' if v.kind=='closed' else 'inflow_flux',0.) for a,v in b.items()}
        r=solve_transient(f,np.full(g.shape,-.5),{'test':c0},end_s=end,
            max_dt_s=end/(n/2),save_times_s=[end],dispersion_m2_s=(0.,0.,D),
            solute_boundaries={'test':cb},transport_scheme=scheme)
        actual=r.concentration['test'][-1,:,0,0]
        rows.append(dict(nz=n,dt_s=end/(n/2),normalized_L1=float(np.abs(actual-exact).sum()/np.abs(exact).sum()),
                         relative_mass_residual=r.history[-1]['test']['relative_residual']))
    for a,b in zip(rows,rows[1:]): b['order']=float(np.log2(a['normalized_L1']/b['normalized_L1']))
    return dict(rows=rows,scheme=scheme,absolute_accuracy_gate=.05,
        accuracy_gate_passed=rows[-1]['normalized_L1']<.05,
        passed=all(r['order']>.6 for r in rows[1:]) and all(r['relative_mass_residual']<1e-10 for r in rows)
            and (scheme!='muscl_mc' or rows[-1]['normalized_L1']<.05))


def main():
    out=Path(sys.argv[1] if len(sys.argv)>1 else 'outputs/spec_3_1/extended_verification')
    out.mkdir(parents=True,exist_ok=True)
    report={}
    for name,fn in [('eigenmode',eigenmode),('celia_reference',celia_reference),('transport_refinement',transport_refinement),
                    ('first_order_baseline',lambda:transport_refinement('implicit_upwind'))]:
        report[name]=fn()
        print(name,json.dumps({k:v for k,v in report[name].items() if k not in ('depth_m','reference_head_m','final_head_m')},ensure_ascii=False),flush=True)
        (out/'verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    if not all(x['passed'] for x in report.values()): raise SystemExit(1)


if __name__=='__main__': main()
