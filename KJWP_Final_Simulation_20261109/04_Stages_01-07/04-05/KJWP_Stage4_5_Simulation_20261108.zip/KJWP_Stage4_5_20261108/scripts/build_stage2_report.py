"""Build a self-contained Stage 2 HTML report from saved calculated fields.

No synthetic drawing of plumes; every graph reads CSV/NPZ solver outputs.
"""
import base64
import csv
import html
import json
from pathlib import Path
import re
import sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'outputs/stage2_final'
FIG=OUT/'figures'
COLORS=['#2b6f6b','#bf712b','#6357a4','#b2515a']


def finish(fig,name):
    p=FIG/name
    fig.savefig(p,dpi=145,bbox_inches='tight',facecolor='white')
    plt.close(fig)
    return p


def img(path,alt):
    return '<img class="plot" alt="'+html.escape(alt)+'" src="data:image/png;base64,'+base64.b64encode(path.read_bytes()).decode()+'">'


def table(headers,rows):
    return '<div class="scroll"><table><thead><tr>'+''.join('<th>'+str(x)+'</th>' for x in headers)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+str(x)+'</td>' for x in row)+'</tr>' for row in rows)+'</tbody></table></div>'


def main():
    FIG.mkdir(exist_ok=True)
    checks=json.loads((OUT/'implementation_checks.json').read_text())
    summaries={n:json.loads((OUT/n/'summary.json').read_text()) for n in checks['cases']}
    histories={}
    for n in summaries:
        with (OUT/n/'history.csv').open() as f:
            rows=list(csv.DictReader(f))
            histories[n]={k:np.array([float(r[k]) for r in rows]) for k in rows[0]}
    cfg=json.loads((OUT/'base/input.json').read_text())
    data=np.load(OUT/'base/fields.npz')
    base=summaries['base']; f=base['final']; initial=base['initial']
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,
                         'axes.spines.right':False,'axes.grid':True,'grid.alpha':.18})
    fig,axes=plt.subplots(2,2,figsize=(11.6,7.4),layout='constrained')
    for n,label,color in zip(('low_pressure','base','high_pressure'),('3 kPa','5 kPa','10 kPa'),COLORS):
        h=histories[n]; tt=h['time_s']/60
        axes[0,0].step(tt,h['slurry_rate_m3_s']*1e6,where='pre',label=label,color=color)
        axes[0,1].plot(tt,(h['sulfur_inlet_kg']+h['caco3_inlet_kg'])*1e3,label=label,color=color)
    axes[0,0].set(title='Outlet pressure determines slurry flow',xlabel='Time from simulation start (min)',ylabel='Step-average slurry rate (mL/s)')
    axes[0,1].set(title='Same total dry-solid dose',xlabel='Time from simulation start (min)',ylabel='Cumulative inlet solids (g)')
    axes[0,1].axhline(cfg['target_dry_solid_kg']*1e3,color='gray',linestyle=':',label='Target')
    axes[0,0].set_xlim(0,12)
    axes[0,1].set_xlim(0,12)
    h=histories['base']; tt=h['time_s']/60
    for pool,label,color in zip(('mobile','attached','strained'),('Mobile','Attached (reversible)','Strained'),COLORS):
        axes[1,0].plot(tt,(h['sulfur_'+pool+'_kg']+h['caco3_'+pool+'_kg'])*1e6,label=label,color=color)
    axes[1,0].set(title='Particle mass pools, 5 kPa example',xlabel='Time from simulation start (min)',ylabel='S + CaCO3 mass (mg)')
    axes[1,1].plot(tt,(h['NO3_stored_kg']+h['NO3_out_kg'])*1e6,label='Stored + out',color=COLORS[0])
    axes[1,1].plot(tt,(initial['NO3_stored_kg']+h['NO3_in_kg'])*1e6,label='Initial + in',color=COLORS[1],linestyle='--')
    axes[1,1].set(title='Nitrate balance: no denitrification',xlabel='Time from simulation start (min)',ylabel='NO3 ion mass (mg)')
    for ax in axes.ravel(): ax.legend(fontsize=8)
    overview=finish(fig,'history.png')
    x,y,z=(data[a+'_m'] for a in 'xyz')
    jy=int(np.argmin(np.abs(y-cfg['ports'][0]['position_m'][1])))
    mobile=sum(data['theta']*data[p+'_kg_m3_carrier'] for p in ('sulfur','caco3'))
    retained=sum(data[p+'_'+pool+'_kg_m3_soil'] for p in ('sulfur','caco3') for pool in ('attached','strained'))
    # Consistent colour limits across every saved time.
    series=[data['theta'],data['NO3_kg_m3_carrier']*1000,data['tracer_kg_m3_carrier']*1000,
            mobile,retained,data['head_m']]
    labels=['Carrier water content\n(m3/m3)','Nitrate\n(mg NO3 ion/L carrier)',
            'Conservative tracer\n(mg/L carrier)','Mobile S + CaCO3\n(kg/m3 soil)',
            'Retained S + CaCO3\n(kg/m3 soil)','Water reference pressure head\n(m)']
    maps=['Blues','viridis','viridis','magma','magma','coolwarm']
    slices=[]
    for k,t in enumerate(data['time_s']):
        fig,axes=plt.subplots(2,3,figsize=(12.,10.8),layout='constrained')
        for ax,arr,label,cmap in zip(axes.ravel(),series,labels,maps):
            lo=float(np.min(arr)); hi=float(np.max(arr))
            im=ax.imshow(arr[k,:,jy,:],origin='upper',extent=(0,cfg['grid']['lengths_m'][0],cfg['grid']['lengths_m'][2],0),
                         vmin=lo,vmax=hi if hi>lo else lo+1.,cmap=cmap,interpolation='nearest',aspect='equal')
            ax.set(title=label,xlabel='x (m)',ylabel='Depth z (m)'); ax.grid(False)
            ax.plot(cfg['ports'][0]['position_m'][0],cfg['ports'][0]['position_m'][2],marker='+',color='red',ms=8)
            fig.colorbar(im,ax=ax,shrink=.82)
        fig.suptitle(f'Calculated x-z slices at y={y[jy]:.4f} m; t={t/60:.1f} min')
        slices.append(finish(fig,f'slice_{k}.png'))
    total=(mobile+retained)[-1]
    zz,yy,xx=np.meshgrid(z,y,x,indexing='ij')
    threshold=.01*float(total.max()); mask=total>=threshold
    fig=plt.figure(figsize=(8.5,6.2),layout='constrained'); ax=fig.add_subplot(projection='3d')
    dots=ax.scatter(xx[mask],yy[mask],zz[mask],c=total[mask],s=30,cmap='magma',alpha=.8)
    ax.scatter(*cfg['ports'][0]['position_m'],c='deepskyblue',marker='*',s=170,label='Equivalent outlet')
    ax.set(xlim=(0,.2),ylim=(0,.2),zlim=(.4,0),xlabel='x (m)',ylabel='y (m)',zlabel='Depth z (m)',
           title='Calculated cell centres: total mobile + retained solids')
    ax.set_box_aspect((1,1,2)); ax.legend(loc='upper left',fontsize=8)
    ax.set_xticks([0,.05,.1,.15,.2]); ax.set_yticks([0,.05,.1,.15,.2])
    ax.tick_params(axis='both',labelsize=8)
    fig.colorbar(dots,ax=ax,shrink=.65,label='S + CaCO3 (kg/m3 soil)')
    cloud=finish(fig,'particles_3d.png')
    pressure_rows=[]
    for n in ('low_pressure','base','high_pressure','insufficient_window','no_injection'):
        s=summaries[n]; conf=json.loads((OUT/n/'input.json').read_text()); port=conf['ports'][0]
        t=s['injection_completion_s']
        duration='미달' if t is None else f'{(t-port["start_s"])/60:.3f}'
        name={'low_pressure':'3 kPa','base':'5 kPa 기준 예시','high_pressure':'10 kPa',
              'insufficient_window':'1 kPa / 공급 1초만 허용','no_injection':'밸브 닫힘 대조'}[n]
        pressure_rows.append([name,f'{s["dose"]["injected_dry_solid_kg"]*1e3:.6f}',
                             f'{s["dose"]["injected_slurry_volume_m3"]*1e6:.6f}',duration,
                             '목표 도달' if s['dose']['done'] else '미도달'])
    budget_rows=[]
    for p,label in [('NO3','질산염 이온'),('tracer','보존성 추적자'),('sulfur','황 입자'),('caco3','CaCO₃ 입자')]:
        budget_rows.append([label]+[f'{v:.6g}' for v in [initial[p+'_stored_kg']*1e6,f[p+'_in_kg']*1e6,
          f[p+'_mobile_kg']*1e6,f[p+'_attached_kg']*1e6,f[p+'_strained_kg']*1e6,f[p+'_out_kg']*1e6]]+
          [f'{f[p+"_residual_kg"]*1e6:.2e}'])
    time_rows=[[row['coarse']+' → '+row['fine'],f'{100*row["particle_total_bulk_relative_L1"]:.4f}%',
                f'{100*row["completion_relative_difference"]:.4f}%',f'{row["head_RMSE_m"]:.3e}'] for row in checks['time_refinement']]
    gd=checks['grid_sensitivity']; grid_diff=gd['completion_relative_difference']*100
    grid_warning='공간 수렴 미확정' if grid_diff>5 else '두 격자 진단; 수렴 차수 미확정'
    tests=(ROOT/'outputs/stage2_final_tests.txt').read_text()
    nt=re.search(r'Ran (\d+) tests',tests)
    if nt is None or not tests.rstrip().endswith('OK'): raise RuntimeError('unit test evidence missing or failed')
    failures=[n for n,v in checks['implementation_requirements'].items() if not v]
    maxmass=max(c['max_species_relative_mass_residual'] for c in checks['cases'].values())
    maxwater=max(c['water_relative_residual_to_throughput'] for c in checks['cases'].values())
    slice_content=''.join('<div class="frame" id="frame'+str(k)+'"'+(' hidden' if k else '')+'>'+img(p,f'계산 단면 t={data["time_s"][k]}초')+'</div>' for k,p in enumerate(slices))
    options=''.join(f'<option value="{k}">{t/60:g}분 (t={t:g}초)</option>' for k,t in enumerate(data['time_s']))
    requirement_rows=[[html.escape(n),'통과' if v else '<strong>미통과</strong>'] for n,v in checks['implementation_requirements'].items()]
    text=f'''<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>KJWP · Stage 2 계산 결과 v0.3.0</title><style>
:root{{--ink:#182e34;--muted:#57666a;--green:#21665e;--line:#dce4e1;--paper:#f3f5f1;--warn:#854a18}}
*{{box-sizing:border-box}}body{{margin:0;background:var(--paper);color:var(--ink);font:16px/1.75 system-ui,-apple-system,'Noto Sans KR','Malgun Gothic',sans-serif}}
header{{background:#183c3d;color:white;padding:50px max(24px,calc((100vw - 1120px)/2));border-bottom:7px solid #8fb8a0}}
.eyebrow{{font-size:13px;letter-spacing:.13em;color:#bcd7cb}}h1{{font-size:clamp(29px,4vw,44px);line-height:1.3;margin:14px 0}}header p{{max-width:870px;color:#d6e6df}}
main{{max-width:1170px;margin:auto;padding:25px}}section{{background:white;border:1px solid var(--line);border-radius:13px;padding:28px;margin:20px 0}}h2{{font-size:25px;line-height:1.4;margin:0 0 16px}}h3{{font-size:18px;margin:24px 0 10px}}p{{margin:10px 0}}.muted,.caption{{color:var(--muted);font-size:14px}}.pill{{display:inline-block;background:#285653;color:#e0f4eb;border-radius:30px;padding:3px 12px;margin:3px 5px 3px 0;font-size:13px}}
.cards{{display:grid;grid-template-columns:repeat(3,1fr);gap:15px;margin:20px 0}}.card{{padding:19px;background:#edf4ef;border-radius:9px}}.number{{font-size:30px;font-weight:700;line-height:1.3}}.card small{{display:block;color:var(--muted)}}
.note{{border-left:4px solid #b7793c;background:#fbf4e9;padding:16px 19px;border-radius:4px;margin:18px 0}}.plot{{max-width:100%;height:auto;display:block;margin:12px auto}}.scroll{{overflow-x:auto}}table{{border-collapse:collapse;width:100%;font-size:14px;margin:13px 0}}th,td{{text-align:left;padding:11px 13px;border-bottom:1px solid var(--line);vertical-align:top;white-space:nowrap}}th{{background:#edf2ed}}tbody tr:nth-child(even){{background:#fafbf8}}pre{{background:#142f33;color:#e7f1eb;padding:20px;border-radius:9px;overflow:auto;font-size:13px;line-height:1.8}}code{{font-family:ui-monospace,monospace}}a{{color:#20685f}}details{{margin:17px 0;border-top:1px solid var(--line);padding-top:15px}}summary{{cursor:pointer;font-weight:650}}select{{padding:9px 14px;border-radius:6px;border:1px solid #a8bbb2;font-size:15px;background:white}}.frame[hidden]{{display:none}}footer{{text-align:center;padding:20px;color:var(--muted);font-size:13px}}@media(max-width:700px){{.cards{{grid-template-columns:1fr}}main{{padding:12px}}section{{padding:19px}}}}
</style></head><body><header><div class="eyebrow">KJWP RESEARCH · COMPUTED REPORT · 2026.11.02</div><h1>Stage 2<br>3D 주입수·추적물질 이동 모델</h1><p>출구 압력, 슬러리 물성, 황·탄산칼슘 입자 이동·잔류, 같은 총고체량 종료를 연결한 <strong>v0.3.0 구현본</strong>이다. 아래 그림·표는 저장된 계산 배열과 시간 이력에서 생성했다.</p><span class="pill">반응 OFF · 탈질 제거량 0</span><span class="pill">대표 출구 1개</span><span class="pill">실험·OGS 검증 전</span></header>
<main><section><h2>이번에 연결한 계산</h2><p>압력을 주면 토양 수두에 따라 유량이 정해지고, 운반수와 추적자·두 입자가 이동한다. 입자 농도는 다음 수리 구간의 밀도·점도에 반영된다. 황과 CaCO₃는 각각 <strong>이동 · 가역 부착 · 비가역 걸러짐</strong> 저장량으로 나뉜다.</p>
<div class="cards"><div class="card"><small>기준 예시의 출구 압력</small><div class="number">5 kPa</div><small>지중 출구 기준 · 펌프 계기값 아님</small></div><div class="card"><small>공급 목표: 슬러리 10 mL</small><div class="number">0.4455 g</div><small>총 건조 고체 · 황:CaCO₃ = 진체적 3:1</small></div><div class="card"><small>주입 시작 이후 목표 도달</small><div class="number">{(base['injection_completion_s']-300)/60:.3f}분</div><small>주입은 시뮬레이션 시작 5분 뒤</small></div></div>
<div class="note"><strong>숫자의 지위:</strong> 토양값, 압력, 1 mm 등가 출구 반지름, 입경 5 μm, 잔류 계수, 2 vol% 농도, 10 mL 투입량은 변경 가능한 <strong>계산 예시 가정</strong>이다. 실험으로 보정한 연구 기준안이나 실제 장치의 검증값이 아니다. 외관 Ø10 mm가 내부 노즐 Ø2 mm로 확정됐다는 뜻도 아니다.</div>
<p class="muted">0.2 × 0.2 × 0.4 m 토양, 8 × 8 × 16 셀, 관찰 120분. 초기 질산염 40 mg NO₃⁻/L. 표면 전역에 균일한 2×10⁻⁹ kg NO₃⁻/m²/s 부하를 주며, 비료 용출·질산화는 풀지 않는다. 관 설치·배치 구성은 기존 Stage 5에 남긴다.</p></section>
<section><h2>압력과 주입시간, 입자의 행방</h2><p>3·5·10 kPa 예시는 같은 총고체량을 공급한다. 목표량에 닿는 마지막 시간 구간은 수리를 다시 풀어 결정하고 이후 출구를 닫는다. 관찰시간 종료까지 목표에 못 미친 경우는 미달로 남긴다.</p>{img(overview,'압력별 유량·누적 고체량과 기준 예시의 입자 저장고·질산염 수지')}
{table(['조건','투입 고체 g','투입 슬러리 mL','주입 시작 후 완료 분','상태'],pressure_rows)}
<p class="caption">미달/무주입은 종료 사건과 대조 기능을 확인하는 별도 사례이며 같은 투입량 성능 비교에 끼워 넣지 않는다. 높은 압력의 빠른 공급이 우수한 탈질이나 안전한 현장 주입을 뜻하지 않는다.</p></section>
<section><h2>계산된 3D 분포와 시간별 단면</h2><p>시간을 선택하면 저장된 3D 해의 같은 y 위치 단면을 바꿔 본다. 모든 시각에 같은 색 범위를 적용했다. 빨간 십자는 대표 출구 위치다.</p><label for="frameSelect">저장 시점 </label><select id="frameSelect">{options}</select>{slice_content}
{img(cloud,'계산된 고체 총량의 3차원 셀 중심 분포')}<p class="caption">3D 그림은 t=120분에서 이동+잔류 고체의 토양 부피당 질량이 최대값의 1% 이상인 <strong>계산 셀 중심</strong>을 표시한다. 표시 임계값 {threshold:.5g} kg/m³. 점 크기나 경계를 실제 입자·도달 반경으로 해석하지 않는다. 구형 분포를 강제하지 않았다.</p></section>
<section><h2>질산염은 제거됐는가?</h2><p><strong>이 단계의 탈질 제거량은 0이다.</strong> 농도 감소는 희석·이동으로, 저장량 감소는 경계 유출과 함께 해석한다. 입자 부착·걸러짐으로 남은 양도 질산염 제거량이 아니다.</p>
{table(['성분','초기 mg','누적 유입 mg','이동 mg','부착 mg','걸러짐 mg','누적 유출 mg','수지 잔차 mg'],budget_rows)}
<p>운반수 수지: 초기 {initial['water_stored_m3']*1e6:.6f} mL + 유입 {f['water_in_m3']*1e6:.6f} mL − 유출 {f['water_out_m3']*1e6:.6f} mL = 최종 {f['water_stored_m3']*1e6:.6f} mL. 잔차 {f['water_residual_m3']*1e6:.3e} mL.</p><p class="caption">유입에는 표면과 출구를 모두 포함한다. 물은 운반수 부피 기준이며 슬러리 총부피와 다르다. 질산염 단위는 질소 mg-N이 아니라 질산염 이온 mg이다.</p></section>
<section><h2>구현 검사와 결과의 한계</h2><p>기존 회귀시험을 포함한 <strong>{nt.group(1)}개 자동시험 통과</strong>. 실제 실행 {len(summaries)}개 사례에서 최대 종별 상대 질량수지 잔차는 {maxmass:.2e}, 물의 유입+유출 대비 최대 상대 잔차는 {maxwater:.2e}다. 작은 수지 잔차는 현실 정확도의 백분율이 아니다.</p>
{table(['시간 간격 비교','고체 총 분포 L1 상대 차이','완료시간 상대 차이','수두 RMSE m'],time_rows)}
<div class="note"><strong>{grid_warning}:</strong> 8×8×16 → 12×12×24에서 주입 완료시간 차이 {grid_diff:.3f}%, 황 잔류량 차이 {gd['retained_sulfur_relative_difference']*100:.3f}%. 두 격자는 민감도 진단이며 공간 수렴을 입증하지 않는다. 압력 주입의 실제 시간·분포를 연구 결론으로 사용하기 전에 출구 근사와 공간 해상도를 추가 검토해야 한다.</div>
<p>출구 주변의 전도도를 셀 값 하나로 고정했던 초기 근사에서 큰 격자 차이를 발견해, 수두에 따른 전도도 적분으로 보완했다. 초기 진단은 최종 계산과 구분해 보존했다. 현재도 독립 소프트웨어 비교와 실제 토양·슬러리 보정은 수행 전이다.</p>
<details><summary>자동 구현 검사 {len(checks['implementation_requirements'])}개 항목 보기</summary>{table(['항목','판정'],requirement_rows)}<p>{'모든 구현 검사 통과.' if not failures else '미통과: '+html.escape(', '.join(failures))}</p></details></section>
<section><h2>어떤 식으로 계산했는가?</h2><p>운반수의 Richards 유동과 질량 보존형 MUSCL 수송을 사용한다. 입자 잔류는 별도 저장고로 이동시키며, 같은 총고체량 종료에는 수리 재계산을 사용한다. 아래는 새 결합의 핵심 식이다.</p>
<pre>φ = (cS/ρS + cCa/ρCa) / (1 + cS/ρS + cCa/ρCa)
ρmix = (ρwater + cS + cCa) / (1 + cS/ρS + cCa/ρCa)
μmix = μwater (1 + 2.5φ),  국소 φ ≤ 0.02

∂θ/∂t + div(qw) = Sw
qw = -Ksat kr(h) (1-φ) μwater/μmix [grad(h) - ρmix/ρwater ez]

Qwater = B ∫[hcell → hout*] kr(h) dh   (양의 구동일 때)
B = 4π Ksat (1-φin) μwater/μin / (1/rw - 1/re)
Qslurry = Qwater / (1-φin)

mi = θci,   vset,i = fset (ρi-ρmix) g di² / (18 μmix)
∂mi/∂t + div(qw ci + θvset,i ci ez - θDi grad(ci))
  = Sw cin,i - (ka,i + ks,i)mi + kd,i ai
∂ai/∂t = ka,i mi - kd,i ai,   ∂si/∂t = ks,i mi</pre>
<p class="muted">c: kg/m³ 운반수, m·a·s: kg/m³ 토양. 출구는 등가 구형 저항이며 실제 노즐이나 관 내부를 해상하지 않는다. 국소 전도도 적분은 64점 수치 적분, 포화 구간은 해석 적분. 물성·침강은 한 수리 구간 지연 결합이다. 입자 변위가 보수곡선을 바꾸는 효과, 응집·공극 막힘·균열·공기 포획·탄성 저류·미생물 반응은 미구현이다.</p>
<details><summary>잔류 계수의 지위와 문헌 근거</summary><p>예시의 부착 2×10⁻⁴/s, 탈착 2×10⁻⁵/s, 걸러짐 1×10⁻⁴/s, 침강 감소계수 0.1은 가정값이다. Bradford 등의 연구는 부착·걸러짐을 구분하는 가설의 근거이며 해당 실험 계수를 황·탄산칼슘에 전용하지 않았다. 여기서는 일정 계수이며 깊이 의존 걸러짐·공극 배제를 구현한 것이 아니다.</p><p><a href="https://www.ars.usda.gov/arsuserfiles/20361500/pdf_pubs/P1850.pdf">Bradford et al. (2003), DOI 10.1021/es025899u</a> · <a href="https://gmd.copernicus.org/articles/16/659/2023/gmd-16-659-2023.html">Ireson et al. (2023), DOI 10.5194/gmd-16-659-2023</a> · <a href="https://www.nature.com/articles/155364b0">Vand (1945), DOI 10.1038/155364b0</a>. 문헌의 식을 사용했다고 본 연구 모델이 공인되거나 실험 검증된 것은 아니다.</p></details></section>
<section><h2>파일과 다음 검토</h2><p>이번 구현본에는 실제 계산 입력, 전체 시간 이력, 3D 배열, 코드, 수식·가정 문서와 재현 스크립트가 들어 있다. 이 HTML은 외부 라이브러리 없이 열리며 그림도 내장되어 있다.</p>
<pre>python -m pip install .
python -m unittest discover -s tests -v
python -m kjwp_stage1.stage2 configs/stage2_pressure_particles.json --out outputs/my_stage2
python scripts/run_stage2_final.py
python scripts/build_stage2_report.py</pre>
<p>각 사례: input.json · summary.json · history.csv · fields.npz. 상세 식/범위: docs/STAGE2_METHODS_v0_3_0.md. 관 설계·미정값: docs/DESIGN_CONSTRAINTS_20261102.md.</p><p><strong>다음은 Stage 2 결과 검토다.</strong> 출구 근사·공간 해상도, 입력값의 근거, 실제 슬러리 주입 가능성과 OGS 공통 사례 비교를 확인한다. Stage 3의 반응 계산이나 Stage 5의 서비스관 배치 설계를 자동으로 시작하지 않는다.</p></section>
</main><footer>KJWP · 계산 구현 v0.3.0 · 가상 조건 결과 · 연구용 시뮬레이터 · 실험/OGS 검증 별도</footer>
<script>document.getElementById('frameSelect').addEventListener('change',function(){{document.querySelectorAll('.frame').forEach((f,i)=>{{f.hidden=i!==Number(this.value);}});}});</script></body></html>'''
    (ROOT/'STAGE2_RESULTS.html').write_text(text,encoding='utf-8')
    print('Wrote',ROOT/'STAGE2_RESULTS.html',len(text.encode()),'bytes')


if __name__=='__main__': main()
