"""Build human-readable verification report from actual saved results."""
import json
import re
from pathlib import Path
import platform
import numpy as np
import scipy


def main():
    root=Path('outputs/spec_3_1')
    legacy=json.loads((root/'legacy_verification/validation.json').read_text())
    ext=json.loads((root/'extended_verification/verification.json').read_text())
    checks=json.loads((root/'stage2_checks/checks.json').read_text())
    run=json.loads((root/'stage2_injection/run.json').read_text())
    tests=(root/'unit_tests.txt').read_text()
    count=int(re.search(r'Ran (\d+) tests',tests)[1])
    if not tests.rstrip().endswith('OK') or legacy['status']!='PASS' or not checks['passed']:
        raise RuntimeError('required result not passing')
    if not all(v['passed'] for v in ext.values()): raise RuntimeError('extended verification failed')
    gauss=legacy['checks'][1]['relative_l1']
    ev=ext['eigenmode'];cel=ext['celia_reference'];tr=ext['transport_refinement'];up=ext['first_order_baseline']
    budget=run['final_budget'];base=checks['cases'][0]
    lines=['# 2026-11-01 수치검증과 단계별 판정','',
        '**판정: Stage 1 수치모델 작업 정리, Stage 2 초기 구현·검증 진행. 실환경 및 OGS 검증은 미완료.**','',
        f'현재 실행 환경: Python {platform.python_version()}, NumPy {np.__version__}, SciPy {scipy.__version__}. '
        '합성 조건의 계산이며 측정자료가 아니다. 코드 v0.2.0 / 확장 명세 3.1.','',
        '| 확인 | 실제 결과 | 판정 |','|---|---|---|',
        f'| 자동검사 | 기존 25개+신규 {count-25}개 = {count}개 | 통과 |',
        f'| 기존 ADE 검증 | {len(legacy["checks"])}개, Gaussian 96³ L1={100*gauss[-1]:.6f}% | 기존 기준 통과 |',
        '| 3D 흐름 공간차수 | '+', '.join(f'{r["order"]:.4f}' for r in ev['spatial'][1:])+' | 2차 확인 |',
        '| 흐름 시간차수 | '+', '.join(f'{r["order"]:.4f}' for r in ev['temporal'][1:])+' | 후진 Euler 1차 확인 |',
        f'| Celia 조건, 독립 BDF 시간 비교 | dt 1.25 s 수두 RMSE {1000*cel["rows"][-1]["head_rmse_m"]:.4f} mm | 시간 수렴 확인 |',
        f'| 새 기본 MUSCL 수송 | nz=240, L1 {100*tr["rows"][-1]["normalized_L1"]:.4f}% | 5% 내부 기준 통과 |',
        f'| 비교용 1차 수송 | 같은 조건 L1 {100*up["rows"][-1]["normalized_L1"]:.4f}% | 수렴하지만 5% 정확도 기준 실패 |',
        '| 위치·유량·무주입 대조 | 공급·대칭·유량 반응·NO3 질량 보존 | 통과 |',
        '| OGS·현장 측정 비교 | 이번 미실행 | 미완료 |','',
        '## 고정 흐름 ADE 재검증','',
        '| 격자 | 상대 L1 |','|---|---|']
    lines += [f'| {n}³ | {100*e:.6f}% |' for n,e in zip((24,48,96),gauss)]
    lines += ['', '기존 수렴차수와 해석해·BTC·질량수지 시험을 보존했다. 상세는 '
        '`outputs/spec_3_1/legacy_verification/validation.json`. 그 파일의 OGS 미설치 문구는 '
        '범용 기존 실행기 문구다. 사용자 Windows의 설치/실행 실패 이력은 SPEC_3_1.md를 따른다.','',
        '## 비선형 Richards 비교의 범위','',
        '공개 Celia 문제: 깊이 0.4 m, dz=0.01 m, 초기 수두 −0.615 m, 상부 −0.207 m, 하부 −0.615 m, 360 s. '
        'Haverkamp 보수·투수법칙과 원문의 cm 단위를 SI로 변환했다. 독립적으로 작성한 1D θ 상태 BDF 코드를 '
        '같은 공간격자의 시간 기준으로 썼다. 실제 계산은 수평 2×2 셀의 3D 솔버로 수행했다. '
        '이 결과는 원저자 출력 파일·독립 소프트웨어·현장과의 일치 검증이 아니다.','',
        '| dt [s] | 수두 RMSE [m] | 물 상대 수지 잔차 |','|---|---|---|']
    lines += [f'| {r["dt_s"]:g} | {r["head_rmse_m"]:.8f} | {r["water_relative_residual"]:.3e} |' for r in cel['rows']]
    lines += ['', '3D 선형 검증은 인공 θ(h)·상수 K 조건의 해석 모드다. 이를 실제 토양의 물성으로 사용하지 않는다. '
        '공간 비교는 동일 후진 Euler 시간연산의 연속 공간 모드와 비교하여 공간 오차를 분리했다. '
        '시간 비교는 정확한 반이산 모드를 기준으로 삼았다.','',
        '## 새 용질 수송의 정확도 개선','',
        '| nz | 기본 MUSCL L1 | 비교용 implicit upwind L1 |','|---|---|---|']
    lines += [f'| {a["nz"]} | {100*a["normalized_L1"]:.4f}% | {100*b["normalized_L1"]:.4f}% |'
              for a,b in zip(tr['rows'],up['rows'])]
    lines += ['', '두 방식 모두 질량수지는 작지만 농도 정확도는 다르다. 1차 비교 방식은 한계를 보이기 위해 남겼으며 '
        '그 정확도 기준이 통과했다고 처리하지 않았다. 신규 수송의 고정 흐름·격자/시간 동시 세분화 시험이고, '
        '별도 3D 사선 Gaussian 시험도 자동검사에 포함했다. 변하는 θ에서의 자유류 농도 보존·희석·펄스 수지도 검사했다. '
        '비정상 결합계 전체의 2차 시간 정확도는 주장하지 않는다.','',
        '## Stage 2 실제 계산','',
        '40×40×40 cm 가상 토양, 8×8×16 셀, 초기 정수압·밀폐 경계, '
        '(0.125,0.175,0.2) m 중심, 공급 반경 0.065 m. 0–600 s 주입, 총 1800 s 계산. '
        '주입수의 NO3는 0, 용존 추적자는 40 mg/L다. 반응은 없다.','',
        f'- 주입수: {budget["water_in_m3"]*1e6:.6f} mL; 추적물질 공급: {budget["tracer"]["in_kg"]*1e6:.6f} mg.',
        f'- NO3 총질량: 초기 {budget["NO3"]["initial_kg"]*1e6:.6f} mg, 최종 {budget["NO3"]["stored_kg"]*1e6:.6f} mg.',
        f'- 국소 최저 NO3: 초기 40 mg/L, 최종 {budget["NO3"]["min_kg_m3"]*1000:.6f} mg/L. **농도 감소는 희석이며 제거량은 0.**',
        f'- 물 상대 수지 잔차 {budget["water_relative_residual"]:.3e}; 추적자 {budget["tracer"]["relative_residual"]:.3e}.',
        f'- x축 반사 배치의 추적자장 대칭 차이 최대 {checks["checks"]["mirror_x_max_concentration_difference_kg_m3"]:.3e} kg/m³.',
        f'- 주입 후 실제 횡방향 플럭스 최대 {base["max_lateral_flux_m_s"]:.6e} m/s.','',
        '반유량 조건은 압력·횡방향 흐름 변화가 더 작았고, 무주입 정수압 조건은 정지 상태를 유지했다. '
        '이 대조군들은 물리적 일관성 검사다. 실제 주입 토조의 정확도와 배치별 최적 성능을 증명하지 않는다.','',
        '![계산 결과의 단면](../outputs/spec_3_1/stage2_injection/slices.png)','',
        '## 재현성과 남은 작업','',
        '계산 원본 NPZ, 매 시간단계 수지 CSV, 깊이별 BTC, 입력 및 코드 SHA256은 각 실행 폴더에 있다. '
        '원본 v0.1 자료와 당시 문서는 별도로 남겼다. 새 실행 명령은 README에 있다.','',
        'Stage 1의 수치검증 범위를 마무리하고 Stage 2로 넘어갔다. Stage 2의 기초 기능·대조 계산은 구현했지만 '
        '실제 주입 형상과 토양에서의 격자/시간 독립성·실측 비교는 추가 작업이다. '
        '황·탄산칼슘 반응은 명세 검토만 했으며 Stage 3에서 독립 배치 반응부터 구현한다. '
        'OGS, 입자 전달, 후보 5개의 확정 배치, 현장 보정, 최종 UI는 미완료다.']
    Path('docs/VALIDATION_20261101.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print('report written; all required saved result gates checked')


if __name__=='__main__': main()
