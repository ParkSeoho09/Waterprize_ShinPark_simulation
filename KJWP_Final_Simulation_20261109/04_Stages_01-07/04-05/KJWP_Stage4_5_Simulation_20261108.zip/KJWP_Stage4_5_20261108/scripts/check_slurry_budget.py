"""Material/dose bookkeeping demonstration ONLY, not pressure or particle flow."""
import argparse
import hashlib
import json
from pathlib import Path
from kjwp_stage1.physics.slurry import Slurry,DoseBudget


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('config');p.add_argument('--out',required=True);a=p.parse_args()
    c=json.loads(Path(a.config).read_text(encoding='utf-8'))
    if set(c)!={'slurry','target_dry_solid_kg','prescribed_rates_m3_s','proposed_dt_s'}:
        raise ValueError('unexpected/missing configuration keys')
    s=Slurry(**c['slurry']);cases=[]
    for rate in c['prescribed_rates_m3_s']:
        if rate<=0: raise ValueError('demonstration requires positive rates')
        dose=DoseBudget(s,c['target_dry_solid_kg']);t=0.;steps=0
        while not dose.done:
            dt=dose.dt_for_constant_rate(rate,c['proposed_dt_s'])
            if t+dt==t or steps>100000: raise RuntimeError('dose time cannot advance')
            dose.accept(rate*dt);t+=dt;steps+=1
        cases.append(dict(prescribed_rate_m3_s=rate,time_to_target_s=t,steps=steps,**dose.summary()))
    out=Path(a.out);out.mkdir(parents=True,exist_ok=True)
    report=dict(scope='input/derived properties and accepted-volume dose controller; NOT a spatial transport simulation',
        assumptions='3:1 true solid volume; additive volumes; ideal dilute sphere viscosity',
        source_sha256=hashlib.sha256(Path('kjwp_stage1/physics/slurry.py').read_bytes()).hexdigest(),
        input=c,material=s.summary(),cases=cases,
        next_unimplemented=['pressure-controlled internal injection','slurry-fluid flow coupling',
                            'particle settling/retention','target-dose stopping inside the spatial solver'])
    (out/'check.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False,indent=2))


if __name__=='__main__': main()
