"""Stage 2 pressure / dilute particle coupling. No denitrification reactions.

Water storage is carrier-water volume. Particle displacement in the retention
curve is neglected (dilute approximation); particle volume is accounted for in
inlet dose and local fluid properties. Properties are lagged one time step.
"""
from dataclasses import asdict, replace
import copy
import csv
import hashlib
import json
from pathlib import Path
import platform
import numpy as np
import scipy
from . import __version__
from .core.grid import Grid
from .flow.hydraulics import VanGenuchten
from .flow.richards import WaterBoundary, boundary_water_rates, FlowConvergenceError
from .flow.pressure import PressureFlow, PressurePort
from .physics.boundary import Boundary, FACES
from .physics.slurry import Slurry, DoseBudget
from .physics.particles import (PARTICLES, Retention, mixture_properties,
                               settling_velocity, particle_fluxes)
from .numerics.transient_muscl import transport_muscl

SPECIES = ('NO3', 'tracer') + PARTICLES


def _field(value, grid):
    a=np.broadcast_to(np.asarray(value,dtype=float),grid.shape).copy()
    if not np.all(np.isfinite(a)) or np.any(a<0):
        raise ValueError('finite nonnegative concentration required')
    return a


def solve(config, output=None, progress=None):
    """Run accepted BE hydraulic steps with conservative MUSCL species transport.

    Boundary forcing and dose events align exactly with time intervals.
    A dose event shortens and RE-SOLVES hydraulics (no flux rescaling).
    """
    cfg=copy.deepcopy(config)
    g=Grid(tuple(cfg['grid']['lengths_m']),tuple(cfg['grid']['cells_xyz']))
    soil=VanGenuchten(**cfg['soil']); slurry=Slurry(**cfg.get('slurry',{}))
    dose=DoseBudget(slurry,float(cfg['target_dry_solid_kg']))
    ports=[PressurePort(**p) for p in cfg['ports']]
    if not ports: raise ValueError('at least one pressure outlet required')
    for p in ports: p.cell(g)
    wb={f:WaterBoundary(**cfg['water_boundaries'][f]) for f in FACES}
    flow=PressureFlow(g,soil,wb,theta_tolerance=cfg.get('theta_tolerance',1e-11),max_iterations=150)
    # Uniform inward water flux + uniform upstream C gives uniform top mass load.
    top_load=float(cfg.get('surface_NO3_load_kg_m2_s',0.))
    if not np.isfinite(top_load) or top_load<0: raise ValueError('invalid nitrate surface load')
    if top_load>0 and (wb['z-'].kind!='flux' or not np.isscalar(wb['z-'].value) or wb['z-'].value>=0):
        raise ValueError('uniform nitrate load requires uniform inward top water flux')
    end=float(cfg['end_s']); maxdt=float(cfg['max_dt_s'])
    if not np.isfinite(end) or end<=0 or not np.isfinite(maxdt) or maxdt<=0:
        raise ValueError('invalid simulation duration or time step')
    times=np.asarray(cfg.get('save_times_s',[0.,end]),dtype=float)
    if not np.all(np.isfinite(times)) or np.any(times<0) or np.any(times>end):
        raise ValueError('invalid output times')
    save_times=sorted(set([0.,end]+[float(v) for v in times]))
    events=set(save_times)
    for p in ports:
        events.add(p.start_s)
        if p.end_s is not None: events.add(p.end_s)
    events=sorted(v for v in events if 0<=v<=end)
    retention={s:Retention(**cfg.get('retention',{}).get(s,{})) for s in PARTICLES}
    reduction=float(cfg.get('settling_reduction',0.))
    if not np.isfinite(reduction) or not 0<=reduction<=1: raise ValueError('invalid settling factor')
    d_sol=tuple(cfg.get('solute_dispersion_m2_s',[1e-9]*3))
    d_par=tuple(cfg.get('particle_dispersion_m2_s',[1e-10]*3))
    if any(len(d)!=3 or np.any(np.asarray(d)<0) or not np.all(np.isfinite(d)) for d in (d_sol,d_par)):
        raise ValueError('three finite nonnegative dispersion values required')
    z,_,_=g.mesh_zyx()
    h=z-float(cfg['initial_hydrostatic_water_table_depth_m'])
    theta=flow.theta(h)
    c={s:_field(cfg.get('initial_kg_m3_carrier',{}).get(s,0.),g) for s in SPECIES}
    attached={s:np.zeros(g.shape) for s in PARTICLES}
    strained={s:np.zeros(g.shape) for s in PARTICLES}
    inlet=dict(NO3=float(cfg.get('inlet_NO3_kg_m3_carrier',0.)),
               tracer=float(cfg.get('inlet_tracer_kg_m3_carrier',.04)))
    inlet.update({s:slurry.component_kg_per_m3_slurry[s]/(1-slurry.solid_volume_fraction)
                  for s in PARTICLES})
    if any(not np.isfinite(v) or v<0 for v in inlet.values()): raise ValueError('invalid inlet concentration')
    cb={s:{f:Boundary('closed' if wb[f].kind=='closed' else 'inflow_flux',
          top_load/(-wb['z-'].value) if (s=='NO3' and f=='z-' and top_load>0) else 0.)
          for f in FACES} for s in SPECIES}
    initial_water=float(theta.sum()*g.volume)
    initial_mass={s:float((theta*c[s]).sum()*g.volume) for s in SPECIES}
    cumulative={s:dict(in_kg=0.,out_kg=0.,bottom_out_kg=0.,inlet_kg=0.,boundary_in_kg=0.) for s in SPECIES}
    win=wout=0.; t=0.; completion=None; rejected=0; roots=0; history=[]; fields=[]
    maxcell=0.; maxresidual=0.; count=0

    def record(qrates=None, dt=0., iterations=0):
        props=mixture_properties(slurry,c)
        row=dict(time_s=t,dt_s=dt,water_stored_m3=float(theta.sum()*g.volume),
                 water_in_m3=win,water_out_m3=wout,
                 water_residual_m3=float(theta.sum()*g.volume)-initial_water-win+wout,
                 slurry_in_m3=dose.injected_volume_m3,
                 slurry_rate_m3_s=0. if qrates is None else float(sum(qrates))/(1-slurry.solid_volume_fraction),
                 hydraulic_iterations=iterations,
                 mobile_phi_max=float(props['phi'].max()),
                 mixture_density_max_kg_m3=float(props['density_kg_m3'].max()),
                 mixture_viscosity_max_Pa_s=float(props['viscosity_Pa_s'].max()))
        for s in SPECIES:
            m=float((theta*c[s]).sum()*g.volume)
            a=float(attached[s].sum()*g.volume) if s in PARTICLES else 0.
            st=float(strained[s].sum()*g.volume) if s in PARTICLES else 0.
            v=cumulative[s]
            row.update({s+'_'+k:val for k,val in dict(mobile_kg=m,attached_kg=a,strained_kg=st,
                       stored_kg=m+a+st,**v,
                       residual_kg=m+a+st-initial_mass[s]-v['in_kg']+v['out_kg'],
                       min_kg_m3=float(c[s].min()),max_kg_m3=float(c[s].max())).items()})
        history.append(row)

    def snapshot():
        fields.append(dict(time_s=t,head_m=h.copy(),theta=theta.copy(),
                      **{s+'_kg_m3_carrier':c[s].copy() for s in SPECIES},
                      **{s+'_attached_kg_m3_soil':attached[s].copy() for s in PARTICLES},
                      **{s+'_strained_kg_m3_soil':strained[s].copy() for s in PARTICLES}))

    record(); snapshot()
    while t<end-1e-10:
        next_event=min(v for v in events if v>t+1e-10)
        dt=float(min(maxdt,next_event-t))
        props=mixture_properties(slurry,c)
        flow.set_fluid(props)
        active=[] if dose.done else ports
        while True:
            try:
                water,rates=flow.step_pressure(h,t,dt,active,slurry)
                break
            except FlowConvergenceError:
                dt*=.5; rejected+=1
                if dt<1e-6: raise
        vslurry=float(sum(rates))*dt/(1-slurry.solid_volume_fraction)
        remaining=dose.remaining_volume_m3
        if vslurry>remaining and not dose.done:
            # Locate monotone accepted-step inlet integral with safeguarded bisection.
            # No field, mass, pressure or flux is scaled after a solve.
            low=0.; high=dt; best=None
            for _ in range(64):
                trial=.5*(low+high)
                w,r=flow.step_pressure(h,t,trial,active,slurry)
                volume=float(sum(r))*trial/(1-slurry.solid_volume_fraction)
                roots+=1
                if volume<=remaining:
                    low=trial; best=(trial,w,r,volume)
                else: high=trial
                if best is not None and remaining-best[3]<=5e-13*dose.target_volume_m3:
                    break
            if best is None: raise RuntimeError('failed to locate positive dose event')
            dt,water,rates,vslurry=best
        oldtheta=theta
        # Local retention half step at old water content.
        working={s:c[s].copy() for s in SPECIES}
        anew={s:attached[s].copy() for s in PARTICLES}
        snew={s:strained[s].copy() for s in PARTICLES}
        for s in PARTICLES:
            m,anew[s],snew[s]=retention[s].step(oldtheta*working[s],anew[s],snew[s],dt/2)
            working[s]=m/oldtheta
        newc={}; stepbudgets={}
        for s in SPECIES:
            w=water
            if s in PARTICLES:
                velocity=settling_velocity(slurry,s,props,reduction)
                w=replace(water,fluxes=particle_fluxes(water,velocity,wb['z+'].kind!='closed'))
            newc[s],stepbudgets[s]=transport_muscl(g,w,working[s],dt,
                  d_par if s in PARTICLES else d_sol,cb[s],np.nextafter(t+dt,t),water.source*inlet[s])
        for s in PARTICLES:
            m,anew[s],snew[s]=retention[s].step(water.theta*newc[s],anew[s],snew[s],dt/2)
            newc[s]=m/water.theta
        # Reject out-of-scope concentrations rather than silently clip properties.
        mixture_properties(slurry,newc)
        for s,b in stepbudgets.items():
            v=cumulative[s]
            v['in_kg']+=b['in_kg']+b['source_in_kg']
            v['out_kg']+=b['out_kg']+b['source_out_kg']
            v['inlet_kg']+=b['source_in_kg']; v['boundary_in_kg']+=b['in_kg']
            v['bottom_out_kg']+=dt*b['bottom_out_kg_s']
            maxresidual=max(maxresidual,b['cell_residual_max_kg'])
        bi,bo=boundary_water_rates(water.fluxes,g)
        win+=bi*dt+float(sum(rates))*dt; wout+=bo*dt
        dose.accept(vslurry)
        h=water.head; theta=water.theta; c=newc; attached=anew; strained=snew
        t+=dt; count+=1; maxcell=max(maxcell,water.cell_balance_max)
        if dose.done and completion is None: completion=t
        record(rates,dt,water.iterations)
        if any(abs(t-v)<1e-8 for v in save_times): snapshot()
        if progress is not None and (count%25==0 or abs(t-end)<1e-8):
            progress(dict(time_s=t,steps=count,dose_fraction=dose.injected_volume_m3/dose.target_volume_m3))
    result=dict(config=cfg,history=history,fields=fields,
                summary=dict(code_version=__version__,model='dilute_stage2_pressure_particles_kirchhoff_v1',
                  chemistry_enabled=False,denitrification_removed_kg=0.,
                  dose=dose.summary(),injection_completion_s=completion,
                  hydraulic_steps=count,hydraulic_rejections=rejected,dose_root_solves=roots,
                  max_water_cell_residual=maxcell,max_transport_cell_residual_kg=maxresidual,
                  final=history[-1],initial=history[0],
                  limitations=[
                    'illustrative assumptions, not soil/slurry calibrated or OGS/experiment validated',
                    'carrier-water Richards storage neglects particle displacement (dilute model)',
                    'equivalent spherical subgrid outlet is not resolved nozzle geometry or plume shape',
                    'local isotropic permeability required at outlet; no pressure losses in pipe',
                    'fluid density/viscosity and settling lagged one hydraulic interval',
                    'first-order attachment/detachment/straining, no capacity or clogging feedback',
                    'Stokes settling times empirical reduction, no aggregation or pore exclusion',
                    'constant dispersion coefficients; no fracture, air entrapment or geomechanics',
                    'no nitrification, microbial reactions, denitrification or crop uptake']))
    if output is not None: save(result,g,output)
    return result


def save(result,grid,output):
    path=Path(output); path.mkdir(parents=True,exist_ok=True)
    raw=json.dumps(result['config'],ensure_ascii=False,sort_keys=True,indent=2)+'\n'
    (path/'input.json').write_text(raw,encoding='utf-8')
    summary=result['summary']
    summary['input_sha256']=hashlib.sha256(raw.encode()).hexdigest()
    summary['runtime']=dict(python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__)
    (path/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    with (path/'history.csv').open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=list(result['history'][0]))
        writer.writeheader(); writer.writerows(result['history'])
    keys=result['fields'][0].keys()
    arrays={k:np.asarray([v[k] for v in result['fields']]) for k in keys}
    arrays.update({a+'_m':v for a,v in zip('xyz',grid.centers_xyz)})
    np.savez_compressed(path/'fields.npz',**arrays)


def main():
    import argparse
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('config'); p.add_argument('--out',required=True)
    args=p.parse_args()
    r=solve(json.loads(Path(args.config).read_text(encoding='utf-8')),args.out,
            lambda x: print(json.dumps(x),flush=True))
    print(json.dumps(r['summary'],ensure_ascii=False,indent=2))


if __name__=='__main__': main()
